#ifndef __ENUMS_H__
#define __ENUMS_H__

enum AddSubImmediateOp_e
{
    ADD_w_imm = 285212672,
    ADD_x_imm = -1862270976,
};
typedef enum AddSubImmediateOp_e AddSubImmediateOp;

enum RegisterType
{
    kRegister_32,
    kRegister_W = kRegister_32,
    kRegister_64,
    kRegister_X = kRegister_64,
    kRegister,

    kVRegister,
    kSIMD_FP_Register_8,
    kSIMD_FP_Register_B = kSIMD_FP_Register_8,
    kSIMD_FP_Register_16,
    kSIMD_FP_Register_H = kSIMD_FP_Register_16,
    kSIMD_FP_Register_32,
    kSIMD_FP_Register_S = kSIMD_FP_Register_32,
    kSIMD_FP_Register_64,
    kSIMD_FP_Register_D = kSIMD_FP_Register_64,
    kSIMD_FP_Register_128,
    kSIMD_FP_Register_Q = kSIMD_FP_Register_128,

    kInvalid,
};

// Conditional branch.
enum ConditionalBranchOp
{
    ConditionalBranchFixed     = 0x54000000,
    ConditionalBranchFixedMask = 0xFE000000,
    ConditionalBranchMask      = 0xFF000010,
};

// Test and branch.
enum TestBranchOp
{
    TestBranchFixed     = 0x36000000,
    TestBranchFixedMask = 0x7E000000,
};

enum LoadRegLiteralOp_e
{
    LoadRegLiteralFixed     = 0x18000000,
    LoadRegLiteralFixedMask = 0x3B000000,
    LDR_w_literal = LoadRegLiteralFixed | ( ( 0b00 & ( ( 1 << 2 ) - 1 ) ) << 30 ) | ( ( 0 & ( ( 1 << 1 ) - 1 ) ) << 26 ),
    LDR_x_literal = LoadRegLiteralFixed | ( ( 0b01 & ( ( 1 << 2 ) - 1 ) ) << 30 ) | ( ( 0 & ( ( 1 << 1 ) - 1 ) ) << 26 ),
    LDR_s_literal = LoadRegLiteralFixed | ( ( 0b00 & ( ( 1 << 2 ) - 1 ) ) << 30 ) | ( ( 1 & ( ( 1 << 1 ) - 1 ) ) << 26 ),
    LDR_d_literal = LoadRegLiteralFixed | ( ( 0b01 & ( ( 1 << 2 ) - 1 ) ) << 30 ) | ( ( 1 & ( ( 1 << 1 ) - 1 ) ) << 26 ),
    LDR_q_literal = LoadRegLiteralFixed | ( ( 0b10 & ( ( 1 << 2 ) - 1 ) ) << 30 ) | ( ( 1 & ( ( 1 << 1 ) - 1 ) ) << 26 ),
};
typedef enum LoadRegLiteralOp_e LoadRegLiteralOp;

// Unconditional branch.
enum UnconditionalBranchOp
{
  UnconditionalBranchFixed      = 0x14000000,
  UnconditionalBranchFixedMask  = 0x7C000000,
  UnconditionalBranchMask       = 0xFC000000,
  B  = UnconditionalBranchFixed | 0x00000000,
  BL = UnconditionalBranchFixed | 0x80000000,
};

enum AddSubImmediateOp
{
    ADD_w_imm = 285212672,
    ADD_x_imm = -1862270976,
};

enum PCRelAddressingOp
{
    PCRelAddressingFixed = 0x10000000,
    PCRelAddressingFixedMask = 0x1F000000,
    PCRelAddressingMask = 0x9F000000,
    ADR = PCRelAddressingFixed | 0x00000000,
    ADRP = PCRelAddressingFixed | 0x80000000,
};

// Compare and branch.
enum CompareBranchOp
{
    CompareBranchFixed     = 0x34000000,
    CompareBranchFixedMask = 0x7E000000,
};

enum UnconditionalBranchToRegisterOp
{
    UnconditionalBranchToRegisterFixed = 0xD6000000,
    BR = UnconditionalBranchToRegisterFixed | 0x001F0000,
    BLR = UnconditionalBranchToRegisterFixed | 0x003F0000,
};

enum LoadRegLiteralOp
{
    LoadRegLiteralFixed = 0x18000000,
    LoadRegLiteralFixedMask = 0x3B000000,
    LDR_w_literal = LoadRegLiteralFixed | ((0b00 & ((1 << 2) - 1)) << 30) | ((0 & ((1 << 1) - 1)) << 26),
    LDR_x_literal = LoadRegLiteralFixed | ((0b01 & ((1 << 2) - 1)) << 30) | ((0 & ((1 << 1) - 1)) << 26),
    LDR_s_literal = LoadRegLiteralFixed | ((0b00 & ((1 << 2) - 1)) << 30) | ((1 & ((1 << 1) - 1)) << 26),
    LDR_d_literal = LoadRegLiteralFixed | ((0b01 & ((1 << 2) - 1)) << 30) | ((1 & ((1 << 1) - 1)) << 26),
    LDR_q_literal = LoadRegLiteralFixed | ((0b10 & ((1 << 2) - 1)) << 30) | ((1 & ((1 << 1) - 1)) << 26),
};


// Move wide immediate.
enum MoveWideImmediateOp_e
{
    MoveWideImmediateFixed = 0x12800000,
    MOVZ = 0x40000000,
    MOVK = 0x60000000,
};
typedef enum MoveWideImmediateOp_e MoveWideImmediateOp;

enum AddrMode_e { Offset, PreIndex, PostIndex };
typedef enum AddrMode_e AddrMode;

enum LoadStoreUnsignedOffset
{
    LoadStoreUnsignedOffsetFixed = 0x39000000,
};

// Load/store
enum LoadStoreOp_e
{
    STR_x = ( ( 0b11 & ( ( 1 << 2 ) - 1 ) ) << 30 ) | ( ( 0 & ( ( 1 << 1 ) - 1 ) ) << 26 ) | ( ( 0b00 & ( ( 1 << 2 ) - 1 ) ) << 22 ),
    LDR_x = ( ( 0b11 & ( ( 1 << 2 ) - 1 ) ) << 30 ) | ( ( 0 & ( ( 1 << 1 ) - 1 ) ) << 26 ) | ( ( 0b01 & ( ( 1 << 2 ) - 1 ) ) << 22 ),
};
typedef enum LoadStoreOp_e LoadStoreOp;

typedef enum {
    kNoAccess = 0,
    kRead = 1,
    kWrite = 2,
    kExecute = 4
} MemoryPermission;

#endif // __ENUMS_H__