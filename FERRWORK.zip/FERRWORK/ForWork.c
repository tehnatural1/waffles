
#include <stdint.h>

#include <mach-o/dyld.h>
#include <mach-o/nlist.h>
#include <mach-o/dyld_images.h>

#include <sys/mman.h>
#include <sys/stat.h>
#include <inttypes.h>

#include <CoreFoundation/CoreFoundation.h>
#include <AudioToolbox/AudioUnit.h>

#include "utility/utility.h"
#include "utility/error.h"
#include "utility/debug.h"
#include "dyld_cache_format.h"
// #include "dobby.h"
// #include "this.h"

#if defined( __LP64__ )
    typedef struct mach_header_64       mach_header_t;
    typedef struct segment_command_64   segment_command_t;
    typedef struct section_64           section_t;
    typedef struct nlist_64             nlist_t;

    #define LC_SEGMENT_ARCH_DEPENDENT   LC_SEGMENT_64
#else
    typedef struct mach_header          mach_header_t;
    typedef struct segment_command      segment_command_t;
    typedef struct section              section_t;
    typedef struct nlist                nlist_t;

    #define LC_SEGMENT_ARCH_DEPENDENT   LC_SEGMENT
#endif

//------------------------------------------------------------------------------
//  DEFINITIONS
//------------------------------------------------------------------------------

#define ARRAY_LENGTH( ARRAY )           ( sizeof( ARRAY ) / sizeof( ARRAY[ 0 ] ) )
#define EXPORTED_API                    __attribute__(( visibility( "default" ) ))

#define SYMBOLS_FILE_EXTENSION          ".symbols"
#define MAX_SEGMENT_COUNT               64
#define OPTIONAL
#define UNUSED_PARAMETER( PARAMETER )   (void) PARAMETER

//------------------------------------------------------------------------------
//  DYNAMICALLY LINKED EXTERNAL METHODS
//------------------------------------------------------------------------------

#ifdef __cplusplus
extern "C" {
#endif

extern
const char*
    dyld_shared_cache_file_path
    (

    );

extern
int
    __shared_region_check_np
    (
        uint64_t*               StartAddress
    );

extern
kern_return_t
    mach_vm_write
    (
        vm_map_t                TargetTask,
        mach_vm_address_t       Address,
        vm_offset_t             Data,
        mach_msg_type_number_t  DataCount
    );

extern
kern_return_t
    mach_vm_allocate
    (
        vm_map_t                Target,
        mach_vm_address_t*      Address,
        mach_vm_size_t          Size,
        int                     Flags
    );

extern
kern_return_t
    mach_vm_protect
    (
        vm_map_t                TargetTask,
        mach_vm_address_t       Address,
        mach_vm_size_t          Size,
        boolean_t               SetMaximum,
        vm_prot_t               NewProtection
    );

extern
kern_return_t
    mach_vm_deallocate
    (
        vm_map_t                Target,
        mach_vm_address_t       Address,
        mach_vm_size_t          Size
    );

#ifdef __cplusplus
}
#endif


//------------------------------------------------------------------------------
//  DATA STRUCTURES
//------------------------------------------------------------------------------

typedef struct dyld_cache_header                    dyld_cache_header_t;
typedef struct dyld_cache_mapping_info              dyld_cache_mapping_info_t;
typedef struct dyld_all_image_infos                 dyld_all_image_infos_t;
typedef struct dyld_cache_local_symbols_info        dcls_info_t;
typedef struct dyld_cache_local_symbols_entry_64    dcls_entry_64_t;
typedef struct dyld_cache_local_symbols_entry       dcls_entry_t;
typedef struct load_command                         load_command_t;
typedef struct symtab_command                       symtab_command_t;
typedef struct dysymtab_command                     dysymtab_command_t;
typedef struct dyld_info_command                    dyld_info_command_t;
typedef struct linkedit_data_command                linkedit_data_command_t;

typedef struct
shared_cache_ctx
{
    //
    // CACHES
    //
    dyld_cache_header_t*        RuntimeSharedCache;
    dyld_cache_header_t*        MmapSharedCache;

    //
    // ASLR
    //
    uintptr_t                   RuntimeSlide;
    bool                        IsLatestFormat;

    //
    // SYMBOLS
    //
    dcls_info_t*                LocalSymbolsInfo;
    dcls_entry_t*               LocalSymbolsEntries;
    dcls_entry_64_t*            LocalSymbolsEntries64;

    //
    // TABLES
    //
    nlist_t*                    SymbolTable;
    char*                       StringTable;

} shared_cache_ctx_t;

typedef struct
macho_ctx_t
{
    bool                        IsRuntimeMode;

    //
    // HEADERS
    //
    mach_header_t*              Header;
    mach_header_t*              CacheHeader;

    //
    // VIRTUAL ADDRESS REGION INFO
    //
    uintptr_t                   LoadVmAddr;
    size_t                      VmSize;
    uintptr_t                   VmRegionStart;
    uintptr_t                   VmRegionEnd;

    //
    // ADDRESS SLIDES
    //
    uintptr_t                   Slide;
    uintptr_t                   LinkedItBase;

    //
    // SEGMENT COMMANDS
    //
    segment_command_t*          Segments[ MAX_SEGMENT_COUNT ];
    int                         SegmentsCount;
    segment_command_t*          TextSegment;
    segment_command_t*          DataSegment;
    segment_command_t*          TextExecSegment;
    segment_command_t*          DataConstSegment;
    segment_command_t*          LinkedItSegment;

    //
    // LOAD COMMANDS
    //
    symtab_command_t*           SymbolTableCommand;     // LC_SYMTAB
    dysymtab_command_t*         DySymbolTableCommand;   // LC_DYSYMTAB
    dyld_info_command_t*        DyldInfoCommand;        // LC_DYLD_INFO or LC_DYLD_INFO_ONLY
    linkedit_data_command_t*    ExportsTrieCommand;     // LC_DYLD_EXPORTS_TRIE
    linkedit_data_command_t*    ChainedFixupsCommand;   // LC_DYLD_CHAINED_FIXUPS
    linkedit_data_command_t*    CodeSignatureCommand;   // LC_CODE_SIGNATURE

    //
    // TABLES
    //
    nlist_t*                    SymbolTable;
    char*                       StringTable;
    uint32_t*                   IndirectSymbolTable;

} macho_ctx_t;

//------------------------------------------------------------------------------
//  PROTOTYPES
//------------------------------------------------------------------------------

static
ErrorStatus
    GetSharedCacheBaseAddress
    (
        OUT         dyld_cache_header_t**       LoadAddress
    );

static
ErrorStatus
    InitializeSharedCacheContext
    (
        IN  OUT     shared_cache_ctx_t*         Context
    );

static
ErrorStatus
    MapFileOffsetToBuffer
    (
        IN          size_t                      MapSize,
        IN          off_t                       MapOffset,
        IN          const char*                 MapFile,
        OUT         uint8_t**                   MmapBuffer
    );

static
ErrorStatus
    MapSharedCacheToBuffer
    (
        IN          const char*                 MapFile,
        IN  OUT     uint8_t**                   MmapBuffer
    );

static
ErrorStatus
    LoadSymbolsFromSharedCache
    (
        IN          shared_cache_ctx_t*         Context
    );

//------------------------------------------------------------------------------
//  PRIVATE FUNCTIONS
//------------------------------------------------------------------------------

static
ErrorStatus
    GetSharedCacheBaseAddress
    (
        OUT         dyld_cache_header_t**       BaseAddress
    )
{
    ErrorStatus                 retVal              = ERROR_FAILURE;
    uintptr_t                   shared_cache_base   = 0;
    task_dyld_info_data_t       task_dyld_info      = { 0 };
    mach_msg_type_number_t      count               = TASK_DYLD_INFO_COUNT;
    kern_return_t               task_info_status    = KERN_FAILURE;
    dyld_all_image_infos_t*     all_image_infos     = NULL;

    __VERIFY_PARAM( BaseAddress )

    // Attempt to get shared cache base. Failure is OK.
    if( 0 != __shared_region_check_np( (uint64_t*) &shared_cache_base ) )
    {
        DEBUGL( LOG_LEVEL_WARNING, "__shared_region_check_np() Failed. Attempting task resolve.\n" );
    }

    // If base was collected nothing to do
    if( shared_cache_base )
    {
        *BaseAddress    = (dyld_cache_header_t*) shared_cache_base;
        retVal          = ERROR_SUCCESS;
    }
    else {
        // task info
        if( KERN_SUCCESS != ( task_info_status = task_info( mach_task_self(),
                                                            TASK_DYLD_INFO,
                                                            (task_info_t) &task_dyld_info,
                                                            &count ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR,
                    "task_info() Failed. retVal: %d\n",
                    task_info_status );
            retVal = ERROR_TASK_INFO;
        }
        else {
            // get dyld load address
            all_image_infos = (dyld_all_image_infos_t*) task_dyld_info.all_image_info_addr;
            *BaseAddress    = (dyld_cache_header_t*) all_image_infos->sharedCacheBaseAddress;
            retVal          = ERROR_SUCCESS;
        } // task_info()
    } // shared_cache_base

    __DEBUG_RETVAL( retVal )
    return retVal;
}

static
ErrorStatus
    InitializeSharedCacheContext
    (
        IN  OUT     shared_cache_ctx_t*         Context
    )
{
    ErrorStatus                     retVal                  = ERROR_FAILURE;
    dyld_cache_header_t*            runtime_shared_cache    = NULL;
    dyld_cache_mapping_info_t*      mappings                = NULL;
    uintptr_t                       slide                   = 0;

    __VERIFY_PARAM( Context )

    // Always scrub the shared cache context
    memset( Context,
            0,
            sizeof( shared_cache_ctx_t ) );

    if( ERROR_SUCCESS != ( retVal = GetSharedCacheBaseAddress( &runtime_shared_cache ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "GetSharedCacheBaseAddress() Failed\n" );
    }
    else {
        // Update shared cache pointer
        Context->RuntimeSharedCache = runtime_shared_cache;

        // Shared cache slide
        mappings    = (dyld_cache_mapping_info_t*)( (char*) runtime_shared_cache + runtime_shared_cache->mappingOffset );
        slide       = (uintptr_t) runtime_shared_cache - (uintptr_t) ( mappings[ 0 ].address );

        // Update known slide
        Context->RuntimeSlide = slide;
    } // GetSharedCacheBaseAddress()

    __DEBUG_RETVAL( retVal )
    return retVal;
}

static
ErrorStatus
    MapFileOffsetToBuffer
    (
        IN          size_t                      MapSize,
        IN          off_t                       MapOffset,
        IN          const char*                 MapFile,
        OUT         uint8_t**                   MmapBuffer
    )
{
    ErrorStatus     retVal              = ERROR_FAILURE;
    int             file_descriptor     = -1;

    __VERIFY_PARAM( MapFile, MmapBuffer )

    // Open file
    if( 0 > ( file_descriptor = open( MapFile,
                                      O_RDONLY,
                                      0 ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "open() Failed\n" );
        retVal = ERROR_FILE_IO;
    }
    else {
        // Map to the buffer
        if( MAP_FAILED == ( *MmapBuffer = (uint8_t *) mmap( 0,
                                                            MapSize,
                                                            PROT_READ | PROT_WRITE,
                                                            MAP_PRIVATE,
                                                            file_descriptor,
                                                            MapOffset ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "mmap() Failed\n" );
            // Set failure
            *MmapBuffer = NULL;
            retVal      = ERROR_MEMORY_MAPPING;
        }
        else {
            // Success
            retVal = ERROR_SUCCESS;
        } // mmap()

        close( file_descriptor );
    } // open()

    __DEBUG_RETVAL( retVal )
    return retVal;
}

static
ErrorStatus
    MapSharedCacheToBuffer
    (
        IN          const char*                 MapFile,
        IN  OUT     uint8_t**                   MmapBuffer
    )
{
    ErrorStatus     retVal          = ERROR_FAILURE;
    struct stat     file_stat       = { 0 };
    int             stat_code       = 0;

    __VERIFY_PARAM( MapFile, MmapBuffer )

    // Stat file to map
    if( 0 != ( stat_code = stat( MapFile, &file_stat ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "stat() Failed\n" );
        retVal = ERROR_FILE_IO;
    }
    else {
        // Map the file
        retVal = MapFileOffsetToBuffer( file_stat.st_size,
                                        0,
                                        MapFile,
                                        MmapBuffer );
    } // stat()

    __DEBUG_RETVAL( retVal )
    return retVal;
}

static
ErrorStatus
    LoadSymbolsFromSharedCache
    (
        IN          shared_cache_ctx_t*         Context
    )
{
    ErrorStatus     retVal                                  = ERROR_SUCCESS;
    uint64_t        localSymbolsOffset                      = 0;
    char*           shared_cache_path                       = NULL;
    char            shared_cache_symbols_path[ PATH_MAX ]   = { 0 };
    uint8_t*        mmBuffer                                = NULL;

    __VERIFY_PARAM( Context )

    // Assume latest and get proven wrong
    Context->IsLatestFormat = true;

    // Get shared cache file path
    if( NULL == ( shared_cache_path = (char*)dyld_shared_cache_file_path() ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "dyld_shared_cache_file_path() Failed\n" );
        // Fail
        retVal = ERROR_CACHED_LOCATION;
    }
    else {
        (void) strncat( shared_cache_symbols_path,
                        shared_cache_path,
                        PATH_MAX );
        (void) strncat( shared_cache_symbols_path,
                        SYMBOLS_FILE_EXTENSION,
                        sizeof( SYMBOLS_FILE_EXTENSION ) );

        // Attempt to map .symbols
        if( ERROR_SUCCESS != ( retVal = MapSharedCacheToBuffer( shared_cache_symbols_path, &mmBuffer ) ) )
        {
            DEBUGL( LOG_LEVEL_NOTICE,
                    "Failed to map '%s'. Assuming iOS < 15.0.",
                    shared_cache_symbols_path );

            // Ensure shared cache can be mapped
            if( 0 == Context->RuntimeSharedCache->localSymbolsSize )
            {
                DEBUGL( LOG_LEVEL_CRITICAL, "Context->RuntimeSharedCache->localSymbolsSize Invalid.\n" );
                retVal = ERROR_SYMBOL_SIZE;
            }
            else {
                // Attempt to map the shared cache
                if( ERROR_SUCCESS != ( retVal = MapFileOffsetToBuffer ( Context->RuntimeSharedCache->localSymbolsSize,
                                                                        Context->RuntimeSharedCache->localSymbolsOffset,
                                                                        shared_cache_path,
                                                                        &mmBuffer ) ) )
                {
                    DEBUGL( LOG_LEVEL_ERROR, "MapFileOffsetToBuffer() Failed.\n" );
                }
                else {
                    Context->MmapSharedCache = (dyld_cache_header_t*)
                        ( (uintptr_t) mmBuffer - Context->RuntimeSharedCache->localSymbolsOffset );

                    localSymbolsOffset          = Context->RuntimeSharedCache->localSymbolsOffset;
                    Context->IsLatestFormat     = false;
                } // MapFileOffsetToBuffer()
            } // Context->RuntimeSharedCache->localSymbolsSize
        }
        else
        {
            DEBUGL( LOG_LEVEL_NOTICE, "MapSharedCacheToBuffer() Succeeded. Assuming iOS >= 15.0\n" );
            // iOS >= 15.0
            Context->MmapSharedCache    = (dyld_cache_header_t*)mmBuffer;
            localSymbolsOffset          = Context->MmapSharedCache->localSymbolsOffset;
        } // MapSharedCacheToBuffer()

        if( ERROR_SUCCESS == retVal )
        {
            Context->LocalSymbolsInfo = (dcls_info_t*)
                ( (char*)Context->MmapSharedCache + localSymbolsOffset );

            if( true == Context->IsLatestFormat )
            {
                Context->LocalSymbolsEntries64 = (dcls_entry_64_t*)
                    ( (char*)Context->LocalSymbolsInfo + Context->LocalSymbolsInfo->entriesOffset );
            }
            else {
                Context->LocalSymbolsEntries = (dcls_entry_t*)
                    ( (char*)Context->LocalSymbolsInfo + Context->LocalSymbolsInfo->entriesOffset );
            }

            Context->SymbolTable = (nlist_t*)( (char*)Context->LocalSymbolsInfo + Context->LocalSymbolsInfo->nlistOffset );
            Context->StringTable = ( (char*)Context->LocalSymbolsInfo ) + Context->LocalSymbolsInfo->stringsOffset;
        } // ERROR_SUCCESS == retVal
    } // dyld_shared_cache_file_path()

    __DEBUG_RETVAL( retVal )
    return retVal;
}

static
ErrorStatus
    IsAddressInSharedCache
    (
        IN          shared_cache_ctx_t*         Context,
        IN          uintptr_t                   Address
    )
{
    ErrorStatus             retVal                  = ERROR_FAILURE;
    dyld_cache_header_t*    runtime_shared_cache    = NULL;
    uintptr_t               region_start            = 0;
    uintptr_t               region_end              = 0;

    __DEBUG_FUNCTION_START__

    if( Context )
    {
        runtime_shared_cache = Context->RuntimeSharedCache;
    }
    else
    {
        (void)GetSharedCacheBaseAddress( &runtime_shared_cache );
    }

    region_start    = runtime_shared_cache->sharedRegionStart + Context->RuntimeSlide;
    region_end      = region_start + runtime_shared_cache->sharedRegionSize;

    retVal          = ( ( ( Address >= region_start ) && ( Address < region_end ) )
                        ? ERROR_SUCCESS
                        : ERROR_NOT_FOUND );

    __DEBUG_RETVAL( retVal )
    return retVal;
}

static
ErrorStatus
    LoadSymbolTableFromSharedCache
    (
        IN          shared_cache_ctx_t*         Context,
        IN          mach_header_t*              ImageHeader,
        OUT         nlist_t**                   SymbolTable,
        OUT         uint32_t*                   SymbolTableCount,
        OUT         char**                      StringTable
    )
{
    ErrorStatus     retVal              = ERROR_FAILURE;
    uint64_t        offset_in_cache     = 0;
    nlist_t*        localNlists         = NULL;
    uint32_t        localNlistCount     = 0;
    char*           localStrings        = NULL;
    uint32_t        entry_itr           = 0;
    uint32_t        localNlistStart     = 0;

    __VERIFY_PARAM( Context,
                    ImageHeader,
                    SymbolTable,
                    SymbolTableCount,
                    StringTable )

    retVal          = ERROR_NOT_FOUND;
    offset_in_cache = (uint64_t)ImageHeader - (uint64_t)Context->RuntimeSharedCache;

    // Iterate over each entry
    for( entry_itr = 0;
        ( entry_itr < Context->LocalSymbolsInfo->entriesCount ) &&
        ( ERROR_NOT_FOUND == retVal );
        ++entry_itr )
    {
        // Determine Shared Cache Format
        if( true == Context->IsLatestFormat )
        {
            if( Context->LocalSymbolsEntries64[ entry_itr ].dylibOffset == offset_in_cache )
            {
                localNlistStart = Context->LocalSymbolsEntries64[ entry_itr ].nlistStartIndex;
                localNlistCount = Context->LocalSymbolsEntries64[ entry_itr ].nlistCount;
                localNlists     = &Context->SymbolTable[ localNlistStart ];
                retVal          = ERROR_SUCCESS;
            }
        }
        else {
            if( Context->LocalSymbolsEntries[ entry_itr ].dylibOffset == offset_in_cache )
            {
                localNlistStart = Context->LocalSymbolsEntries[ entry_itr ].nlistStartIndex;
                localNlistCount = Context->LocalSymbolsEntries[ entry_itr ].nlistCount;
                localNlists     = &Context->SymbolTable[ localNlistStart ];
                retVal          = ERROR_SUCCESS;
            }
        } // Shared Cache Format
    } // for()

    *SymbolTable        = localNlists;
    *SymbolTableCount   = (uint32_t) localNlistCount;
    *StringTable        = (char *) Context->StringTable;

    __DEBUG_RETVAL( retVal )
    return retVal;
}

static
ErrorStatus
    FindSymbolAddressInSymbolTable
    (
        IN          char*               SymbolNamePattern,
        IN          nlist_t*            SymbolTable,
        IN          uint32_t            SymbolTableCount,
        IN          char*               StringTable,
        OUT         uintptr_t*          SymbolAddress
    )
{
    ErrorStatus     retVal              = ERROR_FAILURE;
    char*           symbol_name         = NULL;
    uint32_t        sym_tab_itr         = 0;

    __VERIFY_PARAM( SymbolNamePattern,
                    SymbolTable,
                    StringTable,
                    SymbolAddress )

    // Set inital
    *SymbolAddress  = 0;
    retVal          = ERROR_NOT_FOUND;

    // Iterate through symbol table
    for( sym_tab_itr = 0;
        ( sym_tab_itr <  SymbolTableCount ) &&
        ( 0           == *SymbolAddress   );
        sym_tab_itr++ )
    {
        // Only entries with a stab offset are interesting
        if( SymbolTable[ sym_tab_itr ].n_value )
        {
            symbol_name = StringTable + SymbolTable[ sym_tab_itr ].n_un.n_strx;

            // Symbol was exact match
            if( 0 == strcmp( SymbolNamePattern, symbol_name ) )
            {
                *SymbolAddress = SymbolTable[ sym_tab_itr ].n_value;
                retVal = ERROR_SUCCESS;
            }
            else if( ( '_' == symbol_name[ 0 ] ) &&
                     ( 0   == strcmp( SymbolNamePattern, &symbol_name[ 1 ] ) ) )
            {
                *SymbolAddress = SymbolTable[ sym_tab_itr ].n_value;
                retVal = ERROR_SUCCESS;
            } // strcmp()
        } // SymbolTable[ sym_tab_itr ].n_value
    } // for()

    __DEBUG_RETVAL( retVal )
    return retVal;
}



// #include <kern/cs_blobs.h>

// // iOS 1-14
// #define CSMAGIC_EMBEDDED_ENTITLEMENTS 0xfade7171
// // iOS 15+
// #define CSMAGIC_EMBEDDED_DER_ENTITLEMENTS 0xfade7172
// #define CSMAGIC_EMBEDDED_SIGNATURE 0xfade0cc0
// CSMAGIC_REQUIREMENT

typedef struct __BlobIndex
{
    uint32_t type;
    uint32_t offset;
} CS_Blob;

typedef struct CS_SuperBlob_s
{
    uint32_t    magic;
    uint32_t    length;
    uint32_t    count;
    CS_Blob     index[];
} CS_SuperBlob_t;

static
void
    DisplayCodeSig
    (
        macho_ctx_t*            Context,
        linkedit_data_command_t* LoadCommand
    )
{
    uintptr_t dataStart = (uintptr_t) Context->Header + LoadCommand->dataoff;

    CS_SuperBlob_t* superBlob = (CS_SuperBlob_t*)dataStart;
    if( ntohl( superBlob->magic ) != 0xfade0cc0 )
    {
        DEBUGL( LOG_LEVEL_ERROR, "INVALID SUPERBLOB :(\n" );
        return;
    }

    uint32_t count = ntohl( superBlob->count );
    for (int i = 0; i < count; i++)
    {
        uintptr_t blobBytes = dataStart + ntohl( superBlob->index[ i ].offset );
        uint32_t blobMagic = ntohl(*(uint32_t *)blobBytes);
        if( blobMagic != 0xfade7171 )
        {
            continue;
        }

        DEBUGL( LOG_LEVEL_INFO, "MATCHING BLOB FOUND!\n" );

        uint32_t blobLength = ntohl(*(uint32_t *)(blobBytes + 4));

        CFDataRef data = CFDataCreateWithBytesNoCopy( kCFAllocatorDefault, (blobBytes + 8), blobLength - 8, NULL );
        char* entitlements = CFDataGetBytePtr( data );

        DEBUGL( LOG_LEVEL_INFO, "Entitlements: %s\n", entitlements );
    }
}



static
ErrorStatus
    UpdateContextFromLoadCommand
    (
        IN          load_command_t*         LoadCommand,
        IN  OUT     macho_ctx_t*            Context
    )
{
    ErrorStatus             retVal              = ERROR_SUCCESS;
    segment_command_t*      curr_seg_cmd        = NULL;

    switch( LoadCommand->cmd )
    {
        case LC_SEGMENT_ARCH_DEPENDENT:
        {
            curr_seg_cmd = (segment_command_t*) LoadCommand;
            Context->Segments[ Context->SegmentsCount++ ] = curr_seg_cmd;

            if( !strcmp( curr_seg_cmd->segname, "__LINKEDIT" ) )
            {
                Context->LinkedItSegment = curr_seg_cmd;
            }
            else if( !strcmp( curr_seg_cmd->segname, "__DATA" ) )
            {
                Context->DataSegment = curr_seg_cmd;
            }
            else if( !strcmp( curr_seg_cmd->segname, "__DATA_CONST" ) )
            {
                Context->DataConstSegment = curr_seg_cmd;
            }
            else if( !strcmp( curr_seg_cmd->segname, "__TEXT" ) )
            {
                Context->TextSegment = curr_seg_cmd;
            }
            else if( !strcmp( curr_seg_cmd->segname, "__TEXT_EXEC" ) )
            {
                Context->TextExecSegment = curr_seg_cmd;
            }
            break;
        }

        case LC_SYMTAB:
        {
            Context->SymbolTableCommand = (symtab_command_t*) LoadCommand;
            break;
        }

        case LC_DYSYMTAB:
        {
            Context->DySymbolTableCommand = (dysymtab_command_t*) LoadCommand;
            break;
        }

        case LC_DYLD_INFO:
        case LC_DYLD_INFO_ONLY:
        {
            Context->DyldInfoCommand = (dyld_info_command_t*) LoadCommand;
            break;
        }

        case LC_DYLD_EXPORTS_TRIE:
        {
            Context->ExportsTrieCommand = (linkedit_data_command_t*) LoadCommand;
            break;
        }

        case LC_DYLD_CHAINED_FIXUPS:
        {
            Context->ChainedFixupsCommand = (linkedit_data_command_t*) LoadCommand;
            break;
        }

        case LC_CODE_SIGNATURE:
        {
            DisplayCodeSig( Context, LoadCommand );
            Context->CodeSignatureCommand = (linkedit_data_command_t*) LoadCommand;
            break;
        }

        default:
        {
            // Unhandle load command
            retVal = ERROR_UNHANDLED_DATA_TYPE;
            DEBUGL( LOG_LEVEL_WARNING,
                    "Unhandle Load Command: 0x%" PRIx8 "\n",
                    LoadCommand->cmd );
            break;
        }
    } // switch()

    return retVal;
}

static
ErrorStatus
    InitializeMachoContext
    (
        IN          mach_header_t*      MachHeader,
        IN          bool                RuntimeMode,
        IN          mach_header_t*      CacheHeader,
        IN  OUT     macho_ctx_t*        Context
    )
{
    ErrorStatus         retVal          = ERROR_SUCCESS;
    load_command_t*     curr_cmd        = NULL;
    segment_command_t*  seg_cmd         = NULL;
    uint32_t            macho_iter      = 0;

    __VERIFY_PARAM( MachHeader, Context )

    Context->Header         = MachHeader;
    Context->IsRuntimeMode  = RuntimeMode;
    Context->CacheHeader    = CacheHeader;

    curr_cmd = (load_command_t*)( (uintptr_t)MachHeader + sizeof( mach_header_t ) );

    for( macho_iter = 0; macho_iter < MachHeader->ncmds; macho_iter++ )
    {
        (void)UpdateContextFromLoadCommand( curr_cmd, Context );
        curr_cmd = (load_command_t*)( (uintptr_t)curr_cmd + curr_cmd->cmdsize );
    } // for()

    Context->Slide          = (uintptr_t)MachHeader
                            - (uintptr_t)Context->TextSegment->vmaddr;
    Context->LinkedItBase   = (uintptr_t)Context->Slide
                            + Context->LinkedItSegment->vmaddr
                            - Context->LinkedItSegment->fileoff;

    if( !RuntimeMode )
    {
        Context->LinkedItBase = (uintptr_t)( CacheHeader ? CacheHeader : MachHeader );
    }

    Context->VmRegionStart  = (uintptr_t)-1;
    Context->VmRegionEnd    = 0;

    for( macho_iter = 0; macho_iter < Context->SegmentsCount; macho_iter++ )
    {
        seg_cmd = Context->Segments[ macho_iter ];

        if( !strcmp( seg_cmd->segname, "__PAGEZERO" ) )
        {
            continue;
        }

        if( !strcmp( seg_cmd->segname, "__TEXT" ) )
        {
            Context->LoadVmAddr = seg_cmd->vmaddr;
        }

        // Update known memory region
        if( Context->VmRegionStart > seg_cmd->vmaddr )
        {
            Context->VmRegionStart = seg_cmd->vmaddr;
        }
        if( Context->VmRegionEnd < ( seg_cmd->vmaddr + seg_cmd->vmsize ) )
        {
            Context->VmRegionEnd = seg_cmd->vmaddr + seg_cmd->vmsize;
        }
    } // for()

    Context->VmSize = Context->VmRegionEnd - Context->VmRegionStart;

    if( Context->SymbolTableCommand )
    {
        Context->SymbolTable = (nlist_t*)( Context->LinkedItBase + Context->SymbolTableCommand->symoff );
        Context->StringTable = (char*)( Context->LinkedItBase + Context->SymbolTableCommand->stroff );
    }

    if( Context->DySymbolTableCommand )
    {
        Context->IndirectSymbolTable = (uint32_t*)( Context->LinkedItBase + Context->DySymbolTableCommand->indirectsymoff );
    }

    DEBUGL( LOG_LEVEL_INFO,
            "Header: %p: region: %" PRIuPTR
            " - %" PRIuPTR
            ", load_vmaddr: %" PRIuPTR
            ", vmsize: %zu, slide: %" PRIuPTR "\n",
            Context->Header,
            Context->VmRegionStart,
            Context->VmRegionEnd,
            Context->LoadVmAddr,
            Context->VmSize,
            Context->Slide );

    __DEBUG_RETVAL( retVal )
    return retVal;
}

static
ErrorStatus
    ResolveAddressWithSymbolTable
    (
        IN          macho_ctx_t*            Context,
        IN          const char*             SymbolNamePattern,
        IN OUT      uintptr_t*              SymbolAddress
    )
{
    ErrorStatus     retVal          = ERROR_FAILURE;
    char*           symbol_name     = NULL;
    uint32_t        symbol_itr      = 0;

    __VERIFY_PARAM( Context,
                    SymbolNamePattern,
                    SymbolAddress )

    // Set initial
    *SymbolAddress  = 0;
    retVal          = ERROR_NOT_FOUND;

    for( symbol_itr = 0;
        ( symbol_itr      <  Context->SymbolTableCommand->nsyms ) &&
        ( ERROR_NOT_FOUND == retVal                             );
        symbol_itr++ )
    {
        if( Context->SymbolTable[ symbol_itr ].n_value )
        {
            symbol_name = Context->StringTable + Context->SymbolTable[ symbol_itr ].n_un.n_strx;

            if( 0 == strcmp( SymbolNamePattern, symbol_name ) )
            {
                *SymbolAddress = Context->SymbolTable[ symbol_itr ].n_value;
                retVal = ERROR_SUCCESS;
            }
            else if( ( '_' == symbol_name[ 0 ]                               ) &&
                     ( 0   == strcmp( SymbolNamePattern, &symbol_name[ 1 ] ) ) )
            {
                *SymbolAddress = Context->SymbolTable[ symbol_itr ].n_value;
                retVal = ERROR_SUCCESS;
            } // strcmp()
        } // Context->symtab[ symbol_itr ].n_value
    } // for()

    __DEBUG_RETVAL( retVal )
    return retVal;
}

static
ErrorStatus
    ResolveAddressForSymbol
    (
        IN  OUT     macho_ctx_t*            Context,
        IN          const char*             SymbolName,
        IN          int                     type,
        IN  OUT     uintptr_t*              SymbolAddress
    )
{
    ErrorStatus retVal = ERROR_FAILURE;

    __VERIFY_PARAM( Context,
                    SymbolName,
                    SymbolAddress )

    // Set unused - resolving exported symbols will not be shared with work :)
    UNUSED_PARAMETER( type );

    if( ERROR_SUCCESS != ( retVal = ResolveAddressWithSymbolTable ( Context,
                                                                    SymbolName,
                                                                    SymbolAddress ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "ResolveAddressWithSymbolTable() Failed\n" );
    }
    else {
        // Update address with ASLR slide
        *SymbolAddress = *SymbolAddress + ( Context->IsRuntimeMode ? Context->Slide : 0 );
    } // ResolveAddressWithSymbolTable()

    __DEBUG_RETVAL( retVal )
    return retVal;
}


static
ErrorStatus
    ResolveWithSharedCache
    (
        IN          const char*             SymbolName,
        IN          const mach_header_t*    MachHeader,
        IN  OUT     uintptr_t*              FunctionAddress
    )
{
    ErrorStatus         retVal              = ERROR_FAILURE;
    nlist_t*            symbolTable         = NULL;
    uint32_t            symbolTableCount    = 0;
    char*               stringTable         = NULL;
    shared_cache_ctx_t  sc_context          = { 0 };

    __VERIFY_PARAM( SymbolName,
                    MachHeader,
                    FunctionAddress )

    // Init shared cache
    if( ERROR_SUCCESS != ( retVal = InitializeSharedCacheContext( &sc_context ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "InitializeSharedCacheContext() Failed\n" );
    }
    else {
        // Load symbols
        if( ERROR_SUCCESS != ( retVal = LoadSymbolsFromSharedCache( &sc_context ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "LoadSymbolsFromSharedCache() Failed\n" );
        }
        else {
            // Ensure shared cache was mapped
            if( NULL != sc_context.MmapSharedCache )
            {
                // Check if header falls in shared cache memory space
                if( ERROR_SUCCESS != ( retVal = IsAddressInSharedCache( &sc_context, (uintptr_t)MachHeader ) ) )
                {
                    DEBUGL( LOG_LEVEL_ERROR, "IsAddressInSharedCache() Failed\n" );
                }
                else {
                    // Get string and symbol table
                    retVal = LoadSymbolTableFromSharedCache( &sc_context,
                                                            (mach_header_t*)MachHeader,
                                                            &symbolTable,
                                                            &symbolTableCount,
                                                            &stringTable );
                } // IsAddressInSharedCache()
            } // shared_cache_ctx.MmapSharedCache

            // Ensure string and symbol table
            if( ( NULL != symbolTable ) &&
                ( NULL != stringTable ) )
            {
                // Get the address of the symbol
                if( ERROR_SUCCESS != ( retVal = FindSymbolAddressInSymbolTable( (char*)SymbolName,
                                                                                symbolTable,
                                                                                symbolTableCount,
                                                                                stringTable,
                                                                                FunctionAddress ) ) )
                {
                    DEBUGL( LOG_LEVEL_ERROR, "FindSymbolAddressInSymbolTable() Failed\n" );
                }
                else {
                    DEBUGL( LOG_LEVEL_INFO,
                            "Address: %" PRIuPTR ", Slide: %" PRIuPTR "\n",
                            *FunctionAddress,
                            sc_context.RuntimeSlide );

                    // Shift Address by the slide
                    *FunctionAddress = *FunctionAddress + sc_context.RuntimeSlide;
                } // FindSymbolAddressInSymbolTable()
            } // symbolTable && stringTable
        } // LoadSymbolsFromSharedCache()
    } // InitializeSharedCacheContext()

    __DEBUG_RETVAL( retVal )
    return retVal;
}

static
ErrorStatus
    ResolveWithSymbolTable
    (
        IN          const char*             SymbolName,
        IN          const mach_header_t*    MachHeader,
        IN  OUT     uintptr_t*              FunctionAddress
    )
{
    ErrorStatus     retVal          = ERROR_FAILURE;
    macho_ctx_t     machoContext    = { 0 };

    __VERIFY_PARAM( SymbolName,
                    MachHeader,
                    FunctionAddress )

    // Initialize the macho context
    if( ERROR_SUCCESS != ( retVal = InitializeMachoContext( (mach_header_t*) MachHeader,
                                                            true,
                                                            NULL,
                                                            &machoContext ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "InitializeMachoContext() Failed\n" );
    }
    else {
        retVal = ResolveAddressForSymbol( &machoContext,
                                          SymbolName,
                                          3, // OBFUSCATED AND NOT FOR WORK :)
                                          FunctionAddress );
    } // InitializeMachoContext()

    __DEBUG_RETVAL( retVal )
    return retVal;
}

static
ErrorStatus
    GetMachHeaderForSymbol
    (
        IN  OUT     mach_header_t**         MachHeader,
        IN          const char*             ImageName,          OPTIONAL
        OUT         uintptr_t*              Address,
        IN          const char*             SymbolName
    )
{
    ErrorStatus     retVal          = ERROR_FAILURE;
    uint32_t        image_count     = 0;
    uint32_t        image_itr       = 0;
    char*           image_name      = NULL;

    __VERIFY_PARAM( MachHeader,
                    Address,
                    SymbolName )

    // Set initial
    image_count     = _dyld_image_count();
    retVal          = ERROR_NOT_FOUND;
    *MachHeader     = NULL;

    // Attemp discovery
    for( image_itr = 0;
        ( image_itr       <  image_count ) &&
        ( ERROR_NOT_FOUND == retVal      );
        image_itr++ )
    {
        // Ensure an image name
        if( NULL == ( image_name = (char*) _dyld_get_image_name( image_itr ) ) )
        {
            continue;
        }

        // Ensure target image
        if( ( NULL != ImageName           ) &&
            ( NULL == strnstr( image_name,
                               ImageName,
                               PATH_MAX ) ) )
        {
            continue;
        }

        // Ensure macho header
        if( NULL == ( *MachHeader = (mach_header_t*) _dyld_get_image_header( image_itr ) ) )
        {
            continue;
        }

        // Attempt to resolve the memory address of the symbol
        if( ERROR_SUCCESS != ( retVal = ResolveWithSharedCache( SymbolName,
                                                                *MachHeader,
                                                                Address ) ) )
        {
            if( ERROR_SUCCESS == ( retVal = ResolveWithSymbolTable( SymbolName,
                                                                    *MachHeader,
                                                                    Address ) ) )
            {
                DEBUGL( LOG_LEVEL_DEBUG, "Found address in image: %s\n", image_name );
            } // ResolveWithSymbolTable()
        } // ResolveWithSharedCache()
    } // for()

    __DEBUG_RETVAL( retVal )
    return retVal;
}

//------------------------------------------------------------------------------
//  EXPORTED API
//------------------------------------------------------------------------------

EXPORTED_API
uintptr_t
    ResolveSymbol
    (
        IN          const char*         SymbolName,
        IN          const char*         ImageName       OPTIONAL
    )
{
    ErrorStatus     retVal          = ERROR_FAILURE;
    mach_header_t*  mach_header     = NULL;
    uintptr_t       memoryAddress   = 0;

    if( ERROR_SUCCESS != ( retVal = GetMachHeaderForSymbol( &mach_header,
                                                            ImageName,
                                                            &memoryAddress,
                                                            SymbolName ) ) )
    {
        memoryAddress = 0;
    } // GetMachHeaderForSymbol()

    return memoryAddress;
}


typedef int32_t
    ( *AudioUnitProcess_t )
    (
        AudioUnit                       inUnit,
        AudioUnitRenderActionFlags*     __nullable ioActionFlags,
        const AudioTimeStamp*           inTimeStamp,
        UInt32                          inNumberFrames,
        AudioBufferList*                ioData
    );

int main()
{
    ErrorStatus         retVal                  = ERROR_FAILURE;
    uintptr_t           memoryAddress           = 0;
    const char          framework_image[]       = "AudioToolboxCore";
    const char          symbol_name[]           = "AudioUnitProcess";

    __DEBUG_FUNCTION_START__

    memoryAddress = ResolveSymbol( symbol_name, NULL );

    // Ensure address was resolved
    if( 0 != memoryAddress )
    {
        DEBUGL( LOG_LEVEL_NOTICE,
                "Resolved Symbol: %" PRIuPTR "\n",
                memoryAddress );
        DEBUGL( LOG_LEVEL_NOTICE,
                "AudioUnitProcess: %" PRIuPTR "\n",
                (uintptr_t)( AudioUnitProcess ) );

        AudioUnit                       inUnit                  = NULL;
        AudioUnitRenderActionFlags*     ioActionFlags           = NULL;
        const AudioTimeStamp*           inTimeStamp             = NULL;
        AudioBufferList*                ioData                  = NULL;
        uint32_t                        inNumberFrames          = 0;
        OSStatus error_code = 0;

        error_code = ((AudioUnitProcess_t)memoryAddress)( inUnit,
                                                            ioActionFlags,
                                                            inTimeStamp,
                                                            inNumberFrames,
                                                            ioData );
        DEBUGL( LOG_LEVEL_NOTICE,
                "error_code: 0x%X\n",
                error_code );

    }

    DEBUGL( LOG_LEVEL_DEBUG, "exit\n" );
    return 0;
}

