#ifndef __RELOC_DATA_LABEL_H__
#define __RELOC_DATA_LABEL_H__

#include <stdint.h>
#include "PseudoLabel.h"

// Define the maximum size for data
#define MAX_DATA_SIZE 8

// RelocDataLabel structure
typedef struct RelocDataLabel {
    PseudoLabel label;
    uint8_t data_[MAX_DATA_SIZE];
    uint8_t data_size_;
} RelocDataLabel;

// Function prototypes
void RelocDataLabel_init(RelocDataLabel *relocDataLabel);
void RelocDataLabel_initWithData(RelocDataLabel *relocDataLabel, const void *data, size_t data_size);
void RelocDataLabel_fixupData(RelocDataLabel *relocDataLabel, const void *value, size_t value_size);
const void *RelocDataLabel_data(const RelocDataLabel *relocDataLabel);

#endif // __RELOC_DATA_LABEL_H__