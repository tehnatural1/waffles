#ifndef __ASSEMBLER_BASE_H__
#define __ASSEMBLER_BASE_H__

#include <stdio.h>
#include <stdint.h>
#include "CodeMemBuffer.h"
#include "RelocDataLabel.h"

typedef struct AssemblerBase {
    uintptr_t fixed_addr;
    CodeMemBuffer code_buffer_;
    RelocDataLabel **data_labels;
    size_t data_labels_size;
    size_t data_labels_capacity;
} AssemblerBase;

void AssemblerBase_init(AssemblerBase *assembler, uintptr_t fixed_addr);
size_t AssemblerBase_pc_offset(AssemblerBase *assembler);
void AssemblerBase_set_fixed_addr(AssemblerBase *assembler, uintptr_t in_fixed_addr);
CodeMemBuffer *AssemblerBase_code_buffer(AssemblerBase *assembler);
RelocDataLabel *AssemblerBase_createDataLabel(AssemblerBase *assembler, uint64_t data);
void AssemblerBase_bindLabel(AssemblerBase *assembler, void *label);
void AssemblerBase_relocDataLabels(AssemblerBase *assembler);

#endif // __ASSEMBLER_BASE_H__