#ifndef __UTILITY_H__
#define __UTILITY_H__

#include "debug.h"
#include "error.h"

#define IN
#define OUT

#define NULL_CHECK_PARAMETER( Parameter, ReturnCode )           \
    if( NULL == Parameter )                                     \
    {                                                           \
        DEBUGL( LOG_LEVEL_ERROR, #Parameter " is NULL\n" );     \
        return ReturnCode;                                      \
    }

#define VERIFY_PARAM__0__

#define VERIFY_PARAM__1__( Parameter ) \
    NULL_CHECK_PARAMETER( Parameter, ERROR_ARGUMENT_IS_NULL )

#define VERIFY_PARAM__2__( PARAM1, PARAM2 )     \
    VERIFY_PARAM__1__( PARAM1 )                 \
    VERIFY_PARAM__1__( PARAM2 )

#define VERIFY_PARAM__3__( Parameter, ... )     \
    VERIFY_PARAM__1__( Parameter )              \
    VERIFY_PARAM__2__( __VA_ARGS__ )

#define VERIFY_PARAM__4__( Parameter, ... )     \
    VERIFY_PARAM__1__( Parameter )              \
    VERIFY_PARAM__3__( __VA_ARGS__ )

#define VERIFY_PARAM__5__( Parameter, ... )     \
    VERIFY_PARAM__1__( Parameter )              \
    VERIFY_PARAM__4__( __VA_ARGS__ )

#define VERIFY_PARAM__6__( Parameter, ... )     \
    VERIFY_PARAM__1__( Parameter )              \
    VERIFY_PARAM__5__( __VA_ARGS__ )

#define VERIFY_PARAM__7__( Parameter, ... )     \
    VERIFY_PARAM__1__( Parameter )              \
    VERIFY_PARAM__6__( __VA_ARGS__ )

#define VERIFY_PARAM__8__( Parameter, ... )     \
    VERIFY_PARAM__1__( Parameter )              \
    VERIFY_PARAM__7__( __VA_ARGS__ )

#define VERIFY_PARAM__9__( Parameter, ... )     \
    VERIFY_PARAM__1__( Parameter )              \
    VERIFY_PARAM__8__( __VA_ARGS__ )

#define N_ARGS( ... )               \
    N_ARGS_HELPER1( __VA_ARGS__,    \
                    __9__,          \
                    __8__,          \
                    __7__,          \
                    __6__,          \
                    __5__,          \
                    __4__,          \
                    __3__,          \
                    __2__,          \
                    __1__,          \
                    __0__ )

#define N_ARGS_HELPER1( ... )       \
    N_ARGS_HELPER2( __VA_ARGS__ )

#define N_ARGS_HELPER2( x1,         \
                        x2,         \
                        x3,         \
                        x4,         \
                        x5,         \
                        x6,         \
                        x7,         \
                        x8,         \
                        x9,         \
                        n,          \
                        ... ) n

#define JOIN_PARAM_PARTS( PREFIX, POSTFIX )     \
    PREFIX ## POSTFIX

#define BUILD_VERIFY( PREFIX, POSTFIX )         \
    JOIN_PARAM_PARTS( PREFIX, POSTFIX )

#define __VERIFY_PARAMETER__( Parameter )       \
    VERIFY_PARAM__1__( Parameter )

#define __VERIFY_PARAMETERS__( ... )            \
    BUILD_VERIFY( VERIFY_PARAM, N_ARGS( __VA_ARGS__ ) )( __VA_ARGS__ );

#define __DEBUG_FUNCTION_ENTER__( ... )         \
    __DEBUG_FUNCTION_START__                    \
    BUILD_VERIFY( VERIFY_PARAM, N_ARGS( __VA_ARGS__ ) )( __VA_ARGS__ );

#define __VERIFY_PARAM( ... )                   \
    __DEBUG_FUNCTION_START__                    \
    BUILD_VERIFY( VERIFY_PARAM, N_ARGS( __VA_ARGS__ ) )( __VA_ARGS__ );

#endif