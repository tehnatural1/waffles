#ifndef __DEBUG_H__
#define __DEBUG_H__

#include <syslog.h>
#include <inttypes.h>
#include "utility/error.h"

#define LOG_LEVEL_EMERGENCY     LOG_EMERG       /* system is unusable */
#define LOG_LEVEL_ALERT         LOG_ALERT       /* action must be taken immediately */
#define LOG_LEVEL_CRITICAL      LOG_CRIT        /* critical conditions */
#define LOG_LEVEL_ERROR         LOG_ERR         /* error conditions */
#define LOG_LEVEL_WARNING       LOG_WARNING     /* warning conditions */
#define LOG_LEVEL_NOTICE        LOG_NOTICE      /* normal but significant condition */
#define LOG_LEVEL_INFO          LOG_INFO        /* informational */
#define LOG_LEVEL_DEBUG         LOG_DEBUG       /* debug-level messages */

#define LOG_DEFAULTS            ( LOG_CONS | LOG_PERROR | LOG_PID )
#define LOG_NAME                "No_Name"
#define RET_CODE_8X             "0x%08" PRIX8

#define DEBUGL( DEBUG_LEVEL,                    \
                FORMAT,                         \
                ARGUMENTS... )                  \
    do                                          \
    {                                           \
        openlog( LOG_NAME,                      \
                LOG_DEFAULTS,                   \
                LOG_USER );                     \
        syslog( DEBUG_LEVEL,                    \
                "%s[%d] -> %s(): " FORMAT,      \
                __FILE__,                       \
                __LINE__,                       \
                __FUNCTION__,                   \
                ##ARGUMENTS );                  \
        closelog();                             \
    }                                           \
    while( 0 );

#define DEBUG( ... )                            \
    DEBUGL( LOG_LEVEL_DEBUG, __VA_ARGS__ );

#define __DEBUG_FUNCTION_START__                \
    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

#define __DEBUG_FUNCTION_EXIT__                 \
    DEBUGL( LOG_LEVEL_DEBUG, "exit\n" );

#define __DEBUG_FUNCTION_END__( RETURN_CODE )   \
    DEBUGL( LOG_LEVEL_DEBUG,                    \
            "retVal: " RET_CODE_8X,             \
            RETURN_CODE );                      \
    return RETURN_CODE;

#define __DEBUG_RETVAL( RETURN_CODE )           \
    DEBUGL( LOG_LEVEL_DEBUG,                    \
            "retVal: " RET_CODE_8X " %s\n",     \
            RETURN_CODE,                        \
            ErrorString( RETURN_CODE ) );

static inline const char* ErrorString( int ErrorCode )
{
    switch( ErrorCode )
    {
        ERROR_STRINGS( ERROR_TEXT )
    } // switch()

    return "Unkown Erorr code!";
}

#endif