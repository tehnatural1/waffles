#ifndef __ERROR_H__
#define __ERROR_H__

#define ERROR_SUCCESS               ( 0x00000000 )
#define ERROR_FAILURE               ( 0xFFFFFFFF )

#define ERROR_ARGUMENT_IS_NULL      ( 0x00000010 )
#define ERROR_NOT_FOUND             ( 0x00000011 )
#define ERROR_MEM_ALLOC             ( 0x00000012 )
#define ERROR_UNHANDLED_DATA_TYPE   ( 0x00000013 )

#define ERROR_FILE_IO               ( 0x00000100 )
#define ERROR_CACHED_LOCATION       ( 0x00000101 )
#define ERROR_MEMORY_MAPPING        ( 0x00000102 )
#define ERROR_SYMBOL_SIZE           ( 0x00000103 )

#define ERROR_TASK_INFO             ( 0x00001000 )

#define ERROR_STRINGS( E )                                              \
    E( ERROR_SUCCESS,               "Success"                       )   \
    E( ERROR_FAILURE,               "Generic Error"                 )   \
    E( ERROR_ARGUMENT_IS_NULL,      "Null Argument"                 )   \
    E( ERROR_NOT_FOUND,             "Element not found"             )   \
    E( ERROR_MEM_ALLOC,             "Out of memory"                 )   \
    E( ERROR_UNHANDLED_DATA_TYPE,   "Unexpected data type"          )   \
    E( ERROR_FILE_IO,               "File I/O"                      )   \
    E( ERROR_CACHED_LOCATION,       "Invalid cache location"        )   \
    E( ERROR_MEMORY_MAPPING,        "Faied to map memory region"    )   \
    E( ERROR_SYMBOL_SIZE,           "Invliad symbol size"           )   \
    E( ERROR_TASK_INFO,             "Need to summarize"             )

#define ERROR_TEXT( NAME, TEXT ) case NAME: return #NAME " (" TEXT ")";

typedef int ErrorStatus;

#endif