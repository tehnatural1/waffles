
#ifdef __cplusplus
extern "C" {
#endif

int DoTheHook(void *address, void *fake_func, void **out_origin_func, uintptr_t datShitBrah);

#ifdef __cplusplus
}
#endif