#ifndef __SIMPLE_LINEAR_ALLOCATOR_H__
#define __SIMPLE_LINEAR_ALLOCATOR_H__

#include <stdint.h>
#include <stdio.h>

typedef struct simple_linear_allocator_t {
    uint8_t *buffer;
    uint32_t size;
    uint32_t capacity;
    uint32_t builtin_alignment;
} simple_linear_allocator_t;

void simple_linear_allocator_t_init(struct simple_linear_allocator_t *allocator, uint8_t *in_buffer, uint32_t in_capacity, uint32_t in_alignment);
uint8_t *simple_linear_allocator_t_alloc(struct simple_linear_allocator_t *allocator, uint32_t in_size, uint32_t in_alignment);
void simple_linear_allocator_t_free(struct simple_linear_allocator_t *allocator, uint8_t *buf);
uint8_t *simple_linear_allocator_t_cursor(struct simple_linear_allocator_t *allocator);

#endif // __SIMPLE_LINEAR_ALLOCATOR_H__