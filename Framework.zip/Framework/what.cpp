#include <stdint.h>
#include <string.h>
#include <iostream>

#define Rn(rn) (rn.code() << 5)
#define Rd(rd) (rd.code() << 0)
#define Rt(rt) (rt.code() << 0)
#define LeftShift(a, b, c) ((a & ((1 << b) - 1)) << c)
#define submask(x) ((1L << ((x) + 1)) - 1)
#define bits(obj, st, fn) (((obj) >> (st)) & submask((fn) - (st)))
#define set_bits(obj, st, fn, bits) obj = (((~(submask(fn - st) << st)) & obj) | (bits << st))

#define ALIGN ALIGN_FLOOR
#define ALIGN_FLOOR( ADDRESS, RANGE ) ( (uintptr_t)ADDRESS & ~( (uintptr_t)RANGE - 1 ) )

enum AddSubImmediateOp
{
    ADD_w_imm = 285212672,
    ADD_x_imm = -1862270976,
};

enum PCRelAddressingOp
{
    PCRelAddressingFixed      = 0x10000000,
    PCRelAddressingFixedMask  = 0x1F000000,
    PCRelAddressingMask       = 0x9F000000,
    ADR  = PCRelAddressingFixed | 0x00000000,
    ADRP = PCRelAddressingFixed | 0x80000000,
};

enum Shift { NO_SHIFT = -1, };
enum Extend { NO_EXTEND = -1, };

enum UnconditionalBranchToRegisterOp
{
    UnconditionalBranchToRegisterFixed = 0xD6000000,
    BR  = UnconditionalBranchToRegisterFixed | 0x001F0000,
    BLR = UnconditionalBranchToRegisterFixed | 0x003F0000,
};

enum LoadRegLiteralOp
{
    LoadRegLiteralFixed     = 0x18000000,
    LoadRegLiteralFixedMask = 0x3B000000,
    LDR_w_literal = LoadRegLiteralFixed | ( ( 0b00 & ( ( 1 << 2 ) - 1 ) ) << 30 ) | ( ( 0 & ( ( 1 << 1 ) - 1 ) ) << 26 ),
    LDR_x_literal = LoadRegLiteralFixed | ( ( 0b01 & ( ( 1 << 2 ) - 1 ) ) << 30 ) | ( ( 0 & ( ( 1 << 1 ) - 1 ) ) << 26 ),
    LDR_s_literal = LoadRegLiteralFixed | ( ( 0b00 & ( ( 1 << 2 ) - 1 ) ) << 30 ) | ( ( 1 & ( ( 1 << 1 ) - 1 ) ) << 26 ),
    LDR_d_literal = LoadRegLiteralFixed | ( ( 0b01 & ( ( 1 << 2 ) - 1 ) ) << 30 ) | ( ( 1 & ( ( 1 << 1 ) - 1 ) ) << 26 ),
    LDR_q_literal = LoadRegLiteralFixed | ( ( 0b10 & ( ( 1 << 2 ) - 1 ) ) << 30 ) | ( ( 1 & ( ( 1 << 1 ) - 1 ) ) << 26 ),
};

struct MemBuffer {
    uint8_t* buffer;
    uint32_t buffer_size;
    uint32_t buffer_capacity;

    MemBuffer() {
        buffer = (uint8_t *)operator new(64);
        buffer_size = 0;
        buffer_capacity = 64;
    }

    ~MemBuffer() {
        operator delete((void *)buffer);
    }

    MemBlock dup() {
        uint8_t *copy_buf = (uint8_t *)operator new(buffer_size);
        memcpy(copy_buf, buffer, buffer_size);
        return MemBlock((uintptr_t)copy_buf, buffer_size);
    }

    uint8_t *data() {
        return buffer;
    }

    uint32_t size() {
        return buffer_size;
    }

    void write(uint32_t offset, void *in_buffer, int size) {
        memcpy(this->buffer + offset, in_buffer, size);
    }

    void emit(void *in_buffer, int size) {
        ensure_capacity(size);
        write(buffer_size, in_buffer, size);
        buffer_size += size;
    }

    void ensure_capacity(int in_size) {
        if (buffer_size + in_size > buffer_capacity) {
            uint32_t new_capacity = buffer_capacity * 2;
            while (new_capacity < buffer_size + in_size) {
                new_capacity *= 2;
            }
            uint8_t *new_buffer = (uint8_t *)operator new(new_capacity);
            memcpy(new_buffer, buffer, buffer_size);
            operator delete(buffer);
            buffer = new_buffer;
            buffer_capacity = new_capacity;
        }
    }
};

struct CodeMemBuffer : MemBuffer {
    void EmitBuffer(uint8_t *buffer, uint32_t buffer_size) {
        emit(buffer, buffer_size);
    }

    template <typename T> void Emit(T value) {
        EmitBuffer((uint8_t *)&value, sizeof(value));
    }

    int32_t LoadInst(uint32_t offset) {
        return *reinterpret_cast<int32_t *>(data() + offset);
    }

    void RewriteInst(uint32_t offset, int32_t instr) {
        *reinterpret_cast<int32_t *>(data() + offset) = instr;
    }
};

struct Label {
    uintptr_t pos;
};

struct PseudoLabel : Label {
    struct ref_inst_t {
        int link_type;
        uintptr_t inst_offset;

        explicit ref_inst_t(int link_type, size_t inst_offset) : link_type(link_type), inst_offset(inst_offset) {
        }

        int type() {
            return link_type;
        }

        uintptr_t offset() {
            return inst_offset;
        }
    };

    CodeMemBuffer *code_buffer;
    std::vector<ref_inst_t> ref_insts;

    PseudoLabel() : PseudoLabel(0) {
    }

    PseudoLabel(uintptr_t pos) {
        bind_to(pos);
    }

    void bind_to(uintptr_t pos) {
        this->pos = pos;
    }

    bool has_confused_instructions() {
        return !ref_insts.empty();
    }

    void link_confused_instructions(CodeMemBuffer *buffer);

    void link_to(int link_type, uint32_t pc_offset) {
        ref_inst_t insn(link_type, pc_offset);
        ref_insts.push_back(insn);
    }
};

static inline uint32_t encode_imm19_offset(uint32_t instr, int64_t offset) {
    uint32_t imm19 = bits((offset >> 2), 0, 18);
    set_bits(instr, 5, 23, imm19);
    return instr;
}

inline void PseudoLabel::link_confused_instructions(CodeMemBuffer *buffer) {
    for (auto &ref_inst : ref_insts) {
        int64_t fixup_offset = pos - ref_inst.offset();

        uint32_t inst = buffer->LoadInst(ref_inst.offset());
        uint32_t new_inst = 0;

        if (ref_inst.link_type == 0) {
            new_inst = encode_imm19_offset(inst, fixup_offset);
        }

        buffer->RewriteInst(ref_inst.offset(), new_inst);
    }
}


struct RelocDataLabel : PseudoLabel {
    uint8_t data_[8];
    uint8_t data_size_;

    RelocDataLabel() {
        data_size_ = 0;
    }

    template <typename T> RelocDataLabel(T data) {
        *(T *)data_ = data;
        data_size_ = sizeof(T);
    }
};

struct AssemblerBase {
    uintptr_t fixed_addr;
    CodeMemBuffer code_buffer_;
    std::vector<RelocDataLabel *> data_labels;

    explicit AssemblerBase(uintptr_t fixed_addr) {
        this->fixed_addr = fixed_addr;
    }

    size_t pc_offset() {
        return code_buffer_.size();
    }

    CodeMemBuffer *code_buffer() {
        return &code_buffer_;
    }

    RelocDataLabel *createDataLabel(uint64_t data) {
        auto data_label = new RelocDataLabel(data);
        data_labels.push_back(data_label);
        return data_label;
    }

    void bindLabel(PseudoLabel *label) {
        label->bind_to(pc_offset());
        if (label->has_confused_instructions()) {
            label->link_confused_instructions(&code_buffer_);
        }
    }

    void relocDataLabels() {
        for (auto *data_label : data_labels) {
            bindLabel(data_label);
            code_buffer_.emit(data_label->data_, data_label->data_size_);
        }
    }
};

struct RegisterBase {
public:
    int reg_id;

    static constexpr RegisterBase from_code(int reg_id) {
        return RegisterBase{reg_id};
    }

    static constexpr RegisterBase no_reg() {
        return RegisterBase{0};
    }

    explicit constexpr RegisterBase(int code) : reg_id(code) {
    }

    bool operator==(const RegisterBase &other) const {
        return reg_id == other.reg_id;
    }

    int code() const {
        return reg_id;
    };
};

class CPURegister : RegisterBase {
public:
    enum RegisterType {
        kRegister_32,
        kRegister_W = kRegister_32,
        kRegister_64,
        kRegister_X = kRegister_64,
        kRegister,

        kVRegister,
        kSIMD_FP_Register_8,
        kSIMD_FP_Register_B = kSIMD_FP_Register_8,
        kSIMD_FP_Register_16,
        kSIMD_FP_Register_H = kSIMD_FP_Register_16,
        kSIMD_FP_Register_32,
        kSIMD_FP_Register_S = kSIMD_FP_Register_32,
        kSIMD_FP_Register_64,
        kSIMD_FP_Register_D = kSIMD_FP_Register_64,
        kSIMD_FP_Register_128,
        kSIMD_FP_Register_Q = kSIMD_FP_Register_128,

        kInvalid,
    };

    constexpr CPURegister( int code, int size, RegisterType type ) : RegisterBase(code), reg_size_(size), reg_type_(type) {
    }

    int32_t code() const {
        return reg_id;
    };

    bool Is64Bits() const {
        return reg_size_ == 64;
    }

    bool Is(const CPURegister &reg) const {
        return (reg.reg_id == this->reg_id);
    }

    static constexpr CPURegister InvalidRegister() {
        return CPURegister(0, 0, kInvalid);
    }

    static constexpr CPURegister X(int code) {
        return CPURegister(code, 64, kRegister_64);
    }

    RegisterType type() const {
        return reg_type_;
    }

private:
    RegisterType reg_type_;
    int reg_size_;
};

typedef CPURegister Register;

#define InvalidRegister CPURegister::InvalidRegister()

struct Operand {
    int64_t immediate_;
    Register reg_;

    Shift shift_;
    Extend extend_;
    int32_t shift_extend_imm_;

    inline explicit Operand(int64_t imm)
        : immediate_(imm), reg_(InvalidRegister), shift_(NO_SHIFT), extend_(NO_EXTEND), shift_extend_imm_(0) {
    }

    bool IsImmediate() const {
        return reg_.Is(InvalidRegister);
    }

    int64_t immediate() const {
        return immediate_;
    }
};


struct Assembler : AssemblerBase {
    Assembler(uintptr_t fixed_addr) : AssemblerBase(fixed_addr) {
    }

    void Emit(uint32_t value) {
        code_buffer_.Emit<uint32_t>(value);
    }

    void adrp(const Register &rd, int64_t imm) {
        uint32_t immlo = LeftShift(bits(imm >> 12, 0, 1), 2, 29);
        uint32_t immhi = LeftShift(bits(imm >> 12, 2, 20), 19, 5);
        Emit(ADRP | Rd(rd) | immlo | immhi);
    }

    void add(const Register &rd, const Register &rn, int64_t imm) {
        if (rd.Is64Bits() && rn.Is64Bits())
            AddSubImmediate(rd, rn, Operand(imm), ADD_x_imm );
        else
            AddSubImmediate(rd, rn, Operand(imm), ADD_w_imm );
    }

    void br(Register rn) {
        Emit(BR | Rn(rn));
    }

    void ldr(Register rt, int64_t imm) {
        LoadRegLiteralOp op;
        switch (rt.type()) {
            case CPURegister::kRegister_32:
                op = LDR_w_literal;
                break;
            case CPURegister::kRegister_X:
                op = LDR_x_literal;
                break;
            case CPURegister::kSIMD_FP_Register_S:
                op = LDR_s_literal;
                break;
            case CPURegister::kSIMD_FP_Register_D:
                op = LDR_d_literal;
                break;
            case CPURegister::kSIMD_FP_Register_Q:
                op = LDR_q_literal;
                break;
            default:
                printf( "THIS CODE SHOULD BE UNREACHABLE\n" );
                break;
        }
        EmitLoadRegLiteral(op, rt, imm);
    }

private:
    void EmitLoadRegLiteral(LoadRegLiteralOp op, CPURegister rt, int64_t imm) {
        const int32_t encoding = op | LeftShift(imm >> 2, 26, 5) | Rt(rt);
        Emit(encoding);
    }

    void AddSubImmediate(const Register &rd, const Register &rn, const Operand &operand, AddSubImmediateOp op) {
        if (operand.IsImmediate()) {
            int64_t immediate = operand.immediate();
            int32_t imm12 = LeftShift(immediate, 12, 10);
            Emit(op | Rd(rd) | Rn(rn) | imm12);
        } else {
            printf( "THIS CODE SHOULD BE UNREACHABLE\n" );
        }
    }
};

struct TurboAssembler : Assembler {
public:
    TurboAssembler() : TurboAssembler(0) {
    }

    TurboAssembler(uintptr_t fixed_addr) : Assembler(fixed_addr) {
    }

    void AdrpAdd(Register rd, uint64_t from, uint64_t to) {
        uint64_t from_PAGE = ALIGN(from, 0x1000);
        uint64_t to_PAGE = ALIGN(to, 0x1000);
        uint64_t to_PAGEOFF = (uint64_t)to % 0x1000;

        adrp(rd, to_PAGE - from_PAGE);
        add(rd, rd, to_PAGEOFF);
    }

    void Ldr(Register rt, PseudoLabel *label) {
        label->link_to(0, pc_offset());
        ldr(rt, 0);
    }
};

struct MemRange
{
    uintptr_t start_;
    size_t size;

    MemRange() : start_(0), size(0) {
    }

    MemRange( uintptr_t start, size_t size ) : start_(start), size(size) {
    }

    uintptr_t addr() const
    {
        return start_;
    }
};

struct MemBlock : MemRange {
    MemBlock() : MemRange() {
    }

    MemBlock(uintptr_t start, size_t size) : MemRange(start, size) {
    }
};

using CodeMemBlock = MemBlock;

struct Trampoline {
    int type;
    CodeMemBlock buffer;

    Trampoline *forward_trampoline;

    Trampoline() : type(0), buffer() {
    }

    Trampoline(int type, CodeMemBlock buffer) : type(type), buffer(buffer) {
    }

    Trampoline(int type, CodeMemBlock buffer, Trampoline *forward)
        : type(type), buffer(buffer), forward_trampoline(forward) {
    }

    uintptr_t addr() {
        return buffer.addr();
    }

    uintptr_t size() {
        return buffer.size;
    }

    uintptr_t forward_addr() {
        return forward_trampoline->addr();
    }

    uintptr_t forward_size() {
        return forward_trampoline->size();
    }
};

#define ARM64_TMP_REG_NDX_0 17
constexpr Register TMP_REG_0 = CPURegister::X( ARM64_TMP_REG_NDX_0 );

class CodeGenBase {
public:
    CodeGenBase(AssemblerBase *assembler) : assembler_(assembler) {
    }

protected:
    AssemblerBase *assembler_;
};

class CodeGen : public CodeGenBase {
public:
    CodeGen(TurboAssembler *turbo_assembler) : CodeGenBase(turbo_assembler) {
    }

    void LiteralLdrBranch(uint64_t address) {
        auto turbo_assembler_ = reinterpret_cast<TurboAssembler *>(this->assembler_);

        auto label = turbo_assembler_->createDataLabel(address);
        turbo_assembler_->Ldr(TMP_REG_0, label);
        turbo_assembler_->br(TMP_REG_0);
    }
};

Trampoline* GenerateNormalTrampolineBuffer(uintptr_t from, uintptr_t to) {
    // this->fixed_addr = from
    TurboAssembler turbo_assembler_(from);
    int tramp_type = 0;
    uint64_t distance = llabs((int64_t)(from - to));
    uint64_t adrp_range = UINT32_MAX - 1;
    if (distance < adrp_range) {
        tramp_type = 3;
        turbo_assembler_.AdrpAdd(TMP_REG_0, from, to);
        turbo_assembler_.br(TMP_REG_0);
    } else {
        tramp_type = 4;
        CodeGen codegen(&turbo_assembler_);
        codegen.LiteralLdrBranch((uint64_t)to);
    }

    // bind all labels
    turbo_assembler_.relocDataLabels();

    auto tramp_buffer = turbo_assembler_.code_buffer();
    auto tramp_block = tramp_buffer->dup();
    auto tramp = new Trampoline(tramp_type, tramp_block);
    return tramp;
}









using CodeMemBlock = MemBlock;

struct relo_ctx_t {
  uintptr_t cursor;
  uint32_t relocated_insn_count;

  CodeMemBlock *origin;
  CodeMemBlock relocated{};
  CodeMemBuffer *relocated_buffer;

  explicit relo_ctx_t(MemBlock *origin) : origin(origin) {
    cursor = origin->addr();
  }

  uint32_t preferred_relo_size() {
    return origin->size;
  }

  void correct_final_relo_size() {
    origin->resize(relo_size());
  }

  uint32_t relo_size() {
    return (uintptr_t)cursor - origin->addr();
  }

  uintptr_t origin_start() {
    return origin->addr();
  }

  uintptr_t origin_cursor() {
    return origin->addr() + relo_size();
  }

  uint32_t origin_off() {
    return (uintptr_t)cursor - origin->addr();
  }

  uintptr_t relocated_start() {
    return relocated.addr();
  }

  uintptr_t relocated_cursor() {
    return relocated.addr() + relocated_buffer->size();
  }

  uint32_t relocated_off() {
    return relocated_buffer->size();
  }

  void record_relo_start() {
    printf("relo: origin_off: %p, relocated_off: %p", origin_off(), relocated_off());
  }

  int relocate(bool branch);
};

void GenRelocateCode(void *buffer, CodeMemBlock *origin, CodeMemBlock *relocated, bool branch) {
  relo_ctx_t ctx(origin);
  ctx.relocate(branch);
  *relocated = ctx.relocated;
}

void GenRelocateCodeAndBranch(void *buffer, CodeMemBlock *origin, CodeMemBlock *relocated) {
  GenRelocateCode(buffer, origin, relocated, true);
}


struct InterceptRouting {
  Interceptor::Entry *entry = 0;
  Trampoline *trampoline = 0;
  Trampoline *near_trampoline = 0;
  int error = 0;

  explicit InterceptRouting(Interceptor::Entry *entry) : entry(entry) {
  }

  ~InterceptRouting() {
    if (trampoline) {
      // TODO: free code block
      delete trampoline;
    }
    if (near_trampoline) {
      // TODO: free code block
      delete near_trampoline;
    }
  }

  virtual void Prepare() {
  }
  virtual void DispatchRouting() {
  }
  void Commit() {
  }

  virtual addr_t TrampolineTarget() {
    printf( "THIS CODE SHOULD BE UNREACHABLE\n" );
    return -1;
  }

  addr_t trampoline_addr() {
    if (near_trampoline)
    {
      return near_trampoline->addr();
    }

    return trampoline->addr();
  }

  size_t trampoline_size() {
    if (near_trampoline)
      return near_trampoline->size();
    return trampoline->size();
  }

  virtual void Active() {
    auto ret = DobbyCodePatch((void *)entry->addr, (uint8_t *)trampoline_addr(), trampoline_size());
    error |= (ret != 0);
  }

  bool GenerateTrampoline() {
    addr_t from = entry->addr;
    addr_t to = TrampolineTarget();

    if (!near_trampoline) {
      trampoline = GenerateNormalTrampolineBuffer(from, to);
    }
    return true;
  }

  void GenerateRelocatedCode() {
    if (trampoline_addr() == 0) {
      error = 1;
    }

    auto code_addr = entry->addr;
    auto preferred_size = trampoline_size();
    auto origin = CodeMemBlock(code_addr, preferred_size);
    auto relocated = CodeMemBlock(0, 0);

    GenRelocateCodeAndBranch((void *)code_addr, &origin, &relocated);
    if (relocated.size == 0) {
      error = 1;
      return;
    }

    entry->patched = origin;
    entry->relocated = relocated;
  }

  void BackupOriginCode() {
    entry->backup_orig_code();
  }
};


int main()
{
    uintptr_t from = 0x1111FFFF;
    uintptr_t to = 0x2222EEEE;
    Trampoline* trampoline = GenerateNormalTrampolineBuffer(from, to);

    uintptr_t f_addr = trampoline->forward_addr();
    printf( "f_addr: %u\n", f_addr );
}

