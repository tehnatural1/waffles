#include "CodeMemBuffer.h"

CodeMemBuffer*
    CodeMemBuffer_create
    (
        void
    )
{
    CodeMemBuffer *code_buffer = malloc(sizeof(CodeMemBuffer));
    if (code_buffer == NULL)
    {
        // Handle memory allocation failure
        return NULL;
    }
    code_buffer->buffer = malloc(64); // Initial buffer size 64 bytes
    if (code_buffer->buffer == NULL)
    {
        // Handle memory allocation failure
        free(code_buffer);
        return NULL;
    }
    code_buffer->buffer_size = 0;
    code_buffer->buffer_capacity = 64;
    return code_buffer;
}

void
    CodeMemBuffer_destroy
    (
        CodeMemBuffer *code_buffer
    )
{
    if (code_buffer != NULL)
    {
        free(code_buffer->buffer);
        free(code_buffer);
    }
}

void
    CodeMemBuffer_emit
    (
        CodeMemBuffer *code_buffer,
        uint8_t *in_buffer,
        int size
    )
{
    // Ensure capacity
    if (code_buffer->buffer_size + size > code_buffer->buffer_capacity)
    {
        uint32_t new_capacity = code_buffer->buffer_capacity * 2;
        while (new_capacity < code_buffer->buffer_size + size)
        {
            new_capacity *= 2;
        }
        uint8_t *new_buffer = realloc(code_buffer->buffer, new_capacity);
        if (new_buffer == NULL)
        {
            // Handle memory allocation failure
            return;
        }
        code_buffer->buffer = new_buffer;
        code_buffer->buffer_capacity = new_capacity;
    }
    // Copy the input buffer into the code buffer
    memcpy(code_buffer->buffer + code_buffer->buffer_size, in_buffer, size);
    code_buffer->buffer_size += size;
}

int32_t
    CodeMemBuffer_load_inst
    (
        CodeMemBuffer *code_buffer,
        uint32_t offset
    )
{
    int32_t *instructions = (int32_t *)code_buffer->buffer;
    return instructions[offset / sizeof(int32_t)];
}

void
    CodeMemBuffer_rewrite_inst
    (
        CodeMemBuffer *code_buffer,
        uint32_t offset,
        int32_t new_inst
    )
{
    int32_t *instructions = (int32_t *)code_buffer->buffer;
    instructions[offset / sizeof(int32_t)] = new_inst;
}
