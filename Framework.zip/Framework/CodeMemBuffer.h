#ifndef __CODE_MEM_BUFFER_H__
#define __CODE_MEM_BUFFER_H__

#include <stdint.h>
#include <stdio.h>

typedef struct CodeMemBuffer {
    uint8_t *buffer;
    uint32_t buffer_size;
    uint32_t buffer_capacity;
} CodeMemBuffer;

CodeMemBuffer *CodeMemBuffer_create();
void CodeMemBuffer_destroy(CodeMemBuffer *code_buffer);
void CodeMemBuffer_emit(CodeMemBuffer *code_buffer, uint8_t *in_buffer, int size);
int32_t CodeMemBuffer_load_inst(CodeMemBuffer *code_buffer, uint32_t offset);
void CodeMemBuffer_rewrite_inst(CodeMemBuffer *code_buffer, uint32_t offset, int32_t new_inst);

#endif // __CODE_MEM_BUFFER_H__