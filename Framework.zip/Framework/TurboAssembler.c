#include "TurboAssembler.h"

TurboAssembler*
    TurboAssembler_create
    (
        uintptr_t fixed_addr
    )
{
    TurboAssembler *turbo_assembler = malloc(sizeof(TurboAssembler));
    if (turbo_assembler == NULL) {
        // Handle memory allocation failure
        return NULL;
    }
    turbo_assembler->fixed_addr = fixed_addr;
    turbo_assembler->code_buffer = CodeMemBuffer_create();
    if (turbo_assembler->code_buffer == NULL) {
        // Handle memory allocation failure
        free(turbo_assembler);
        return NULL;
    }
    turbo_assembler->data_labels = NULL;
    turbo_assembler->data_labels_count = 0;
    return turbo_assembler;
}

void
    TurboAssembler_destroy
    (
        TurboAssembler *turbo_assembler
    )
{
    if (turbo_assembler != NULL) {
        CodeMemBuffer_destroy(turbo_assembler->code_buffer);
        for (size_t i = 0; i < turbo_assembler->data_labels_count; ++i) {
            PseudoLabel_destroy(&turbo_assembler->data_labels[i]);
        }
        free(turbo_assembler->data_labels);
        free(turbo_assembler);
    }
}

void
    TurboAssembler_emit_buffer
    (
        TurboAssembler *turbo_assembler,
        uint8_t *buffer,
        uint32_t buffer_size
    )
{
    CodeMemBuffer_emit(turbo_assembler->code_buffer, buffer, buffer_size);
}

void
    TurboAssembler_emit
    (
        TurboAssembler *turbo_assembler,
        uint32_t value
    )
{
    CodeMemBuffer_emit(turbo_assembler->code_buffer, (uint8_t *)&value, sizeof(value));
}

void
    TurboAssembler_adrp_add
    (
        TurboAssembler *turbo_assembler,
        Register* rd,
        uint64_t from,
        uint64_t to
    )
{
    uint64_t from_PAGE = ALIGN(from, 0x1000);
    uint64_t to_PAGE = ALIGN(to, 0x1000);
    uint64_t to_PAGEOFF = to % 0x1000;

    adrp(rd, to_PAGE - from_PAGE, turbo_assembler->code_buffer);
    add(rd, rd, to_PAGEOFF, turbo_assembler->code_buffer);
}

void
    TurboAssembler_ldr
    (
        TurboAssembler *turbo_assembler,
        Register* rt,
        PseudoLabel *label
    )
{
    PseudoLabel_link_to(label,
                        0,
                        turbo_assembler->code_buffer->buffer_size);
    ldr(rt,
        0,
        turbo_assembler->code_buffer);
}

void
    TurboAssembler_relocDataLabels
    (
        TurboAssembler *turbo_assembler
    )
{
    // Iterate through all data labels
    for (size_t i = 0; i < turbo_assembler->data_labels_count; ++i) {
        // Bind the label
        PseudoLabel_bind_to(&turbo_assembler->data_labels[i], turbo_assembler->code_buffer->buffer_size);

        // Link confused instructions
        PseudoLabel_link_confused_instructions(&turbo_assembler->data_labels[i], turbo_assembler->code_buffer);

        // Emit the label's data into the code buffer
        uintptr_t label_addr = turbo_assembler->data_labels[i].pos;
        CodeMemBuffer_emit(turbo_assembler->code_buffer, (uint8_t*)&label_addr, sizeof(label_addr));
    }
}

