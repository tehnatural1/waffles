
#include "PseudoLabel.h"

PseudoLabel*
    PseudoLabel_create
    (
        uintptr_t pos
    )
{
    PseudoLabel* label = malloc(sizeof(PseudoLabel));
    if (label == NULL) {
        // Handle memory allocation failure
        return NULL;
    }
    label->pos = pos;
    label->ref_insts = NULL;
    label->ref_insts_count = 0;
    return label;
}

void
    PseudoLabel_destroy
    (
        PseudoLabel* label
    )
{
    if( NULL != label )
    {
        free(label->ref_insts);
        free(label);
    }
}

void
    PseudoLabel_link_to
    (
        PseudoLabel* label,
        int link_type,
        size_t pc_offset
    )
{
    label->ref_insts_count++;
    label->ref_insts = realloc(label->ref_insts, label->ref_insts_count * sizeof(ref_inst_t));

    if( NULL == label->ref_insts )
    {
        // Handle memory allocation failure
        return;
    }

    label->ref_insts[ label->ref_insts_count - 1 ].link_type    = link_type;
    label->ref_insts[ label->ref_insts_count - 1 ].inst_offset  = pc_offset;
}

void
    PseudoLabel_link_confused_instructions
    (
        PseudoLabel* label,
        CodeMemBuffer* buffer
    )
{
    for( size_t i = 0; i < label->ref_insts_count; ++i )
    {
        int64_t fixup_offset = label->pos - label->ref_insts[i].inst_offset;

        uint32_t inst = CodeMemBuffer_load_inst(buffer, label->ref_insts[i].inst_offset);
        uint32_t new_inst = 0;

        if (label->ref_insts[i].link_type == 0) {
            new_inst = encode_imm19_offset(inst, fixup_offset);
        }

        CodeMemBuffer_rewrite_inst(buffer, label->ref_insts[i].inst_offset, new_inst);
    }
}
