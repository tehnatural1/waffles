#ifndef __TURBO_ASSEMBLER_H__
#define __TURBO_ASSEMBLER_H__

#include <stdint.h>
#include <stdio.h>
#include "CodeMemBuffer.h"
#include "PseudoLabel.h"

typedef struct TurboAssembler
{
    uintptr_t fixed_addr;
    CodeMemBuffer *code_buffer;
    PseudoLabel *data_labels;
    size_t data_labels_count;
} TurboAssembler;

TurboAssembler *TurboAssembler_create(uintptr_t fixed_addr);
void TurboAssembler_destroy(TurboAssembler *turbo_assembler);
void TurboAssembler_emit_buffer(TurboAssembler *turbo_assembler, uint8_t *buffer, uint32_t buffer_size);
void TurboAssembler_emit(TurboAssembler *turbo_assembler, uint32_t value);
void TurboAssembler_adrp_add(TurboAssembler *turbo_assembler, Register* rd, uint64_t from, uint64_t to);
void TurboAssembler_ldr(TurboAssembler *turbo_assembler, Register* rt, PseudoLabel *label);
void TurboAssembler_relocDataLabels(TurboAssembler *turbo_assembler);


#endif // __TURBO_ASSEMBLER_H__