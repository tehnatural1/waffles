#include "RelocDataLabel.h"

// Initialize RelocDataLabel
void
    RelocDataLabel_init
    (
        RelocDataLabel *relocDataLabel
    )
{
    relocDataLabel->data_size_ = 0;
}

// Initialize RelocDataLabel with data
void
    RelocDataLabel_initWithData
    (
        RelocDataLabel *relocDataLabel,
        const void *data,
        size_t data_size
    )
{
    if (data_size <= MAX_DATA_SIZE)
    {
        // Copy data
        for (size_t i = 0; i < data_size; ++i)
        {
            relocDataLabel->data_[i] = ((const uint8_t *)data)[i];
        }
        relocDataLabel->data_size_ = (uint8_t)data_size;
    }
    else {
        // Data exceeds maximum size, set data size to 0
        relocDataLabel->data_size_ = 0;
    }
}

// Fixup data in RelocDataLabel with new value
void
    RelocDataLabel_fixupData
    (
        RelocDataLabel *relocDataLabel,
        const void *value,
        size_t value_size
    )
{
    if (value_size <= MAX_DATA_SIZE)
    {
        // Copy value
        for (size_t i = 0; i < value_size; ++i)
        {
            relocDataLabel->data_[i] = ((const uint8_t *)value)[i];
        }
        relocDataLabel->data_size_ = (uint8_t)value_size;
    }
    else {
        // Value exceeds maximum size, set data size to 0
        relocDataLabel->data_size_ = 0;
    }
}

// Get data from RelocDataLabel
const void*
    RelocDataLabel_data
    (
        const RelocDataLabel *relocDataLabel
    )
{
    return relocDataLabel->data_;
}

