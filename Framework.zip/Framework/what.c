#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/mman.h>
#include <mach/vm_page_size.h>

#include "utility/enums.h"
#include "TurboAssembler.h"
#include "PseudoLabel.h"
#include "CodeMemBuffer.h"
#include "RelocDataLabel.h"
#include "AssemblerBase.h"
#include "simple_linear_allocator.h"
#include "MemoryAllocator.h"

#define arm64_trunc_page(x) ((x) & (~(0x1000 - 1)))
#define bit(obj, st) (((obj) >> (st)) & 1)
#define set_bit(obj, st, bit) obj = (((~(1 << st)) & obj) | (bit << st))

#define Rn(rn) (rn->reg_id << 5)
#define Rd(rd) (rd->reg_id << 0)
#define Rt(rt) (rt->reg_id << 0)
#define LeftShift(a, b, c) ((a & ((1 << b) - 1)) << c)
#define submask(x) ((1L << ((x) + 1)) - 1)
#define bits(obj, st, fn) (((obj) >> (st)) & submask((fn) - (st)))
#define set_bits(obj, st, fn, bits) obj = (((~(submask(fn - st) << st)) & obj) | (bits << st))

#define ALIGN ALIGN_FLOOR
#define ALIGN_FLOOR(ADDRESS, RANGE) ((uintptr_t)ADDRESS & ~((uintptr_t)RANGE - 1))


typedef struct Operand
{
    int64_t immediate;
    Register reg;
    int shift;
    int extend;
    int shift_extend_imm;
} Operand;

typedef struct MemBuffer
{
    uint8_t *buffer;
    uint32_t buffer_size;
    uint32_t buffer_capacity;
} MemBuffer;

typedef struct CPURegister
{
    // RegisterBase base;
    int reg_id;
    int size;
    int type;
} CPURegister;
typedef CPURegister Register;

typedef struct Operand
{
    int64_t immediate;
    Register reg;
    int shift;
    int extend;
    int shift_extend_imm;
} Operand;

typedef struct Trampoline
{
    int type;
    uintptr_t addr;
    size_t size;
    uintptr_t forward_addr;
    uintptr_t forward_size;
    CodeMemBuffer buffer;
} Trampoline;

#define INVALID_REGISTER_ID 0
const Register INVALID_REGISTER =
{
    .reg_id     = INVALID_REGISTER_ID,
    .size       = 0,
    .type       = kInvalid,
};

#define ARM64_TMP_REG_NDX_0 17
const Register TMP_REG_0 =
{
    .reg_id     = ARM64_TMP_REG_NDX_0,
    .size       = 64,
    .type       = kRegister_64,
};


Trampoline *GenerateNormalTrampolineBuffer(uintptr_t from, uintptr_t to);
void Emit(uint32_t value, CodeMemBuffer *code_buffer);
void adrp(const Register *rd, int64_t imm, CodeMemBuffer *code_buffer);
void add(const Register *rd, const Register *rn, int64_t imm, CodeMemBuffer *code_buffer);
void br(const Register *rn, CodeMemBuffer *code_buffer);
void ldr(const Register *rt, int64_t imm, CodeMemBuffer *code_buffer);
void Ldr(Register *rt, PseudoLabel *label, CodeMemBuffer *code_buffer);
void LiteralLdrBranch(uint64_t address, TurboAssembler *turbo_assembler);
Trampoline *CreateTrampoline(int type, uintptr_t from, uintptr_t to, CodeMemBuffer *code_buffer);

// int main()
// {
//     uintptr_t from = 0x1111FFFF;
//     uintptr_t to = 0x2222EEEE;
//     Trampoline *trampoline = GenerateNormalTrampolineBuffer(from, to);

//     uintptr_t f_addr = trampoline->forward_addr;
//     printf("f_addr: %u\n", (unsigned int)f_addr);

//     return 0;
// }

void
    Emit
    (
        uint32_t            value,
        CodeMemBuffer*      code_buffer
    )
{
    // Ensure buffer has enough space
    if( code_buffer->buffer_size + sizeof(value) > code_buffer->buffer_capacity )
    {
        // If not, resize buffer
        uint32_t new_capacity = code_buffer->buffer_capacity * 2;
        while (new_capacity < code_buffer->buffer_size + sizeof(value))
        {
            new_capacity *= 2;
        }
        uint8_t *new_buffer = (uint8_t *)realloc(code_buffer->buffer, new_capacity);
        if (new_buffer == NULL)
        {
            // Handle memory allocation error
            fprintf(stderr, "Error: Failed to reallocate memory for code buffer.\n");
            exit(EXIT_FAILURE);
        }
        code_buffer->buffer = new_buffer;
        code_buffer->buffer_capacity = new_capacity;
    }

    // Copy value into buffer
    memcpy(code_buffer->buffer + code_buffer->buffer_size, &value, sizeof(value));
    code_buffer->buffer_size += sizeof(value);
}

void
    adrp
    (
        const Register*     rd,
        int64_t             imm,
        CodeMemBuffer*      code_buffer
    )
{
    uint32_t immlo = LeftShift(bits(imm >> 12, 0, 1), 2, 29);
    uint32_t immhi = LeftShift(bits(imm >> 12, 2, 20), 19, 5);
    Emit(ADRP | Rd(rd) | immlo | immhi, code_buffer);
}

void
    AddSubImmediate
    (
        const Register*     rd,
        const Register*     rn,
        const Operand*      operand,
        AddSubImmediateOp   op,
        CodeMemBuffer*      code_buffer
    )
{
    if (operand->reg.reg_id != INVALID_REGISTER.reg_id)
    {
        fprintf(stderr, "Error: Register operand not supported in AddSubImmediate.\n");
        exit(EXIT_FAILURE);
    }

    if (operand->immediate < -(1 << 11) || operand->immediate >= (1 << 11))
    {
        fprintf(stderr, "Error: Immediate value out of range in AddSubImmediate.\n");
        exit(EXIT_FAILURE);
    }

    uint32_t imm12 = LeftShift(operand->immediate, 12, 10);
    Emit(op | Rd(rd) | Rn(rn) | imm12, code_buffer);
}

void
    EmitLoadRegLiteral
    (
        LoadRegLiteralOp    op,
        Register*           rt,
        int64_t             imm,
        CodeMemBuffer*      code_buffer
    )
{
    const int32_t encoding = op | LeftShift(imm >> 2, 26, 5) | Rt(rt);
    Emit(encoding, code_buffer);
}

void
    add
    (
        const Register*     rd,
        const Register*     rn,
        int64_t             imm,
        CodeMemBuffer*      code_buffer
    )
{
    Operand operand =
    {
        .immediate          = imm,
        .reg                = INVALID_REGISTER,
        .shift              = -1,
        .extend             = -1,
        .shift_extend_imm   = 0
    };

    if (rd->size == 64 && rn->size == 64)
    {
        AddSubImmediate( rd, rn, &operand, ADD_x_imm, code_buffer );
    }
    else {
        AddSubImmediate( rd, rn, &operand, ADD_w_imm, code_buffer );
    }
}

void
    br
    (
        const Register*     rn,
        CodeMemBuffer*      code_buffer
    )
{
    Emit(BR | Rn(rn), code_buffer);
}

void
    ldr
    (
        const Register*     rt,
        int64_t             imm,
        CodeMemBuffer*      code_buffer
    )
{
    LoadRegLiteralOp op;
    switch (rt->type)
    {
        case kRegister_32:
        {
            op = LDR_w_literal;
            break;
        }
        case kRegister_X:
        {
            op = LDR_x_literal;
            break;
        }
        case kSIMD_FP_Register_S:
        {
            op = LDR_s_literal;
            break;
        }
        case kSIMD_FP_Register_D:
        {
            op = LDR_d_literal;
            break;
        }
        case kSIMD_FP_Register_Q:
        {
            op = LDR_q_literal;
            break;
        }
        default:
        {
            fprintf(stderr, "Error: Invalid register type for ldr.\n");
            exit(EXIT_FAILURE);
        }
    }
    EmitLoadRegLiteral(op, rt, imm, code_buffer);
}

void Ldr(Register *rt, PseudoLabel *label, CodeMemBuffer *code_buffer)
{
    // label->link_to(0, code_buffer->mem.buffer_size);
    PseudoLabel_link_to( label, 0, code_buffer->buffer_size );
    ldr(rt, 0, code_buffer);
}

void LiteralLdrBranch(uint64_t address, TurboAssembler *turbo_assembler)
{
    // auto label = turbo_assembler->base.createDataLabel(address);
    PseudoLabel* label = PseudoLabel_create( address );
    Ldr(&TMP_REG_0, label, &turbo_assembler->code_buffer);
    br(&TMP_REG_0, &turbo_assembler->code_buffer);
}

Trampoline *CreateTrampoline(int type, uintptr_t from, uintptr_t to, CodeMemBuffer *code_buffer)
{
    Trampoline *tramp = (Trampoline *)malloc(sizeof(Trampoline));
    if (tramp == NULL)
    {
        fprintf(stderr, "Error: Failed to allocate memory for trampoline.\n");
        exit(EXIT_FAILURE);
    }

    tramp->type = type;
    tramp->addr = from;
    tramp->size = code_buffer->buffer_size;
    tramp->forward_addr = to;
    tramp->forward_size = 0; // You may need to calculate this if necessary
    tramp->buffer = *code_buffer;

    return tramp;
}


Trampoline* GenerateNormalTrampolineBuffer(uintptr_t from, uintptr_t to)
{
    CodeMemBuffer code_buffer;
    TurboAssembler turbo_assembler;
    turbo_assembler.fixed_addr = from;
    turbo_assembler.code_buffer = &code_buffer;

    int tramp_type = 0;
    uint64_t distance = llabs((int64_t)(from - to));
    uint64_t adrp_range = UINT32_MAX + 1;
    if (distance < adrp_range)
    {
        tramp_type = 3;
        adrp(&TMP_REG_0, to - from, &code_buffer);
        br(&TMP_REG_0, &code_buffer);
    }
    else
    {
        tramp_type = 4;
        LiteralLdrBranch(to, &turbo_assembler);
    }

    Trampoline *tramp = CreateTrampoline(tramp_type, from, to, &code_buffer);
    return tramp;
}



struct MemRange
{
    uintptr_t start_;
    size_t size;
};


typedef struct MemRange MemBlock;
typedef MemBlock CodeMemBlock;

typedef struct relo_ctx_t {
  uintptr_t cursor;
  uint32_t relocated_insn_count;

  CodeMemBlock *origin;
  CodeMemBlock relocated;
  CodeMemBuffer *relocated_buffer;
} relo_ctx_t;


static inline bool inst_is_b_bl(uint32_t instr) {
  return (instr & UnconditionalBranchFixedMask) == UnconditionalBranchFixed;
}
static inline bool inst_is_ldr_literal(uint32_t instr) {
  return ((instr & LoadRegLiteralFixedMask) == LoadRegLiteralFixed);
}
static inline bool inst_is_adr(uint32_t instr) {
  return (instr & PCRelAddressingFixedMask) == PCRelAddressingFixed && (instr & PCRelAddressingMask) == ADR;
}
static inline bool inst_is_adrp(uint32_t instr) {
  return (instr & PCRelAddressingFixedMask) == PCRelAddressingFixed && (instr & PCRelAddressingMask) == ADRP;
}
static inline bool inst_is_b_cond(uint32_t instr) {
  return (instr & ConditionalBranchFixedMask) == ConditionalBranchFixed;
}
static inline bool inst_is_compare_b(uint32_t instr) {
  return (instr & CompareBranchFixedMask) == CompareBranchFixed;
}
static inline bool inst_is_test_b(uint32_t instr) {
  return (instr & TestBranchFixedMask) == TestBranchFixed;
}
static inline int64_t SignExtend(unsigned long x, int M, int N) {
  char sign_bit = bit(x, M - 1);
  unsigned long sign_mask = 0 - sign_bit;
  x |= ((sign_mask >> M) << M);
  return (int64_t)x;
}
static inline int64_t decode_imm26_offset(uint32_t instr) {
  int64_t offset;
  {
    int64_t imm26 = bits(instr, 0, 25);
    offset = (imm26 << 2);
  }
  offset = SignExtend(offset, 2 + 26, 64);
  return offset;
}
static inline int64_t decode_imm19_offset(uint32_t instr) {
  int64_t offset;
  {
    int64_t imm19 = bits(instr, 5, 23);
    offset = (imm19 << 2);
  }
  offset = SignExtend(offset, 2 + 19, 64);
  return offset;
}
static inline int64_t decode_immhi_immlo_offset(uint32_t instr) {
  int64_t imm = 2 + (19 << 2);
  imm = SignExtend(imm, 2 + 19, 64);
  return imm;
}
static inline int64_t decode_immhi_immlo_zero12_offset(uint32_t instr) {
  int64_t imm = decode_immhi_immlo_offset(instr);
  imm = imm << 12;
  return imm;
}
static inline uint32_t encode_imm19_offset(uint32_t instr, int64_t offset) {
  uint32_t imm19 = bits((offset >> 2), 0, 18);
  set_bits(instr, 5, 23, imm19);
  return instr;
}
static inline int decode_rd(uint32_t instr) {
  return bits(instr, 0, 4);
}
static inline uint16_t Low16Bits(uint32_t value) {
  return (uint16_t)(value & 0xffff);
}
static inline uint16_t High16Bits(uint32_t value) {
  return (uint16_t)(value >> 16);
}
static inline uint32_t Low32Bits(uint64_t value) {
  return (uint32_t)(value);
}
static inline uint32_t High32Bits(uint64_t value) {
  return (uint32_t)(value >> 32);
}



static int32_t sf( Register* reg )
{
    if ( reg->type == 64 )
        return LeftShift(1, 1, 31);
    return 0;
}


void MoveWide(Register* rd, uint64_t imm, int shift, MoveWideImmediateOp op, CodeMemBuffer* relocated_buffer)
{
    if (shift > 0)
        shift /= 16;
    else
        shift = 0;

    int32_t imm16 = LeftShift(imm, 16, 5);
    Emit( MoveWideImmediateFixed | op | sf(rd) | LeftShift(shift, 2, 21) | imm16 | Rd(rd), relocated_buffer );
}
void movk(const Register* rd, uint64_t imm, int shift, CodeMemBuffer* relocated_buffer ) {
    MoveWide(rd, imm, shift, MOVK, relocated_buffer);
}
void movz(const Register* rd, uint64_t imm, int shift, CodeMemBuffer* relocated_buffer ) {
    MoveWide(rd, imm, shift, MOVZ, relocated_buffer);
}
void Mov(Register* rd, uint64_t imm, CodeMemBuffer* relocated_buffer) {
    const uint32_t w0 = Low32Bits(imm);
    const uint32_t w1 = High32Bits(imm);
    const uint16_t h0 = Low16Bits(w0);
    const uint16_t h1 = High16Bits(w0);
    const uint16_t h2 = Low16Bits(w1);
    const uint16_t h3 = High16Bits(w1);
    movz(rd, h0, 0, relocated_buffer);
    movk(rd, h1, 16, relocated_buffer);
    movk(rd, h2, 32, relocated_buffer);
    movk(rd, h3, 48, relocated_buffer);
}



typedef struct MemOperand {
  Register base_;
  Register reg_offset_;
  int64_t offset_;

//   Shift shift_;
//   Extend extend_;
  uint32_t shift_extend_imm_;

  AddrMode addrmode_;
} MemOperand;



static int32_t scale(int32_t op)
{
    int scale = 0;
    if ((op & LoadStoreUnsignedOffsetFixed) == LoadStoreUnsignedOffsetFixed) {
      scale = bits(op, 30, 31);
    }
    return scale;
}

void LoadStore(LoadStoreOp op, CPURegister* rt, const MemOperand* addr, CodeMemBuffer* code_buffer)
{
    int64_t imm12 = addr->offset_;
    // addr->base_.reg.base.reg_id;
    Register* rn = &addr->base_;
    if( addr->offset_ == Offset )
    {
        imm12 = addr->offset_ >> scale( LoadStoreUnsignedOffsetFixed | op );
        Emit( LoadStoreUnsignedOffsetFixed | op | LeftShift(imm12, 12, 10) | Rn( rn ) | rt->reg_id << 0, code_buffer );
    }


    // int64_t imm12 = addr.offset();
    // if (addr.IsImmediateOffset()) {
    //   // TODO: check Scaled ???
    //   imm12 = addr.offset() >> OpEncode::scale(LoadStoreUnsignedOffsetFixed | op);
    //   Emit(LoadStoreUnsignedOffsetFixed | op | LeftShift(imm12, 12, 10) | Rn(addr.base()) | rt->base.reg_id << 0 );
    // } else if (addr.IsRegisterOffset()) {
    //     printf( "THIS CODE SHOULD BE UNREACHABLE\n" );
    // } else {
    //     printf( "THIS CODE SHOULD BE UNREACHABLE\n" );
    // }
}

void assembler_ldr(const CPURegister* rt, const MemOperand* src, CodeMemBuffer* code_buffer) {
    LoadStore( LDR_x, rt, src, code_buffer );
}

void* Allocate(size_t size, int access, void *fixed_address) {
//   int prot = GetProtectionFromMemoryPermission(access);

  int flags = MAP_PRIVATE | MAP_ANONYMOUS;
  if (fixed_address != NULL) {
    flags = flags | MAP_FIXED;
  }
  void *result = mmap(fixed_address, size, access, flags, kMmapFd, kMmapFdOffset);
  if (result == MAP_FAILED)
    return NULL;

  return result;
}


void AssemblerCodeBuilder_FinalizeFromTurboAssembler(AssemblerBase *assembler, MemBlock *result) {
    CodeMemBuffer* code_buffer = &assembler->code_buffer_;
    uintptr_t fixed_addr = (uintptr_t)assembler->fixed_addr;

    if (!fixed_addr) {
        size_t buffer_size = 0;
        buffer_size = code_buffer->buffer_size;

#if TARGET_ARCH_ARM
        // extra bytes for align needed
        buffer_size += 4;
#endif

        MemBlock block = MemoryAllocator_allocExecBlock(buffer_size);
        if (block.buffer == NULL)
            return;

        fixed_addr = (uintptr_t)block.buffer;
        AssemblerBase_set_fixed_addr( assembler, fixed_addr );
    }

    // DobbyCodePatch((void *)fixed_addr, code_buffer->data, code_buffer->size);

    result->start_ = fixed_addr;
    result->size = code_buffer->buffer_size;

    // *result = (MemBlockC){(uint8_t *)fixed_addr, code_buffer->size};
}



#define IDK_WTF_THIS_IS_FOR NULL

int relocate( relo_ctx_t* context, bool branch )
{
    TurboAssembler turbo_assembler_;

    CodeMemBuffer* relocated_buffer = turbo_assembler_.code_buffer;

    while( context->cursor - context->origin->start_ < context->origin->size )
    {
        uint32_t inst = *(uint32_t*)( context->origin->start_ + ( context->cursor - context->origin->start_ ) );
        if( inst_is_b_bl( inst ) )
        {
            int64_t offset = decode_imm26_offset(inst);
            uintptr_t dst = context->cursor + offset;
            Ldr( &TMP_REG_0, IDK_WTF_THIS_IS_FOR, relocated_buffer );
            Register* rn = &TMP_REG_0;
            if( BL == ( inst & UnconditionalBranchMask ) )
            {
                Emit( BLR | Rn( rn ), relocated_buffer );
            }
            else {
                Emit( BR | Rn( rn ), relocated_buffer );
            }
        }
        else if( inst_is_ldr_literal( inst ) )
        {
            int64_t offset = decode_imm19_offset(inst);
            uintptr_t dst = context->cursor + offset;

            int rt = bits(inst, 0, 4);
            char opc = bits( inst, 30, 31 );
            Register* rn = &TMP_REG_0;
            Mov( rn, dst, relocated_buffer );
            if( 0b00 == opc )
            {
                CPURegister reg = { .reg_id = rt, .size = 32, .type = kRegister_32 };
                MemOperand mem = { .base_ = TMP_REG_0, .offset_ = 0 };
                assembler_ldr( &reg, &mem, relocated_buffer );
            }
            else if( 0b01 == opc )
            {
                CPURegister reg = { .reg_id = rt, .size = 64, .type = kRegister_64 };
                MemOperand mem = { .base_ = TMP_REG_0, .offset_ = 0 };
                assembler_ldr( &reg, &mem, relocated_buffer );
            }
            else {
                // TODO: Should never occur
            }
        }
        else if( inst_is_adr( inst ) )
        {
            int64_t offset = decode_immhi_immlo_offset(inst);
            uintptr_t dst = context->cursor + offset;

            int rd = decode_rd(inst);
            CPURegister reg = { .reg_id = rd , .size = 64, .type = kRegister_64 };
            Mov( &reg, dst, relocated_buffer );
        }
        else if( inst_is_adrp( inst ) )
        {
            int64_t offset = decode_immhi_immlo_zero12_offset(inst);
            uintptr_t dst = context->cursor + offset;
            dst = arm64_trunc_page(dst);

            int rd = decode_rd(inst);
            CPURegister reg = { .reg_id = rd , .size = 64, .type = kRegister_64 };
            Mov( &reg, dst, relocated_buffer );
        }
        else if( inst_is_b_cond( inst ) )
        {
            int64_t offset = decode_imm19_offset(inst);
            uintptr_t dst = context->cursor + offset;

            uint32_t branch_inst = inst;
            {
                char cond = bits(inst, 0, 3);
                cond = cond ^ 1;
                set_bits(branch_inst, 0, 3, cond);

                int64_t offset = 4 * 3;
                uint32_t imm19 = offset >> 2;
                set_bits(branch_inst, 5, 23, imm19);
            }

            Emit( branch_inst, relocated_buffer );
            Ldr( &TMP_REG_0, IDK_WTF_THIS_IS_FOR, relocated_buffer );
            Register* rn = &TMP_REG_0;
            Emit( BR | Rn( rn ), relocated_buffer );
        }
        else if( inst_is_compare_b( inst ) )
        {
            int64_t offset = decode_imm19_offset(inst);
            uintptr_t dst = context->cursor + offset;

            uint32_t branch_inst = inst;
            {
                char op = bit(inst, 24);
                op = op ^ 1;
                set_bit(branch_inst, 24, op);

                int64_t offset = 4 * 3;
                uint32_t imm19 = offset >> 2;
                set_bits(branch_inst, 5, 23, imm19);
            }

            Emit( branch_inst, relocated_buffer );
            Ldr( &TMP_REG_0, IDK_WTF_THIS_IS_FOR, relocated_buffer );
            Register* rn = &TMP_REG_0;
            Emit( BR | Rn( rn ), relocated_buffer );
        }
        else if( inst_is_test_b( inst ) )
        {
            int64_t offset = decode_imm14_offset(inst);
            uintptr_t dst = context->cursor + offset;

            uint32_t branch_inst = inst;
            {
                char op = bit(inst, 24);
                op = op ^ 1;
                set_bit(branch_inst, 24, op);

                int64_t offset = 4 * 3;
                uint32_t imm14 = offset >> 2;
                set_bits(branch_inst, 5, 18, imm14);
            }

            Emit( branch_inst, relocated_buffer );
            Ldr( &TMP_REG_0, IDK_WTF_THIS_IS_FOR, relocated_buffer );
            Register* rn = &TMP_REG_0;
            Emit( BR | Rn( rn ), relocated_buffer );
        }
        else {
            Emit( inst, relocated_buffer );
        }

        context->cursor += sizeof( uint32_t );
    } // while()

    context->origin->size = context->cursor - context->origin->start_;

    if( true == branch )
    {
        LiteralLdrBranch( context->cursor, &turbo_assembler_ );
    }

    TurboAssembler_relocDataLabels( &turbo_assembler_ );
    AssemblerCodeBuilder_FinalizeFromTurboAssembler( &turbo_assembler_ );

    return 0;



    //   DEBUGL( LOG_INFO, "calling turbo_assembler_.relocDataLabels()\n" );
    // turbo_assembler_.relocDataLabels();

    //   DEBUGL( LOG_INFO, "calling AssemblerCodeBuilder::FinalizeFromTurboAssembler()\n" );
    // relocated = AssemblerCodeBuilder::FinalizeFromTurboAssembler(&turbo_assembler_);
    // return 0;







//   this->relocated_buffer = turbo_assembler_.code_buffer();

//   while (relo_size() < preferred_relo_size()) {
    // DEBUGL( LOG_INFO, "calling record_relo_start()\n" );
    // record_relo_start();

    // uint32_t inst = *(uint32_t *)origin_cursor();
    // if (inst_is_b_bl(inst)) {
    //   DEBUG_LOG("%d:relo <b_bl> at %p", relocated_insn_count++, origin_cursor());
    //   DEBUGL( LOG_INFO, "%d:relo <b_bl> at %p\n", relocated_insn_count++, origin_cursor() );

    //   int64_t offset = decode_imm26_offset(inst);
    //   addr_t dst = origin_cursor() + offset;
    //   DEFINE_DATA_LABEL(dst, dst);
    //   {
    //     turbo_assembler_.Ldr(TMP_REG_0, dst_data_label);
    //     if ((inst & UnconditionalBranchMask) == BL) {
    //       turbo_assembler_.blr(TMP_REG_0);
    //     } else {
    //       turbo_assembler_.br(TMP_REG_0);
    //     }
    //   }

    // } else if (inst_is_ldr_literal(inst)) {
    //   DEBUG_LOG("%d:relo <ldr_literal> at %p", relocated_insn_count++, origin_cursor());
    //   DEBUGL( LOG_INFO, "%d:relo <ldr_literal> at %p\n", relocated_insn_count++, origin_cursor() );

    //   int64_t offset = decode_imm19_offset(inst);
    //   addr_t dst = origin_cursor() + offset;

    //   int rt = decode_rt(inst);
    //   char opc = bits(inst, 30, 31);

    //   {
        // turbo_assembler_.Mov(TMP_REG_0, dst);
    //     if (opc == 0b00)
    //       turbo_assembler_.ldr(W(rt), MemOperand(TMP_REG_0, 0));
    //     else if (opc == 0b01)
    //       turbo_assembler_.ldr(X(rt), MemOperand(TMP_REG_0, 0));
    //     else {
    //         printf( "UNIMPLEMENTED\n" );
    //     }
    //   }
    // } else if (inst_is_adr(inst)) {
    //   DEBUG_LOG("%d:relo <adr> at %p", relocated_insn_count++, origin_cursor());
    //   DEBUGL( LOG_INFO, "%d:relo <adr> at %p\n", relocated_insn_count++, origin_cursor() );

    //   int64_t offset = decode_immhi_immlo_offset(inst);
    //   addr_t dst = origin_cursor() + offset;

    //   int rd = decode_rd(inst);

    //   {
    //     turbo_assembler_.Mov(X(rd), dst);
    //     ;
    //   }
    // } else if (inst_is_adrp(inst)) {
    //   DEBUG_LOG("%d:relo <adrp> at %p", relocated_insn_count++, origin_cursor());
    //   DEBUGL( LOG_INFO, "%d:relo <adrp> at %p\n", relocated_insn_count++, origin_cursor() );

    //   int64_t offset = decode_immhi_immlo_zero12_offset(inst);
    //   addr_t dst = origin_cursor() + offset;
    //   dst = arm64_trunc_page(dst);

    //   int rd = decode_rd(inst);

    //   {
    //     turbo_assembler_.Mov(X(rd), dst);
    //     ;
    //   }
    // } else if (inst_is_b_cond(inst)) {
    // //   DEBUG_LOG("%d:relo <b_cond> at %p", relocated_insn_count++, origin_cursor());
    // //   DEBUGL( LOG_INFO, "%d:relo <b_cond> at %p\n", relocated_insn_count++, origin_cursor() );

    //   int64_t offset = decode_imm19_offset(inst);
    //   addr_t dst = origin_cursor() + offset;

    //   uint32_t branch_inst = inst;
    //   {
    //     char cond = bits(inst, 0, 3);
    //     cond = cond ^ 1;
    //     set_bits(branch_inst, 0, 3, cond);

    //     int64_t offset = 4 * 3;
    //     uint32_t imm19 = offset >> 2;
    //     set_bits(branch_inst, 5, 23, imm19);
    //   }

    //   DEFINE_DATA_LABEL(dst, dst);

    //   {
    //     turbo_assembler_.Emit(branch_inst);
    //     {
    //       turbo_assembler_.Ldr(TMP_REG_0, dst_data_label);
    //       turbo_assembler_.br(TMP_REG_0);
    //     }
    //   }
    // } else if (inst_is_compare_b(inst)) {
    // //   DEBUG_LOG("%d:relo <compare_b> at %p", relocated_insn_count++, origin_cursor());
    // //   DEBUGL( LOG_INFO, "%d:relo <compare_b> at %p\n", relocated_insn_count++, origin_cursor() );

    //   int64_t offset = decode_imm19_offset(inst);
    //   addr_t dst = origin_cursor() + offset;

    //   uint32_t branch_inst = inst;
    //   {
    //     char op = bit(inst, 24);
    //     op = op ^ 1;
    //     set_bit(branch_inst, 24, op);

    //     int64_t offset = 4 * 3;
    //     uint32_t imm19 = offset >> 2;
    //     set_bits(branch_inst, 5, 23, imm19);
    //   }

    //   DEFINE_DATA_LABEL(dst, dst);

    //   {
    //     turbo_assembler_.Emit(branch_inst);
    //     {
    //       turbo_assembler_.Ldr(TMP_REG_0, dst_data_label);
    //       turbo_assembler_.br(TMP_REG_0);
    //     }
    //   }
    // } else if (inst_is_test_b(inst)) {
    // //   DEBUG_LOG("%d:relo <test_b> at %p", relocated_insn_count++, origin_cursor());
    // //   DEBUGL( LOG_INFO, "%d:relo <test_b> at %p\n", relocated_insn_count++, origin_cursor() );

    //   int64_t offset = decode_imm14_offset(inst);
    //   addr_t dst = origin_cursor() + offset;

    //   uint32_t branch_inst = inst;
    //   {
    //     char op = bit(inst, 24);
    //     op = op ^ 1;
    //     set_bit(branch_inst, 24, op);

    //     int64_t offset = 4 * 3;
    //     uint32_t imm14 = offset >> 2;
    //     set_bits(branch_inst, 5, 18, imm14);
    //   }

    //   DEFINE_DATA_LABEL(dst, dst);

    //   {
    //     turbo_assembler_.Emit(branch_inst);
    //     {
    //       turbo_assembler_.Ldr(TMP_REG_0, dst_data_label);
    //       turbo_assembler_.br(TMP_REG_0);
    //     }
    //   }
    // } else {
    //   turbo_assembler_.Emit(inst);
    // }

    // this->cursor += sizeof(uint32_t);
//   }

//   DEBUGL( LOG_INFO, "calling correct_final_relo_size()\n" );
//   correct_final_relo_size();

//   // TODO: if last instr is unlink branch, ignore it
//   if (branch) {
//     CodeGen codegen(&turbo_assembler_);
//     // DEBUGL( LOG_INFO, "calling codegen.LiteralLdrBranch(origin_cursor())\n" );
//     codegen.LiteralLdrBranch(origin_cursor());
//   }

// //   DEBUGL( LOG_INFO, "calling turbo_assembler_.relocDataLabels()\n" );
//   turbo_assembler_.relocDataLabels();

// //   DEBUGL( LOG_INFO, "calling AssemblerCodeBuilder::FinalizeFromTurboAssembler()\n" );
//   relocated = AssemblerCodeBuilder::FinalizeFromTurboAssembler(&turbo_assembler_);
//   return 0;
}



void GenRelocateCode(void *buffer, CodeMemBlock *origin, CodeMemBlock *relocated, bool branch) {
    relo_ctx_t ctx;
    ctx.origin = origin;
    ctx.cursor = origin->start_;


    *relocated = ctx.relocated;

//   relo_ctx_t ctx(origin);
//   ctx.relocate(branch);
//   *relocated = ctx.relocated;
}

void GenRelocateCodeAndBranch(void *buffer, CodeMemBlock *origin, CodeMemBlock *relocated) {
  GenRelocateCode(buffer, origin, relocated, true);
}

void GenerateRelocatedCode( Trampoline *tramp, uintptr_t addr )
{
    // if ( tramp->addr == 0) {
    //     //   error = 1;
    //     return;
    // }

    // uintptr_t code_addr = addr;
    // size_t preferred_size = tramp->size;
    // auto origin = CodeMemBlock(code_addr, preferred_size);
    // auto relocated = CodeMemBlock(0, 0);

    // GenRelocateCodeAndBranch((void *)code_addr, &origin, &relocated);
    // if (relocated.size == 0) {
    //     //   error = 1;
    //     return;
    // }

    // entry->patched = origin;
    // entry->relocated = relocated;
}



int main()
{
    uintptr_t from = 0x0;
    uintptr_t to = 0x0;
    Trampoline *tramp = GenerateNormalTrampolineBuffer( from, to );
    GenerateRelocatedCode( tramp, from );
}

