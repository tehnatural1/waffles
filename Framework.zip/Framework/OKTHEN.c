
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <inttypes.h>
#include <stdlib.h>


#define min(a, b) (((a) < (b)) ? (a) : (b))
#define max(a, b) (((a) > (b)) ? (a) : (b))


typedef uintptr_t addr_t;


struct MemRange {
    // addr(), start()
    addr_t start_;
    // end() -> start_ + size;
    size_t size;

//   addr_t start() const {
//     return start_;
//   }

//   addr_t addr() const {
//     return start_;
//   }

//   addr_t end() const {
//     return start_ + size;
//   }

//   void resize(size_t in_size) {
//     size = in_size;
//   }

//   void reset(addr_t in_start, size_t in_size) {
//     start_ = in_start;
//     size = in_size;
//   }

//   MemRange intersect(const MemRange &other) const {
//     auto start = max(this->addr(), other.addr());
//     auto end = min(this->end(), other.end());
//     if (start < end)
//       return MemRange(start, end - start);
//     else
//       return MemRange{};
//   }
};

typedef struct MemRange MemBlock;
typedef MemBlock CodeMemBlock;

typedef struct Trampoline {
    int type;
    CodeMemBlock buffer;
    struct Trampoline* forward_trampoline;
} Trampoline;


struct MemBuffer {
  uint8_t *buffer;
  uint32_t buffer_size;
  uint32_t buffer_capacity;
};

typedef struct MemBuffer CodeMemBuffer;

// struct Label {
//   addr_t pos;
// };

typedef struct ref_inst_t {
    int link_type;
    uintptr_t inst_offset;
} ref_inst_t;

struct PseudoLabel {


    addr_t pos;
    CodeMemBuffer *code_buffer;
    ref_inst_t** ref_insts;
    // stl::vector<ref_inst_t> ref_insts;


//   PseudoLabel(addr_t pos) {
//     bind_to(pos);
//   }

//   void bind_to(addr_t pos) {
//     this->pos = pos;
//   }

//   bool has_confused_instructions() {
//     return !ref_insts.empty();
//   }

//   void link_confused_instructions(CodeMemBuffer *buffer) {
//   for (auto &ref_inst : ref_insts) {
//     int64_t fixup_offset = pos - ref_inst.offset();

//     uint32_t inst = buffer->LoadInst(ref_inst.offset());
//     uint32_t new_inst = 0;

//     if (ref_inst.link_type == kLabelImm19) {
//       new_inst = encode_imm19_offset(inst, fixup_offset);
//     }

//     buffer->RewriteInst(ref_inst.offset(), new_inst);
//   }

//   void link_to(int link_type, uint32_t pc_offset) {
//     ref_inst_t insn(link_type, pc_offset);
//     ref_insts.push_back(insn);
//   }
};

typedef struct RelocDataLabel {
    uint8_t data_[8];
    uint8_t data_size_;
    addr_t pos;
    CodeMemBuffer *code_buffer;
    ref_inst_t** ref_insts;

//   RelocDataLabel() {
//     data_size_ = 0;
//   }

//   template <typename T> RelocDataLabel(T data) {
//     *(T *)data_ = data;
//     data_size_ = sizeof(T);
//   }

//   template <typename T> T data() {
//     return *(T *)data_;
//   }

//   template <typename T> void fixupData(T value) {
//     *(T *)data_ = value;
//   }
} RelocDataLabel;



typedef struct AssemblerBase {
    addr_t fixed_addr;
    CodeMemBuffer code_buffer_;
    RelocDataLabel** data_labels;
} AssemblerBase;

typedef struct AssembleBase Assembler;
typedef struct Assembler TurboAssembler;

enum InstructionFields {

  // Registers.
  kRdShift = 0,
  kRdBits = 5,
  kRnShift = 5,
  kRnBits = 5,
  kRaShift = 10,
  kRaBits = 5,
  kRmShift = 16,
  kRmBits = 5,
  kRtShift = 0,
  kRtBits = 5,
  kRt2Shift = 10,
  kRt2Bits = 5,
  kRsShift = 16,
  kRsBits = 5,

};

#define TRAMPOLINE_ARM64_ADRP_ADD_BR 3
#define ALIGN ALIGN_FLOOR
#define ALIGN_FLOOR(address, range) ((uintptr_t)address & ~((uintptr_t)range - 1))
#define LeftShift(a, b, c) ((a & ((1 << b) - 1)) << c)
#define Rd(rd) (rd->reg_id << kRdShift)


// PC relative addressing.
enum PCRelAddressingOp {
  PCRelAddressingFixed = 0x10000000,
  PCRelAddressingFixedMask = 0x1F000000,
  PCRelAddressingMask = 0x9F000000,
  ADR = PCRelAddressingFixed | 0x00000000,
  ADRP = PCRelAddressingFixed | 0x80000000
};


typedef struct RegisterBase {
    int reg_id;
} RegisterBase;


void
    Emit32
    (
        uint8_t* buffer,
        uint32_t buffer_size
    )
{

}

void adrp(RegisterBase* rd, int64_t imm) {
    // DCHECK(rd.Is64Bits());
    // DCHECK((abs(imm) >> 12) < (1 << 21));

    uint32_t immlo = LeftShift(bits(imm >> 12, 0, 1), 2, 29);
    uint32_t immhi = LeftShift(bits(imm >> 12, 2, 20), 19, 5);
    Emit32( ADRP | Rd(rd) | immlo | immhi, sizeof( uint32_t ) );

    //uint32_t
}

void AdrpAdd(RegisterBase* rd, uint64_t from, uint64_t to) {
    uint64_t from_PAGE = ALIGN(from, 0x1000);
    uint64_t to_PAGE = ALIGN(to, 0x1000);
    uint64_t to_PAGEOFF = (uint64_t)to % 0x1000;

    adrp(rd, to_PAGE - from_PAGE);
    add(rd, rd, to_PAGEOFF);
}





Trampoline*
    GenerateNormalTrampolineBuffer
    (
        addr_t from,
        addr_t to
    )
{
    // TurboAssembler turbo_assembler_(from);

    AssemblerBase* turbo_assembler = malloc( sizeof( AssemblerBase ) );

    turbo_assembler->fixed_addr = from;


    int tramp_type = 0;
    uint64_t distance = llabs((int64_t)(from - to));
    uint64_t adrp_range = ((uint64_t)1 << (2 + 19 + 12 - 1));

    if (distance < adrp_range) {
        tramp_type = TRAMPOLINE_ARM64_ADRP_ADD_BR;
        AdrpAdd(TMP_REG_0, from, to);
        turbo_assembler.br(TMP_REG_0);
        DEBUG_LOG("[trampoline] use [adrp, add, br]");
    } else {
        tramp_type = TRAMPOLINE_ARM64_LDR_BR;
        CodeGen codegen(&turbo_assembler);
        codegen.LiteralLdrBranch((uint64_t)to);
        DEBUG_LOG("[trampoline] use [ldr, br, #label]");
    }

    // bind all labels
    turbo_assembler_.relocDataLabels();

    auto tramp_buffer = turbo_assembler_.code_buffer();
    auto tramp_block = tramp_buffer->dup();
    auto tramp = new Trampoline(tramp_type, tramp_block);
    DEBUG_LOG("[trampoline] trampoline addr: %p(temp), %p(real), size: %d", tramp->addr(), from, tramp->size());
    debug_hex_log_buffer((uint8_t *)tramp->addr(), tramp->size());
    return tramp;
}






bool
    GenerateTrampoline
    (
        uintptr_t*  FunctionToHookAddress,
        void*       FakeFunction
    )
{
    uintptr_t from = *FunctionToHookAddress;
    uintptr_t to = FakeFunction;
    Trampoline* trampoline = malloc( sizeof( Trampoline ) );


    // if (0 && RoutingPluginManager::near_branch_trampoline) {
    //   auto plugin = static_cast<RoutingPluginInterface *>(RoutingPluginManager::near_branch_trampoline);

    //   DEBUGL( LOG_DEBUG, "Calling plugin->GenerateTrampolineBuffer()\n" );
    //   plugin->GenerateTrampolineBuffer(this, from, to);
    // }

    // if (g_enable_near_trampoline) {
    //   DEBUGL( LOG_DEBUG, "Calling GenerateNearTrampolineBuffer()\n" );
    //   near_trampoline = GenerateNearTrampolineBuffer(from, to);
    // }

    // if (!near_trampoline) {
    //   DEBUGL( LOG_DEBUG, "Calling GenerateNormalTrampolineBuffer()\n" );
      trampoline = GenerateNormalTrampolineBuffer(from, to);
    // }
    return true;
}







/**
 * NOTE: Start HERE
 */
void
    BuildRouting
    (
        void
    )
{
    GenerateTrampoline();

    GenerateRelocatedCode();

    BackupOriginCode();


    // entry->addr = HOOK ADDRESS Resolved
    // trampoline_addr() = Trampoline->buffer->start_
    DobbyCodePatch((void *)entry->addr, (uint8_t *)trampoline_addr(), trampoline_size());
}




















// struct Label {
//   addr_t pos;
// };

// struct PseudoLabel : Label {
//   struct ref_inst_t {
//     int link_type;
//     uintptr_t inst_offset;
//     explicit ref_inst_t(int link_type, size_t inst_offset) : link_type(link_type), inst_offset(inst_offset) {
//     }

//     int type() {
//       return link_type;
//     }

//     uintptr_t offset() {
//       return inst_offset;
//     }
//   };

//   CodeMemBuffer *code_buffer;
//   stl::vector<ref_inst_t> ref_insts;

//   PseudoLabel() : PseudoLabel(0) {
//   }

//   PseudoLabel(addr_t pos) {
//     bind_to(pos);
//   }

//   void bind_to(addr_t pos) {
//     this->pos = pos;
//   }

//   bool has_confused_instructions() {
//     return !ref_insts.empty();
//   }

//   void link_confused_instructions(CodeMemBuffer *buffer);

//   void link_to(int link_type, uint32_t pc_offset) {
//     ref_inst_t insn(link_type, pc_offset);
//     ref_insts.push_back(insn);
//   }
// };


// struct RelocDataLabel : PseudoLabel {
//   uint8_t data_[8];
//   uint8_t data_size_;

//   RelocDataLabel() {
//     data_size_ = 0;
//   }

//   template <typename T> RelocDataLabel(T data) {
//     *(T *)data_ = data;
//     data_size_ = sizeof(T);
//   }

//   template <typename T> T data() {
//     return *(T *)data_;
//   }

//   template <typename T> void fixupData(T value) {
//     *(T *)data_ = value;
//   }
// };