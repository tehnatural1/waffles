#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <mach/mach.h>
#include <mach/vm_page_size.h>
#include <iostream>
#include <stddef.h>
#include <unistd.h>
#include <sys/mman.h>
#include <limits.h>
#include "thisTWO.h"

#if __has_feature(ptrauth_calls)
  #include <ptrauth.h>
#endif

#if __APPLE__
  #include <libkern/OSCacheControl.h>
#endif

typedef struct InterceptRouting InterceptRouting;
typedef struct CodeMemBuffer CodeMemBuffer;

#define ALIGN ALIGN_FLOOR
#define ALIGN_FLOOR(ADDRESS, RANGE) ((uintptr_t)ADDRESS & ~((uintptr_t)RANGE - 1))
#define ALIGN_CEIL(ADDRESS, RANGE) (((uintptr_t)ADDRESS + (uintptr_t)RANGE - 1) & ~((uintptr_t)RANGE - 1))

#define PAGE_SIZE vm_page_size

#define arm64_trunc_page(x) ((x) & (~(0x1000 - 1)))
#define min(a, b) (((a) < (b)) ? (a) : (b))
#define max(a, b) (((a) > (b)) ? (a) : (b))
#define LeftShift(a, b, c) ((a & ((1 << b) - 1)) << c)
#define submask(x) ((1L << ((x) + 1)) - 1)
#define bits(obj, st, fn) (((obj) >> (st)) & submask((fn) - (st)))
#define bit(obj, st) (((obj) >> (st)) & 1)
#define set_bit(obj, st, bit) obj = (((~(1 << st)) & obj) | (bit << st))
#define set_bits(obj, st, fn, bits) obj = (((~(submask(fn - st) << st)) & obj) | (bits << st))

// #define Rd(rd) (rd.code() << kRdShift)
// #define Rt(rt) (rt.code() << kRtShift)
// #define Rt2(rt) (rt.code() << kRt2Shift)
// #define Rn(rn) (rn.code() << kRnShift)
// #define Rm(rm) (rm.code() << kRmShift)

#define Rd( rd )  ( rd.reg_id << kRdShift  )
#define Rt( rt )  ( rt.reg_id << kRtShift  )
#define Rt2( rt ) ( rt.reg_id << kRt2Shift )
#define Rn( rn )  ( rn.reg_id << kRnShift  )
#define Rm( rm )  ( rm.reg_id << kRmShift  )

enum InstructionFields
{
    kRdShift    = 0,
    kRnShift    = 5,
    kRmShift    = 16,
    kRtShift    = 0,
    kRt2Shift   = 10,
};

static uintptr_t vm_protect_address = 0x1234567;

enum ref_label_type_t
{
    kLabelImm19
};

// Exception.
enum ExceptionOp
{
    ExceptionFixed  = 0xD4000000,
    BRK             = ExceptionFixed | 0x00200000,
};

enum PCRelAddressingOp
{
    PCRelAddressingFixed        = 0x10000000,
    PCRelAddressingFixedMask    = 0x1F000000,
    PCRelAddressingMask         = 0x9F000000,
    ADR                         = PCRelAddressingFixed | 0x00000000,
    ADRP                        = PCRelAddressingFixed | 0x80000000,
};

// Unconditional branch.
enum UnconditionalBranchOp
{
    UnconditionalBranchFixed        = 0x14000000,
    UnconditionalBranchFixedMask    = 0x7C000000,
    UnconditionalBranchMask         = 0xFC000000,
    B                               = UnconditionalBranchFixed | 0x00000000,
    BL                              = UnconditionalBranchFixed | 0x80000000,
};

// Unconditional branch to register.
enum UnconditionalBranchToRegisterOp
{
    UnconditionalBranchToRegisterFixed  = 0xD6000000,
    BR                                  = UnconditionalBranchToRegisterFixed | 0x001F0000,
    BLR                                 = UnconditionalBranchToRegisterFixed | 0x003F0000,
};

enum LoadStorePairOffsetOp
{
    LoadStorePairOffsetFixed = 0x29000000,
};
enum LoadStorePairPostIndexOp
{
    LoadStorePairPostIndexFixed = 0x28800000,
};
enum LoadStorePairPreIndexOp
{
    LoadStorePairPreIndexFixed = 0x29800000,
};

enum AddSubImmediateOp
{
    AddSubImmediateFixed    = 0x11000000,
    ADD_w_imm               = AddSubImmediateFixed | ((0 & ((1 << 1) - 1)) << 31) | ((0 & ((1 << 1) - 1)) << 30) | ((0 & ((1 << 1) - 1)) << 29),
    SUB_w_imm               = AddSubImmediateFixed | ((0 & ((1 << 1) - 1)) << 31) | ((1 & ((1 << 1) - 1)) << 30) | ((0 & ((1 << 1) - 1)) << 29),
    ADD_x_imm               = AddSubImmediateFixed | ((1 & ((1 << 1) - 1)) << 31) | ((0 & ((1 << 1) - 1)) << 30) | ((0 & ((1 << 1) - 1)) << 29),
    SUB_x_imm               = AddSubImmediateFixed | ((1 & ((1 << 1) - 1)) << 31) | ((1 & ((1 << 1) - 1)) << 30) | ((0 & ((1 << 1) - 1)) << 29),
};

enum LoadRegLiteralOp
{
    LoadRegLiteralFixed     = 0x18000000,
    LoadRegLiteralFixedMask = 0x3B000000,
    LDR_w_literal           = LoadRegLiteralFixed | ((0b00 & ((1 << 2) - 1)) << 30) | ((0 & ((1 << 1) - 1)) << 26),
    LDR_x_literal           = LoadRegLiteralFixed | ((0b01 & ((1 << 2) - 1)) << 30) | ((0 & ((1 << 1) - 1)) << 26),
    LDR_s_literal           = LoadRegLiteralFixed | ((0b00 & ((1 << 2) - 1)) << 30) | ((1 & ((1 << 1) - 1)) << 26),
    LDR_d_literal           = LoadRegLiteralFixed | ((0b01 & ((1 << 2) - 1)) << 30) | ((1 & ((1 << 1) - 1)) << 26),
    LDR_q_literal           = LoadRegLiteralFixed | ((0b10 & ((1 << 2) - 1)) << 30) | ((1 & ((1 << 1) - 1)) << 26),
};

// Load/store
enum LoadStoreOp
{
    STR_x = ((0b11 & ((1 << 2) - 1)) << 30) | ((0 & ((1 << 1) - 1)) << 26) | ((0b00 & ((1 << 2) - 1)) << 22),
    LDR_x = ((0b11 & ((1 << 2) - 1)) << 30) | ((0 & ((1 << 1) - 1)) << 26) | ((0b01 & ((1 << 2) - 1)) << 22),
};

enum LoadStorePairOp
{
    STP_x = ((0b10 & ((1 << 2) - 1)) << 30) | ((0 & ((1 << 1) - 1)) << 26) | ((0 & ((1 << 1) - 1)) << 22),
    LDP_x = ((0b10 & ((1 << 2) - 1)) << 30) | ((0 & ((1 << 1) - 1)) << 26) | ((1 & ((1 << 1) - 1)) << 22),
    STP_q = ((0b10 & ((1 << 2) - 1)) << 30) | ((1 & ((1 << 1) - 1)) << 26) | ((0 & ((1 << 1) - 1)) << 22),
    LDP_q = ((0b10 & ((1 << 2) - 1)) << 30) | ((1 & ((1 << 1) - 1)) << 26) | ((1 & ((1 << 1) - 1)) << 22),
};

enum LoadStoreUnsignedOffset
{
    LoadStoreUnsignedOffsetFixed = 0x39000000,
};

// Move wide immediate.
enum MoveWideImmediateOp
{
    MoveWideImmediateFixed  = 0x12800000,
    MOVZ                    = 0x40000000,
    MOVK                    = 0x60000000,
};

// Logical (immediate and shifted register).
enum LogicalOp
{
  // NOT = 0x00200000,
  // AND = 0x00000000,
  // BIC = AND | NOT,
  ORR = 0x20000000,
  // ORN = ORR | NOT,
  // EOR = 0x40000000,
  // EON = EOR | NOT,
  // ANDS = 0x60000000,
  // BICS = ANDS | NOT
};

// Logical shifted register.
enum LogicalShiftedOp
{
    LogicalShiftedFixed = 0x0A000000,
};

// Compare and branch.
enum CompareBranchOp
{
    CompareBranchFixed      = 0x34000000,
    CompareBranchFixedMask  = 0x7E000000,
};

// Conditional branch.
enum ConditionalBranchOp
{
    ConditionalBranchFixed      = 0x54000000,
    ConditionalBranchFixedMask  = 0xFE000000,
    ConditionalBranchMask       = 0xFF000010,
};

// Test and branch.
enum TestBranchOp
{
    TestBranchFixed         = 0x36000000,
    TestBranchFixedMask     = 0x7E000000,
};

enum trampoline_type_t
{
    // TRAMPOLINE_UNKNOWN = 0,
    // TRAMPOLINE_ARM64_B_XXX,
    // TRAMPOLINE_ARM64_B_XXX_AND_FORWARD_TRAMP,
    TRAMPOLINE_ARM64_ADRP_ADD_BR    = 3,
    TRAMPOLINE_ARM64_LDR_BR         = 4,
    // CLOSURE_TRAMPOLINE_ARM64,
    // FORWARD_TRAMPOLINE_ARM64,
};

enum Shift
{
    NO_SHIFT    = -1,
    LSL         = 0x0,
    LSR         = 0x1,
    ASR         = 0x2,
    ROR         = 0x3,
    MSL         = 0x4
};

enum Extend
{
  NO_EXTEND = -1,
  UXTB = 0,
  UXTH = 1,
  UXTW = 2,
  UXTX = 3,
  SXTB = 4,
  SXTH = 5,
  SXTW = 6,
  SXTX = 7
};

enum MemoryPermission
{
  kNoAccess,

  kRead = 1,
  kWrite = 2,
  kExecute = 4,

  kReadWrite = kRead | kWrite,
  kReadExecute = kRead | kExecute,
  kReadWriteExecute = kRead | kWrite | kExecute,
};

enum AddrMode
{
  Offset,
  PreIndex,
  PostIndex
};

#define KERN_RETURN_ERROR(kr, failure)                   \
  do                                                     \
  {                                                      \
    if (kr != KERN_SUCCESS)                              \
    {                                                    \
      printf("mach error: %s\n", mach_error_string(kr)); \
      return failure;                                    \
    }                                                    \
  } while (0);

#define PUBLIC __attribute__((visibility("default")))

typedef uintptr_t addr_t;

struct CodeMemBlock
{
  addr_t start_;
  size_t size;

  CodeMemBlock() : start_(0), size(0)
  {
  }

  CodeMemBlock(addr_t start, size_t size) : start_(start), size(size)
  {
  }
};

enum RegisterType
{
  kRegister_32,
  kRegister_W = kRegister_32,
  kRegister_64,
  kRegister_X = kRegister_64,
  kRegister,

  kVRegister,
  kSIMD_FP_Register_8,
  kSIMD_FP_Register_B = kSIMD_FP_Register_8,
  kSIMD_FP_Register_16,
  kSIMD_FP_Register_H = kSIMD_FP_Register_16,
  kSIMD_FP_Register_32,
  kSIMD_FP_Register_S = kSIMD_FP_Register_32,
  kSIMD_FP_Register_64,
  kSIMD_FP_Register_D = kSIMD_FP_Register_64,
  kSIMD_FP_Register_128,
  kSIMD_FP_Register_Q = kSIMD_FP_Register_128,

  kInvalid
};

// typedef CPURegister Register;
typedef struct Register_s
{
  int reg_id;
  int reg_size_;
  RegisterType reg_type_;
} CPURegister;

typedef CPURegister Register;


PUBLIC
int DobbyCodePatch(
    void *address,
    uint8_t *buffer,
    uint32_t buffer_size)
{
  if ((nullptr == address) ||
      (nullptr == buffer) ||
      (0 == buffer_size))
  {
    return -1;
  }

  size_t page_size = PAGE_SIZE;
  addr_t patch_page = ALIGN_FLOOR(address, page_size);
  addr_t remap_dest_page = patch_page;
  kern_return_t kr;

  // cross over page
  if ((addr_t)address + buffer_size > patch_page + page_size)
  {
    void *address_a = address;
    uint8_t *buffer_a = buffer;
    uint32_t buffer_size_a = (patch_page + page_size - (addr_t)address);
    auto ret = DobbyCodePatch(address_a, buffer_a, buffer_size_a);
    if (ret == -1)
    {
      return ret;
    }

    void *address_b = (void *)((addr_t)address + buffer_size_a);
    uint8_t *buffer_b = buffer + buffer_size_a;
    uint32_t buffer_size_b = buffer_size - buffer_size_a;
    ret = DobbyCodePatch(address_b, buffer_b, buffer_size_b);
    return ret;
  }

  printf("VM_PROTECT PART\n");

  static __typeof(vm_protect) *vm_protect_fn = nullptr;
  if (vm_protect_fn == nullptr)
  {
    vm_protect_fn = (__typeof(vm_protect) *)vm_protect_address;
    if (vm_protect_fn == nullptr)
    {
      vm_protect_fn = (__typeof(vm_protect) *)vm_protect_address;
    }
#if __has_feature(ptrauth_calls)
#include <ptrauth.h>
    ptrauth_sign_unauthenticated((void *)vm_protect_fn, ptrauth_key_asia, 0);
#endif
  }

  printf("TRYING this SHIT UP IN HERE, UP IN HERE - part 2\n");

  kr = vm_protect_fn(mach_task_self(),
                     remap_dest_page,
                     page_size,
                     false,
                     (VM_PROT_READ | VM_PROT_WRITE | VM_PROT_COPY));

  KERN_RETURN_ERROR(kr, -1);

  memcpy((void *)(patch_page + ((uint64_t)address - remap_dest_page)),
         buffer,
         buffer_size);

  kr = vm_protect_fn(mach_task_self(),
                     remap_dest_page,
                     page_size,
                     false,
                     VM_PROT_READ | VM_PROT_EXECUTE);

  KERN_RETURN_ERROR(kr, -1);

  return 0;
}

struct Trampoline
{
  int type;
  CodeMemBlock buffer;
  Trampoline *forward_trampoline;
};

struct Interceptor
{
  struct Entry
  {
    uint32_t id = 0;

    struct
    {
      bool arm_thumb_mode;
    } features;

    addr_t fake_func_addr;

    addr_t addr;

    CodeMemBlock patched;
    CodeMemBlock relocated;

    InterceptRouting *routing;

    uint8_t *origin_code_ = 0;

    Entry(addr_t addr)
    {
      this->addr = addr;
    }

    ~Entry()
    {
    }

    void backup_orig_code()
    {
      auto orig = (uint8_t *)this->addr;
      uint32_t tramp_size = this->patched.size;
      origin_code_ = (uint8_t *)operator new(tramp_size);
      memcpy(origin_code_, orig, tramp_size);
    }

    void restore_orig_code()
    {
      DobbyCodePatch((void *)patched.start_, origin_code_, patched.size);
      operator delete(origin_code_);
      origin_code_ = nullptr;
    }
  };

  std::vector<Entry *> entries;

  static Interceptor *Shared();

  Entry *find(addr_t addr)
  {
    for (auto *entry : entries)
    {
      if (entry->patched.start_ == addr)
      {
        return entry;
      }
    }
    return nullptr;
  }

  Entry *remove(addr_t addr)
  {
    for (auto iter = entries.begin(); iter != entries.end(); iter++)
    {
      Entry *entry = *iter;
      if (entry->patched.start_ == addr)
      {
        entries.erase(iter);
        return entry;
      }
    }
    return nullptr;
  }

  void add(Entry *entry)
  {
    entries.push_back(entry);
  }

  const Entry *get(int i)
  {
    return entries[i];
  }

  int count() const
  {
    return entries.size();
  }
};


typedef struct ref_inst_t
{
    int link_type;
    size_t inst_offset;
} ref_inst_t;

struct PseudoLabel
{
  CodeMemBuffer *code_buffer;
  size_t ref_insts_count;
  ref_inst_t* ref_insts;
  addr_t pc_offset;
};

void
    PseudoLabel_link_to
    (
        PseudoLabel* label,
        int link_type,
        size_t pc_offset
    )
{
    label->ref_insts_count++;
    label->ref_insts = (ref_inst_t*)realloc(label->ref_insts, label->ref_insts_count * sizeof(ref_inst_t));

    if( NULL == label->ref_insts )
    {
        // Handle memory allocation failure
        return;
    }

    label->ref_insts[ label->ref_insts_count - 1 ].link_type    = link_type;
    label->ref_insts[ label->ref_insts_count - 1 ].inst_offset  = pc_offset;
}

struct RelocDataLabel
{
  PseudoLabel label;
  uint8_t data_[8];
  uint8_t data_size_;
};

typedef struct CodeMemBuffer {
    uint8_t *buffer;
    uint32_t buffer_size;
    uint32_t buffer_capacity;
} CodeMemBuffer;

void
    CodeMemBuffer_emit
    (
        CodeMemBuffer *code_buffer,
        uint8_t *in_buffer,
        int size
    )
{
  // Ensure capacity
  if (code_buffer->buffer_size + size > code_buffer->buffer_capacity)
  {
    uint32_t new_capacity = code_buffer->buffer_capacity * 2;
    while (new_capacity < code_buffer->buffer_size + size)
    {
        new_capacity *= 2;
    }
    uint8_t *new_buffer = (uint8_t *)realloc(code_buffer->buffer, new_capacity);
    if (new_buffer == NULL)
    {
        // Handle memory allocation failure
        return;
    }
    code_buffer->buffer = new_buffer;
    code_buffer->buffer_capacity = new_capacity;
  }
  // Copy the input buffer into the code buffer
  memcpy(code_buffer->buffer + code_buffer->buffer_size, in_buffer, size);
  code_buffer->buffer_size += size;
}

static inline uint32_t encode_imm19_offset(uint32_t instr, int64_t offset)
{
  uint32_t imm19 = bits((offset >> 2), 0, 18);
  set_bits(instr, 5, 23, imm19);
  return instr;
}

void
  PseudoLabel_link_confused_instructions
  (
    PseudoLabel* label,
    CodeMemBuffer* buffer
  )
{
  printf( "CAW CAW MOTHERFUCKER\n" );
  for( size_t i = 0; i < label->ref_insts_count; ++i )
  {
    int64_t fixup_offset = label->pc_offset - label->ref_insts[i].inst_offset;

    uint32_t inst = *(int32_t*)( buffer->buffer + label->ref_insts[i].inst_offset );
    uint32_t new_inst = 0;

    if (label->ref_insts[i].link_type == 0) {
        new_inst = encode_imm19_offset(inst, fixup_offset);
    }

    *(int32_t*)( buffer->buffer + label->ref_insts[i].inst_offset ) = new_inst;
  }
}

Register InvalidRegister = { 0, 0, kInvalid };

struct Operand
{
  int64_t immediate_;
  Register reg_;

  Shift shift_;
  Extend extend_;
  int32_t shift_extend_imm_;

  inline explicit Operand(int64_t imm)
      : immediate_(imm), reg_(InvalidRegister), shift_(NO_SHIFT), extend_(NO_EXTEND), shift_extend_imm_(0)
  {
  }
  inline Operand(Register reg, Shift shift = LSL, int32_t shift_imm = 0)
      : immediate_(0), reg_(reg), shift_(shift), extend_(NO_EXTEND), shift_extend_imm_(shift_imm)
  {
  }
  inline Operand(Register reg, Extend extend, int32_t shift_imm = 0)
      : immediate_(0), reg_(reg), shift_(NO_SHIFT), extend_(extend), shift_extend_imm_(shift_imm)
  {
  }

  bool IsImmediate() const
  {
    // return reg_.Is(InvalidRegister);
    return ( reg_.reg_id == 0 );
  }
};

struct MemOperand
{
  Register base_;
  Register reg_offset_;
  int64_t offset_;

  Shift shift_;
  Extend extend_;
  uint32_t shift_extend_imm_;

  AddrMode addrmode_;

  inline explicit MemOperand(Register base, int64_t offset = 0, AddrMode addrmode = Offset)
      : base_(base), reg_offset_(InvalidRegister), offset_(offset), addrmode_(addrmode), shift_(NO_SHIFT),
        extend_(NO_EXTEND), shift_extend_imm_(0)
  {
  }

  inline explicit MemOperand(Register base, Register regoffset, Extend extend, unsigned extend_imm)
      : base_(base), reg_offset_(regoffset), offset_(0), addrmode_(Offset), shift_(NO_SHIFT), extend_(extend),
        shift_extend_imm_(extend_imm)
  {
  }

  inline explicit MemOperand(Register base, Register regoffset, Shift shift = LSL, unsigned shift_imm = 0)
      : base_(base), reg_offset_(regoffset), offset_(0), addrmode_(Offset), shift_(shift), extend_(NO_EXTEND),
        shift_extend_imm_(shift_imm)
  {
  }

  inline explicit MemOperand(Register base, const Operand &offset, AddrMode addrmode = Offset)
      : base_(base), reg_offset_(InvalidRegister), addrmode_(addrmode)
  {
    if( offset.shift_ != NO_SHIFT ) // if (offset.IsShiftedRegister())
    {
      reg_offset_ = offset.reg_;
      shift_ = offset.shift_;
      shift_extend_imm_ = offset.shift_extend_imm_; // shift_extend_imm();

      extend_ = NO_EXTEND;
      offset_ = 0;
    }
    else if( offset.extend_ != NO_EXTEND ) // else if (offset.IsExtendedRegister())
    {
      reg_offset_ = offset.reg_;
      extend_ = offset.extend_;
      shift_extend_imm_ = offset.shift_extend_imm_; // shift_extend_imm();

      shift_ = NO_SHIFT;
      offset_ = 0;
    }
  }

  const Register &base() const
  {
    return base_;
  }
  const Register &regoffset() const
  {
    return reg_offset_;
  }
  int64_t offset() const
  {
    return offset_;
  }
  AddrMode addrmode() const
  {
    return addrmode_;
  }
  Shift shift() const
  {
    return shift_;
  }
  Extend extend() const
  {
    return extend_;
  }
  unsigned shift_extend_imm() const
  {
    return shift_extend_imm_;
  }

  bool IsImmediateOffset() const
  {
    return (addrmode_ == Offset);
  }
  bool IsRegisterOffset() const
  {
    return (addrmode_ == Offset);
  }
  bool IsPreIndex() const
  {
    return addrmode_ == PreIndex;
  }
  bool IsPostIndex() const
  {
    return addrmode_ == PostIndex;
  }
};

struct AssemblerBase
{
  addr_t fixed_addr;
  CodeMemBuffer code_buffer_;
  std::vector<RelocDataLabel *> data_labels;

  explicit AssemblerBase(addr_t fixed_addr)
  {
    this->fixed_addr = fixed_addr;
    code_buffer_.buffer = (uint8_t *)malloc( 64 );
    code_buffer_.buffer_size = 0;
    code_buffer_.buffer_capacity = 64;
  }

  ~AssemblerBase()
  {
    free( code_buffer_.buffer );
  }

  size_t pc_offset()
  {
    return code_buffer_.buffer_size;
  }

  void set_fixed_addr(addr_t in_fixed_addr)
  {
    this->fixed_addr = in_fixed_addr;
  }

  CodeMemBuffer *code_buffer()
  {
    return &code_buffer_;
  }

  // --- label

  RelocDataLabel *createDataLabel(uint64_t data)
  {
    printf( "Making a createDataLabel()\n" );
    // auto data_label = new RelocDataLabel(data);
    RelocDataLabel *data_label = (RelocDataLabel *)malloc(sizeof(RelocDataLabel));
    if (data_label == NULL)
        return NULL;

    memcpy( data_label->data_, &data, sizeof( uint64_t ) );

    data_label->data_size_ = (uint8_t)sizeof( uint64_t );
    data_label->label.ref_insts_count = 0;
    data_label->label.pc_offset = 0;
    data_labels.push_back(data_label);
    return data_label;
  }

  void bindLabel(PseudoLabel *label)
  {
    // label->bind_to(pc_offset());
    label->pc_offset = code_buffer_.buffer_size;
    if( 0 != label->ref_insts_count )
    {
      // label->ref_insts_count;
      PseudoLabel_link_confused_instructions( label, &code_buffer_ );
      // label->link_confused_instructions(&code_buffer_);
    }
  }

  void relocDataLabels()
  {
    for (auto *data_label : data_labels)
    {
      bindLabel(&data_label->label);
      CodeMemBuffer_emit( &code_buffer_, data_label->data_, data_label->data_size_ );
      // code_buffer_.emit(data_label->data_, data_label->data_size_);
    }
  }
};


  // LoadStore
static int32_t OpEncode_LoadStorePair( LoadStorePairOp op, CPURegister rt, CPURegister rt2, const MemOperand &addr )
{
    int32_t scale = 2;
    int32_t opc = 0;
    int imm7;
    opc = bits(op, 30, 31);
    if( rt.reg_type_ < kRegister ) // if (rt.IsRegister())
    {
      scale += bit(opc, 1);
    }
    else if( rt.reg_type_ > kVRegister ) // (rt.IsVRegister())
    {
      scale += opc;
    }

    imm7 = (int)(addr.offset() >> scale);
    return LeftShift(imm7, 7, 15);
}

// register operation size, 32 bits or 64 bits
static int32_t OpEncode_sf(const Register &reg)
{
    if( reg.reg_size_ == 64 ) // if (reg.Is64Bits())
      return LeftShift(1, 1, 31);
    return 0;
}

// LogicalShift
static int32_t OpEncode_EncodeLogicalShift(const Register &rd, const Register &rn, const Operand &operand)
{
    return( OpEncode_sf( rd )
            | LeftShift( operand.shift_, 2, 22 )
            | Rm( operand.reg_ )
            | LeftShift( operand.shift_extend_imm_, 6, 10 )
            | Rn( rn )
            | Rd( rd ) );
}

// LogicalImmeidate
static int32_t OpEncode_EncodeLogicalImmediate(const Register &rd, const Register &rn, const Operand &operand)
{
  int64_t imm = operand.immediate_;
  int32_t N, imms, immr;
  immr = bits(imm, 0, 5);
  imms = bits(imm, 6, 11);
  N = bit(imm, 12);

  return (OpEncode_sf(rd) | LeftShift(immr, 6, 16) | LeftShift(imms, 6, 10) | Rd(rd) | Rn(rn));
}



struct ExternalReference
{
  void *address;

  explicit ExternalReference(void *address) : address(address)
  {
#if __has_feature(ptrauth_calls) || __arm64e__
    address = ptrauth_strip(address);
#endif
  }
};

static inline uint16_t Low16Bits(uint32_t value)
{
  return static_cast<uint16_t>(value & 0xffff);
}

static inline uint16_t High16Bits(uint32_t value)
{
  return static_cast<uint16_t>(value >> 16);
}

static inline uint32_t Low32Bits(uint64_t value)
{
  return static_cast<uint32_t>(value);
}

static inline uint32_t High32Bits(uint64_t value)
{
  return static_cast<uint32_t>(value >> 32);
}

#define W(code) (CPURegister){ code, 32, kRegister_32 }
#define X(code) (CPURegister){ code, 64, kRegister_64 }
#define ARM64_TMP_REG_NDX_0 17

static const Register TMP_REG_0 = X(ARM64_TMP_REG_NDX_0);
static const Register SP = (Register){ 31, 64, kRegister_64 };
static const Register xzr = (Register){ 31, 64, kRegister_64 };
static const Register wzr = (Register){ 31, 32, kRegister_32 };

struct Assembler : AssemblerBase
{
  Assembler(addr_t fixed_addr) : AssemblerBase(fixed_addr)
  {
  }

  ~Assembler()
  {
  }

  void Emit(uint32_t value)
  {
    // code_buffer_.Emit<uint32_t>(value);
    // code_buffer_.buffer;
    CodeMemBuffer_emit( &code_buffer_, (uint8_t*)&value, sizeof( uint32_t ) );
  }

  void EmitInt64(int64_t value)
  {
    // code_buffer_.Emit<int64_t>(value);
    CodeMemBuffer_emit( &code_buffer_, (uint8_t*)&value, sizeof( int64_t ) );
  }

  // void bind(Label *label);

  void nop()
  {
    Emit(0xD503201F);
  }

  void brk(int code)
  {
    Emit(BRK | LeftShift(code, 16, 5));
  }

  void ret()
  {
    Emit(0xD65F03C0);
  }

  void adrp(const Register &rd, int64_t imm)
  {
    uint32_t immlo = LeftShift(bits(imm >> 12, 0, 1), 2, 29);
    uint32_t immhi = LeftShift(bits(imm >> 12, 2, 20), 19, 5);
    Emit(ADRP | Rd(rd) | immlo | immhi);
  }

  void add(const Register &rd, const Register &rn, int64_t imm)
  {
    if( rd.reg_size_ == 64 && rn.reg_size_ == 64 ) // if (rd.Is64Bits() && rn.Is64Bits())
      AddSubImmediate(rd, rn, Operand(imm), ADD_x_imm);
    else
      AddSubImmediate(rd, rn, Operand(imm), ADD_w_imm);
  }

  void adds(const Register &rd, const Register &rn, int64_t imm)
  {
    printf("THIS CODE SHOULD BE UNREACHABLE\n");
  }
  void sub(const Register &rd, const Register &rn, int64_t imm)
  {
    if( rd.reg_size_ == 64 && rn.reg_size_ == 64 ) // if (rd.Is64Bits() && rn.Is64Bits())
      AddSubImmediate(rd, rn, Operand(imm), SUB_x_imm);
    else
      AddSubImmediate(rd, rn, Operand(imm), SUB_w_imm);
  }
  void subs(const Register &rd, const Register &rn, int64_t imm)
  {
    printf("THIS CODE SHOULD BE UNREACHABLE\n");
  }

  void b(int64_t imm)
  {
    int32_t imm26 = bits(imm >> 2, 0, 25);
    Emit(B | imm26);
  }

  void br(Register rn)
  {
    Emit(BR | Rn(rn));
  }

  void blr(Register rn)
  {
    Emit(BLR | Rn(rn));
  }

  void ldr(Register rt, int64_t imm)
  {
    LoadRegLiteralOp op;
    switch ( rt.reg_type_ )
    {
    // case CPURegister::kRegister_32:
    case kRegister_32:
      op = LDR_w_literal;
      break;
    // case CPURegister::kRegister_X:
    case kRegister_X:
      op = LDR_x_literal;
      break;
    // case CPURegister::kSIMD_FP_Register_S:
    case kSIMD_FP_Register_S:
      op = LDR_s_literal;
      break;
    // case CPURegister::kSIMD_FP_Register_D:
    case kSIMD_FP_Register_D:
      op = LDR_d_literal;
      break;
    // case CPURegister::kSIMD_FP_Register_Q:
    case kSIMD_FP_Register_Q:
      op = LDR_q_literal;
      break;
    default:
      printf("THIS CODE SHOULD BE UNREACHABLE\n");
      break;
    }
    EmitLoadRegLiteral(op, rt, imm);
  }

  void ldr(const CPURegister &rt, const MemOperand &src)
  {
    LoadStore(LDR_x, rt, src);
  }

  void str(const CPURegister &rt, const MemOperand &src)
  {
    LoadStore(STR_x, rt, src);
  }

  void ldp(const Register &rt, const Register &rt2, const MemOperand &src)
  {
    if (rt.reg_type_ == kSIMD_FP_Register_128)
    {
      LoadStorePair(LDP_q, rt, rt2, src);
    }
    else if (rt.reg_type_ == kRegister_X)
    {
      LoadStorePair(LDP_x, rt, rt2, src);
    }
    else
    {
      printf("THIS CODE SHOULD BE UNREACHABLE\n");
    }
  }

  void stp(const Register &rt, const Register &rt2, const MemOperand &dst)
  {
    if (rt.reg_type_ == kSIMD_FP_Register_128)
    {
      LoadStorePair(STP_q, rt, rt2, dst);
    }
    else if (rt.reg_type_ == kRegister_X)
    {
      LoadStorePair(STP_x, rt, rt2, dst);
    }
    else
    {
      printf("THIS CODE SHOULD BE UNREACHABLE\n");
    }
  }

  void mov(const Register &rd, const Register &rn)
  {
    // if( ( rd.Is(SP) ) || ( rn.Is(SP) ) )
    if( ( rd.reg_id == SP.reg_id ) || ( rn.reg_id == SP.reg_id ) )
    {
      add(rd, rn, 0);
    }
    else
    {
      if( rd.reg_size_ == 64 ) // if (rd.Is64Bits())
        orr(rd, xzr, Operand(rn));
      else
        orr(rd, wzr, Operand(rn));
    }
  }
  void movk(const Register &rd, uint64_t imm, int shift = -1)
  {
    MoveWide(rd, imm, shift, MOVK);
  }
  void movz(const Register &rd, uint64_t imm, int shift = -1)
  {
    MoveWide(rd, imm, shift, MOVZ);
  }

  void orr(const Register &rd, const Register &rn, const Operand &operand)
  {
    Logical(rd, rn, operand, ORR);
  }

private:
  // load helpers.
  void EmitLoadRegLiteral(LoadRegLiteralOp op, CPURegister rt, int64_t imm)
  {
    const int32_t encoding = op | LeftShift(imm >> 2, 26, 5) | Rt(rt);
    Emit(encoding);
  }

  void LoadStore(LoadStoreOp op, CPURegister rt, const MemOperand &addr)
  {
    int64_t imm12 = addr.offset();
    if (addr.IsImmediateOffset())
    {
      // TODO: check Scaled ???
      int scale = 0;
      if ((op & LoadStoreUnsignedOffsetFixed) == LoadStoreUnsignedOffsetFixed)
      {
        scale = bits(op, 30, 31);
      }
      imm12 = addr.offset() >> scale;
      Emit(LoadStoreUnsignedOffsetFixed | op | LeftShift(imm12, 12, 10) | Rn(addr.base()) | Rt(rt));
    }
    else if (addr.IsRegisterOffset())
    {
      printf("THIS CODE SHOULD BE UNREACHABLE\n");
    }
    else
    {
      printf("THIS CODE SHOULD BE UNREACHABLE\n");
    }
  }

  void LoadStorePair(LoadStorePairOp op, CPURegister rt, CPURegister rt2, const MemOperand &addr)
  {
    int32_t combine_fields_op = OpEncode_LoadStorePair(op, rt, rt2, addr) | Rt2(rt2) | Rn(addr.base()) | Rt(rt);
    int32_t addrmodeop;

    if (addr.IsImmediateOffset())
    {
      addrmodeop = LoadStorePairOffsetFixed;
    }
    else
    {
      if (addr.IsPreIndex())
      {
        addrmodeop = LoadStorePairPreIndexFixed;
      }
      else
      {
        addrmodeop = LoadStorePairPostIndexFixed;
      }
    }
    Emit(op | addrmodeop | combine_fields_op);
  }

  void MoveWide(Register rd, uint64_t imm, int shift, MoveWideImmediateOp op)
  {
    if (shift > 0)
      shift /= 16;
    else
      shift = 0;

    int32_t imm16 = LeftShift(imm, 16, 5);
    Emit(MoveWideImmediateFixed | op | OpEncode_sf(rd) | LeftShift(shift, 2, 21) | imm16 | Rd(rd));
  }

  void AddSubImmediate(const Register &rd, const Register &rn, const Operand &operand, AddSubImmediateOp op)
  {
    if (operand.IsImmediate())
    {
      int64_t immediate = operand.immediate_;
      int32_t imm12 = LeftShift(immediate, 12, 10);
      Emit(op | Rd(rd) | Rn(rn) | imm12);
    }
    else
    {
      printf("THIS CODE SHOULD BE UNREACHABLE\n");
    }
  }

  void Logical(const Register &rd, const Register &rn, const Operand &operand, LogicalOp op)
  {
    if (operand.IsImmediate())
    {
      LogicalImmediate(rd, rn, operand, op);
    }
    else
    {
      LogicalShift(rd, rn, operand, op);
    }
  }
  void LogicalImmediate(const Register &rd, const Register &rn, const Operand &operand, LogicalOp op)
  {
    int32_t combine_fields_op = OpEncode_EncodeLogicalImmediate(rd, rn, operand);
    Emit(op | combine_fields_op);
  }
  void LogicalShift(const Register &rd, const Register &rn, const Operand &operand, LogicalOp op)
  {
    int32_t combine_fields_op = OpEncode_EncodeLogicalShift(rd, rn, operand);
    Emit(op | LogicalShiftedFixed | combine_fields_op);
  }
};

struct TurboAssembler : Assembler
{
public:
  TurboAssembler() : TurboAssembler(0)
  {
  }

  TurboAssembler(addr_t fixed_addr) : Assembler(fixed_addr)
  {
  }

  ~TurboAssembler()
  {
  }

  void CallFunction(ExternalReference function)
  {
    Mov(TMP_REG_0, (uint64_t)function.address);
    blr(TMP_REG_0);
  }

  void Ldr(Register rt, PseudoLabel *label)
  {
    // label->link_to(kLabelImm19, pc_offset());

    PseudoLabel_link_to( label, kLabelImm19, pc_offset() );
    ldr(rt, 0);
  }

  void Mov(Register rd, uint64_t imm)
  {
    const uint32_t w0 = Low32Bits(imm);
    const uint32_t w1 = High32Bits(imm);
    const uint16_t h0 = Low16Bits(w0);
    const uint16_t h1 = High16Bits(w0);
    const uint16_t h2 = Low16Bits(w1);
    const uint16_t h3 = High16Bits(w1);
    movz(rd, h0, 0);
    movk(rd, h1, 16);
    movk(rd, h2, 32);
    movk(rd, h3, 48);
  }

  void AdrpAdd(Register rd, uint64_t from, uint64_t to)
  {
    uint64_t from_PAGE = ALIGN(from, 0x1000);
    uint64_t to_PAGE = ALIGN(to, 0x1000);
    uint64_t to_PAGEOFF = (uint64_t)to % 0x1000;

    adrp(rd, to_PAGE - from_PAGE);
    add(rd, rd, to_PAGEOFF);
  }
};

class CodeGenBase
{
public:
  CodeGenBase(AssemblerBase *assembler) : assembler_(assembler)
  {
  }

protected:
  AssemblerBase *assembler_;
};

class CodeGen : public CodeGenBase
{
public:
  CodeGen(TurboAssembler *turbo_assembler) : CodeGenBase(turbo_assembler)
  {
  }
  void LiteralLdrBranch(uint64_t address)
  {
    auto turbo_assembler_ = reinterpret_cast<TurboAssembler *>(this->assembler_);

    auto label = turbo_assembler_->createDataLabel(address);
    turbo_assembler_->Ldr(TMP_REG_0, &label->label);
    turbo_assembler_->br(TMP_REG_0);
  }
};

Trampoline *GenerateNormalTrampolineBuffer(addr_t from, addr_t to)
{
  // this->fixed_addr = from
  TurboAssembler turbo_assembler_(from);
  int tramp_type = 0;
  uint64_t distance = llabs((int64_t)(from - to));
  uint64_t adrp_range = UINT32_MAX - 1; // ((uint64_t)1 << (2 + 19 + 12 - 1));
  if (distance < adrp_range)
  {
    tramp_type = TRAMPOLINE_ARM64_ADRP_ADD_BR;
    turbo_assembler_.AdrpAdd(TMP_REG_0, from, to);
    turbo_assembler_.br(TMP_REG_0);
  }
  else
  {
    tramp_type = TRAMPOLINE_ARM64_LDR_BR;
    CodeGen codegen(&turbo_assembler_);
    codegen.LiteralLdrBranch((uint64_t)to);
  }

  // bind all labels
  turbo_assembler_.relocDataLabels();

  auto tramp_buffer = turbo_assembler_.code_buffer();
  // auto tramp_block = tramp_buffer->dup();

  uint8_t *copy_buf = (uint8_t *)operator new( tramp_buffer->buffer_size );
  memcpy(copy_buf, tramp_buffer->buffer, tramp_buffer->buffer_size);

  Trampoline* tramp = (Trampoline*)malloc( sizeof( Trampoline ) );
  tramp->type = tramp_type;
  tramp->buffer.start_ = (addr_t)copy_buf;
  tramp->buffer.size = tramp_buffer->buffer_size;
  return tramp;
}

struct relo_ctx_t
{
  addr_t cursor;
  uint32_t relocated_insn_count;

  CodeMemBlock *origin;
  CodeMemBlock relocated{};
  CodeMemBuffer *relocated_buffer;

  explicit relo_ctx_t(CodeMemBlock *origin) : origin(origin)
  {
    cursor = origin->start_;
  }

  uint32_t preferred_relo_size()
  {
    return origin->size;
  }

  void correct_final_relo_size()
  {
    origin->size = relo_size(); //  resize(relo_size());
  }

  uint32_t relo_size()
  {
    return (uintptr_t)cursor - origin->start_;
  }

  addr_t origin_start()
  {
    return origin->start_;
  }

  addr_t origin_cursor()
  {
    return origin->start_ + relo_size();
  }

  uint32_t origin_off()
  {
    return (uintptr_t)cursor - origin->start_;
  }

  addr_t relocated_start()
  {
    return relocated.start_;
  }

  addr_t relocated_cursor()
  {
    return relocated.start_ + relocated_buffer->buffer_size;
  }

  uint32_t relocated_off()
  {
    return relocated_buffer->buffer_size;
  }

  void record_relo_start()
  {
    printf("relo: origin_off: %p, relocated_off: %p\n", origin_off(), relocated_off());
  }

  int relocate(bool branch);
};

static inline bool inst_is_b_bl(uint32_t instr)
{
  return (instr & UnconditionalBranchFixedMask) == UnconditionalBranchFixed;
}
static inline bool inst_is_ldr_literal(uint32_t instr)
{
  return ((instr & LoadRegLiteralFixedMask) == LoadRegLiteralFixed);
}
static inline bool inst_is_adr(uint32_t instr)
{
  return (instr & PCRelAddressingFixedMask) == PCRelAddressingFixed && (instr & PCRelAddressingMask) == ADR;
}
static inline bool inst_is_adrp(uint32_t instr)
{
  return (instr & PCRelAddressingFixedMask) == PCRelAddressingFixed && (instr & PCRelAddressingMask) == ADRP;
}
static inline bool inst_is_b_cond(uint32_t instr)
{
  return (instr & ConditionalBranchFixedMask) == ConditionalBranchFixed;
}
static inline bool inst_is_compare_b(uint32_t instr)
{
  return (instr & CompareBranchFixedMask) == CompareBranchFixed;
}
static inline bool inst_is_test_b(uint32_t instr)
{
  return (instr & TestBranchFixedMask) == TestBranchFixed;
}

static inline int64_t SignExtend(unsigned long x, int M, int N)
{
  char sign_bit = bit(x, M - 1);
  unsigned long sign_mask = 0 - sign_bit;
  x |= ((sign_mask >> M) << M);
  return (int64_t)x;
}

static inline int decode_rt(uint32_t instr)
{
  return bits(instr, 0, 4);
}
static inline int decode_rd(uint32_t instr)
{
  return bits(instr, 0, 4);
}

static inline int64_t decode_imm26_offset(uint32_t instr)
{
  int64_t offset;
  {
    int64_t imm26 = bits(instr, 0, 25);
    offset = (imm26 << 2);
  }
  offset = SignExtend(offset, 2 + 26, 64);
  return offset;
}
static inline int64_t decode_imm19_offset(uint32_t instr)
{
  int64_t offset;
  {
    int64_t imm19 = bits(instr, 5, 23);
    offset = (imm19 << 2);
  }
  offset = SignExtend(offset, 2 + 19, 64);
  return offset;
}
static inline int64_t decode_immhi_immlo_offset(uint32_t instr)
{
  typedef uint32_t instr_t;
  struct
  {
    instr_t Rd : 5;      // Destination register
    instr_t immhi : 19;  // 19-bit upper immediate
    instr_t dummy_0 : 5; // Must be 10000 == 0x10
    instr_t immlo : 2;   // 2-bit lower immediate
    instr_t op : 1;      // 0 = ADR, 1 = ADRP
  } instr_decode;

  *(instr_t *)&instr_decode = instr;

  int64_t imm = instr_decode.immlo + (instr_decode.immhi << 2);
  imm = SignExtend(imm, 2 + 19, 64);
  return imm;
}
static inline int64_t decode_immhi_immlo_zero12_offset(uint32_t instr)
{
  int64_t imm = decode_immhi_immlo_offset(instr);
  imm = imm << 12;
  return imm;
}
static inline int64_t decode_imm14_offset(uint32_t instr)
{
  int64_t offset;
  {
    int64_t imm14 = bits(instr, 5, 18);
    offset = (imm14 << 2);
  }
  offset = SignExtend(offset, 2 + 14, 64);
  return offset;
}

struct simple_linear_allocator_t
{
  uint8_t *buffer;
  uint32_t size = 0;
  uint32_t capacity;
  uint32_t builtin_alignment;

  simple_linear_allocator_t() = default;

  explicit simple_linear_allocator_t(uint8_t *buffer, uint32_t capacity, uint32_t alignment = 8)
  {
    init(buffer, capacity, alignment);
  }

  void init(uint8_t *in_buffer, uint32_t in_capacity, uint32_t in_alignment = 8)
  {
    buffer = in_buffer;
    capacity = in_capacity;
    builtin_alignment = in_alignment;
    if (builtin_alignment == 0)
    {
      builtin_alignment = 1;
    }
    size = 0;
  }

  uint8_t *alloc(uint32_t in_size, uint32_t in_alignment = 0)
  {
    auto alignment = in_alignment ? in_alignment : builtin_alignment;
    uint32_t gap_size = ALIGN_CEIL((uintptr_t)cursor(), alignment) - (uintptr_t)cursor();
    size += gap_size;

    if (size + in_size > capacity)
    {
      return nullptr;
    }

    auto data = cursor();
    // DEBUG_LOG("alloc: %p - %p", data, in_size);

    size += in_size;
    return data;
  }

  void free(uint8_t *buf)
  {
    // do nothing
  }

  uint8_t *cursor()
  {
    return buffer + size;
  }
};

void
    simple_linear_allocator_t_init
    (
        simple_linear_allocator_t *allocator,
        uint8_t *in_buffer,
        uint32_t in_capacity,
        uint32_t in_alignment
    )
{
    allocator->buffer = in_buffer;
    allocator->capacity = in_capacity;
    allocator->builtin_alignment = (in_alignment == 0) ? 1 : in_alignment;
    allocator->size = 0;
}

uint8_t*
    simple_linear_allocator_t_alloc
    (
        simple_linear_allocator_t *allocator,
        uint32_t in_size,
        uint32_t in_alignment
    )
{
    uint32_t alignment = in_alignment
                        ? in_alignment
                        : allocator->builtin_alignment;
    uint32_t gap_size = ALIGN_CEIL((uintptr_t)(allocator->buffer + allocator->size), alignment) - (uintptr_t)(allocator->buffer + allocator->size);
    allocator->size += gap_size;

    if (allocator->size + in_size > allocator->capacity)
    {
        return NULL;
    }

    uint8_t *data = allocator->buffer + allocator->size;
    allocator->size += in_size;
    return data;
}


const int kMmapFd = VM_MAKE_TAG(255);
const int kMmapFdOffset = 0;

static int GetProtectionFromMemoryPermission(MemoryPermission access)
{
  int prot = 0;
  if (access & MemoryPermission::kRead)
    prot |= PROT_READ;
  if (access & MemoryPermission::kWrite)
    prot |= PROT_WRITE;
  if (access & MemoryPermission::kExecute)
    prot |= PROT_EXEC;
  return prot;
}

static
int
    OSMemory_SetPermission
    (
        void *address,
        size_t size,
        MemoryPermission access
    )
{
    int prot = GetProtectionFromMemoryPermission(access);
    int ret = mprotect(address, size, prot);
    if (ret) {
        perror("OSMemory_SetPermission");
    }
    return ret == 0;
}

static
int
    OSMemory_PageSize
    (
        void
    )
{
    return (int)sysconf(_SC_PAGESIZE);
}

static
void*
    OSMemory_Allocate
    (
        size_t size,
        MemoryPermission access,
        void *fixed_address
    )
{
    int prot = GetProtectionFromMemoryPermission(access);
    int flags = MAP_PRIVATE | MAP_ANONYMOUS;
    if (fixed_address != NULL) {
        flags |= MAP_FIXED;
    }
    void *result = mmap(fixed_address, size, prot, flags, kMmapFd, kMmapFdOffset);
    if (result == MAP_FAILED)
        return NULL;
    return result;
}

// typedef struct MemoryAllocator {
//     simple_linear_allocator_t *code_page_allocators;
//     simple_linear_allocator_t *data_page_allocators;
//     size_t code_page_allocators_count;
//     size_t data_page_allocators_count;
// } MemoryAllocator;

struct MemoryAllocator
{
  std::vector<simple_linear_allocator_t> code_page_allocators;
  std::vector<simple_linear_allocator_t> data_page_allocators;

public:
  inline static MemoryAllocator *Shared();

  // // CodeMemBlock allocDataBlock(size_t in_size)
  // // {
  // //   if (in_size > OSMemory_PageSize())
  // //   {
  // //     //   ERROR_LOG("alloc size too large: %d", in_size);
  // //     return {};
  // //   }

  // //   uint8_t *result = 0;
  // //   for (auto &allocator : data_page_allocators)
  // //   {
  // //     result = (uint8_t *)allocator.alloc(in_size);
  // //     if (result)
  // //       break;
  // //   }

  // //   if (!result)
  // //   {
  // //     auto page = OSMemory_Allocate( OSMemory_PageSize(), kNoAccess, NULL );
  // //     OSMemory_SetPermission(page, OSMemory_PageSize(), kReadWrite);
  // //     auto page_allocator = simple_linear_allocator_t((uint8_t *)page, OSMemory_PageSize());
  // //     data_page_allocators.push_back(page_allocator);
  // //     result = (uint8_t *)data_page_allocators.back().alloc(in_size);
  // //   }
  // //   return CodeMemBlock((addr_t)result, in_size);
  // // }

  CodeMemBlock allocExecBlock(size_t size)
  {
    if (size > OSMemory_PageSize())
    {
      //   ERROR_LOG("alloc size too large: %d", size);
      return {};
    }

    uint8_t *result = 0;
    for (auto &allocator : code_page_allocators)
    {
      result = (uint8_t *)allocator.alloc(size);
      if (result)
        break;
    }

    if (!result)
    {
      auto page = OSMemory_Allocate( OSMemory_PageSize(), kNoAccess, NULL );
      OSMemory_SetPermission(page, OSMemory_PageSize(), kReadExecute);
      auto page_allocator = simple_linear_allocator_t((uint8_t *)page, OSMemory_PageSize());
      code_page_allocators.push_back(page_allocator);
      result = (uint8_t *)code_page_allocators.back().alloc(size);
    }
    return CodeMemBlock((addr_t)result, size);
  }
};

// void*
//     MemoryAllocator_allocExecBlock
//     (
//         MemoryAllocator *allocator,
//         size_t size
//     )
// {
//     if (size > OSMemory_PageSize()) {
//         // ERROR_LOG("alloc size too large: %d", size);
//         return NULL;
//     }

//     uint8_t *result = NULL;
//     for (size_t i = 0; i < allocator->code_page_allocators_count; ++i) {
//         printf( "doing iter on execblock\n" );
//         result = simple_linear_allocator_t_alloc(&allocator->code_page_allocators[i], size, 0);
//         if (result)
//             break;
//     }

//     if (!result) {
//       printf( "!result brah\n" );
//         void *page = OSMemory_Allocate(OSMemory_PageSize(), kNoAccess, NULL);
//         printf( "Chaning permissions...\n" );
//         OSMemory_SetPermission( page, OSMemory_PageSize(), kReadExecute );
//         printf( "Doing the simple linear allocator init\n" );
//         // label->ref_insts = (ref_inst_t*)realloc(label->ref_insts, label->ref_insts_count * sizeof(ref_inst_t));
//         allocator->code_page_allocators_count++;
//         allocator->code_page_allocators = (simple_linear_allocator_t*)realloc(allocator->code_page_allocators, allocator->code_page_allocators_count * sizeof(simple_linear_allocator_t));

//         simple_linear_allocator_t_init(&allocator->code_page_allocators[allocator->code_page_allocators_count - 1], (uint8_t *)page, OSMemory_PageSize(), 0);

//         printf( "Doing simple linear allocator alloc()\n" );
//         result = simple_linear_allocator_t_alloc(&allocator->code_page_allocators[allocator->code_page_allocators_count - 1], size, 0);
//     }
//     return result;
// }


inline static MemoryAllocator gMemoryAllocator;
// MemoryAllocator *MemoryAllocator::Shared()
// {
//   return &gMemoryAllocator;
// }

struct AssemblerCodeBuilder
{
  static CodeMemBlock FinalizeFromTurboAssembler(AssemblerBase *assembler)
  {
    auto code_buffer = assembler->code_buffer();
    auto fixed_addr = (addr_t)assembler->fixed_addr;

    if (!fixed_addr)
    {
      size_t buffer_size = 0;
      buffer_size = code_buffer->buffer_size;

      // #if TARGET_ARCH_ARM
      //       // extra bytes for align needed
      //       buffer_size += 4;
      // #endif

      auto block = gMemoryAllocator.allocExecBlock(buffer_size);
      printf( "making exec block\n" );
      // CodeMemBlock* block = (CodeMemBlock*)MemoryAllocator_allocExecBlock( &gMemoryAllocator, buffer_size );
      if (block.start_ == 0)
        return CodeMemBlock{};

      printf( "way way wyay way way way way way way way\n" );
      fixed_addr = block.start_;
      assembler->set_fixed_addr(fixed_addr);
    }

    DobbyCodePatch((void *)fixed_addr, code_buffer->buffer, code_buffer->buffer_size);

    return CodeMemBlock(fixed_addr, code_buffer->buffer_size);
  }
};

#define DEFINE_DATA_LABEL(data, name) auto name##_data_label = turbo_assembler_.createDataLabel(data);

int relo_ctx_t::relocate(bool branch)
{
  TurboAssembler turbo_assembler_;

  this->relocated_buffer = turbo_assembler_.code_buffer();

  while (relo_size() < preferred_relo_size())
  {
    // DEBUGL( LOG_INFO, "calling record_relo_start()\n" );
    record_relo_start();

    uint32_t inst = *(uint32_t *)origin_cursor();
    if (inst_is_b_bl(inst))
    {
      //   DEBUG_LOG("%d:relo <b_bl> at %p", relocated_insn_count++, origin_cursor());
      //   DEBUGL( LOG_INFO, "%d:relo <b_bl> at %p\n", relocated_insn_count++, origin_cursor() );

      int64_t offset = decode_imm26_offset(inst);
      addr_t dst = origin_cursor() + offset;
      DEFINE_DATA_LABEL(dst, dst);
      {
        turbo_assembler_.Ldr(TMP_REG_0, &dst_data_label->label);
        if ((inst & UnconditionalBranchMask) == BL)
        {
          turbo_assembler_.blr(TMP_REG_0);
        }
        else
        {
          turbo_assembler_.br(TMP_REG_0);
        }
      }
    }
    else if (inst_is_ldr_literal(inst))
    {
      //   DEBUG_LOG("%d:relo <ldr_literal> at %p", relocated_insn_count++, origin_cursor());
      //   DEBUGL( LOG_INFO, "%d:relo <ldr_literal> at %p\n", relocated_insn_count++, origin_cursor() );

      int64_t offset = decode_imm19_offset(inst);
      addr_t dst = origin_cursor() + offset;

      int rt = decode_rt(inst);
      char opc = bits(inst, 30, 31);

      {
        turbo_assembler_.Mov(TMP_REG_0, dst);
        if (opc == 0b00)
          turbo_assembler_.ldr(W(rt), MemOperand(TMP_REG_0, 0));
        else if (opc == 0b01)
          turbo_assembler_.ldr(X(rt), MemOperand(TMP_REG_0, 0));
        else
        {
          printf("UNIMPLEMENTED\n");
        }
      }
    }
    else if (inst_is_adr(inst))
    {
      //   DEBUG_LOG("%d:relo <adr> at %p", relocated_insn_count++, origin_cursor());
      //   DEBUGL( LOG_INFO, "%d:relo <adr> at %p\n", relocated_insn_count++, origin_cursor() );

      int64_t offset = decode_immhi_immlo_offset(inst);
      addr_t dst = origin_cursor() + offset;

      int rd = decode_rd(inst);

      {
        turbo_assembler_.Mov(X(rd), dst);
        ;
      }
    }
    else if (inst_is_adrp(inst))
    {
      //   DEBUG_LOG("%d:relo <adrp> at %p", relocated_insn_count++, origin_cursor());
      //   DEBUGL( LOG_INFO, "%d:relo <adrp> at %p\n", relocated_insn_count++, origin_cursor() );

      int64_t offset = decode_immhi_immlo_zero12_offset(inst);
      addr_t dst = origin_cursor() + offset;
      dst = arm64_trunc_page(dst);

      int rd = decode_rd(inst);

      {
        turbo_assembler_.Mov(X(rd), dst);
        ;
      }
    }
    else if (inst_is_b_cond(inst))
    {
      //   DEBUG_LOG("%d:relo <b_cond> at %p", relocated_insn_count++, origin_cursor());
      //   DEBUGL( LOG_INFO, "%d:relo <b_cond> at %p\n", relocated_insn_count++, origin_cursor() );

      int64_t offset = decode_imm19_offset(inst);
      addr_t dst = origin_cursor() + offset;

      uint32_t branch_inst = inst;
      {
        char cond = bits(inst, 0, 3);
        cond = cond ^ 1;
        set_bits(branch_inst, 0, 3, cond);

        int64_t offset = 4 * 3;
        uint32_t imm19 = offset >> 2;
        set_bits(branch_inst, 5, 23, imm19);
      }

      DEFINE_DATA_LABEL(dst, dst);

      {
        turbo_assembler_.Emit(branch_inst);
        {
          turbo_assembler_.Ldr(TMP_REG_0, &dst_data_label->label);
          turbo_assembler_.br(TMP_REG_0);
        }
      }
    }
    else if (inst_is_compare_b(inst))
    {
      //   DEBUG_LOG("%d:relo <compare_b> at %p", relocated_insn_count++, origin_cursor());
      //   DEBUGL( LOG_INFO, "%d:relo <compare_b> at %p\n", relocated_insn_count++, origin_cursor() );

      int64_t offset = decode_imm19_offset(inst);
      addr_t dst = origin_cursor() + offset;

      uint32_t branch_inst = inst;
      {
        char op = bit(inst, 24);
        op = op ^ 1;
        set_bit(branch_inst, 24, op);

        int64_t offset = 4 * 3;
        uint32_t imm19 = offset >> 2;
        set_bits(branch_inst, 5, 23, imm19);
      }

      DEFINE_DATA_LABEL(dst, dst);

      {
        turbo_assembler_.Emit(branch_inst);
        {
          turbo_assembler_.Ldr(TMP_REG_0, &dst_data_label->label);
          turbo_assembler_.br(TMP_REG_0);
        }
      }
    }
    else if (inst_is_test_b(inst))
    {
      //   DEBUG_LOG("%d:relo <test_b> at %p", relocated_insn_count++, origin_cursor());
      //   DEBUGL( LOG_INFO, "%d:relo <test_b> at %p\n", relocated_insn_count++, origin_cursor() );

      int64_t offset = decode_imm14_offset(inst);
      addr_t dst = origin_cursor() + offset;

      uint32_t branch_inst = inst;
      {
        char op = bit(inst, 24);
        op = op ^ 1;
        set_bit(branch_inst, 24, op);

        int64_t offset = 4 * 3;
        uint32_t imm14 = offset >> 2;
        set_bits(branch_inst, 5, 18, imm14);
      }

      DEFINE_DATA_LABEL(dst, dst);

      {
        turbo_assembler_.Emit(branch_inst);
        {
          turbo_assembler_.Ldr(TMP_REG_0, &dst_data_label->label);
          turbo_assembler_.br(TMP_REG_0);
        }
      }
    }
    else
    {
      turbo_assembler_.Emit(inst);
    }

    this->cursor += sizeof(uint32_t);
  }

  //   DEBUGL( LOG_INFO, "calling correct_final_relo_size()\n" );
  correct_final_relo_size();

  // TODO: if last instr is unlink branch, ignore it
  if (branch)
  {
    CodeGen codegen(&turbo_assembler_);
    codegen.LiteralLdrBranch(origin_cursor());
  }

  turbo_assembler_.relocDataLabels();

  relocated = AssemblerCodeBuilder::FinalizeFromTurboAssembler(&turbo_assembler_);
  return 0;
}

void GenRelocateCode(void *buffer, CodeMemBlock *origin, CodeMemBlock *relocated, bool branch)
{
  relo_ctx_t ctx(origin);
  ctx.relocate(branch);
  *relocated = ctx.relocated;
}

void GenRelocateCodeAndBranch(void *buffer, CodeMemBlock *origin, CodeMemBlock *relocated)
{
  GenRelocateCode(buffer, origin, relocated, true);
}

struct InterceptRouting
{
  Interceptor::Entry *entry = 0;
  Trampoline *trampoline = 0;
  Trampoline *near_trampoline = 0;
  int error = 0;

  explicit InterceptRouting(Interceptor::Entry *entry) : entry(entry)
  {
  }

  ~InterceptRouting()
  {
    if (trampoline)
    {
      // TODO: free code block
      delete trampoline;
    }
    if (near_trampoline)
    {
      // TODO: free code block
      delete near_trampoline;
    }
  }

  virtual void Prepare()
  {
  }
  virtual void DispatchRouting()
  {
  }
  void Commit()
  {
  }

  virtual addr_t TrampolineTarget()
  {
    printf("THIS CODE SHOULD BE UNREACHABLE\n");
    return -1;
  }

  addr_t trampoline_addr()
  {
    if (near_trampoline)
    {
      // return near_trampoline->addr();
      return near_trampoline->buffer.start_;
    }

    // return trampoline->addr();
    return trampoline->buffer.start_;
  }

  size_t trampoline_size()
  {
    if (near_trampoline)
      // return near_trampoline->size();
      return near_trampoline->buffer.size;
    // return trampoline->size();
    return trampoline->buffer.size;
  }

  virtual void Active()
  {
    auto ret = DobbyCodePatch((void *)entry->addr, (uint8_t *)trampoline_addr(), trampoline_size());
    error |= (ret != 0);
  }

  bool GenerateTrampoline()
  {
    addr_t from = entry->addr;
    addr_t to = TrampolineTarget();

    if (!near_trampoline)
    {
      trampoline = GenerateNormalTrampolineBuffer(from, to);
    }
    return true;
  }

  void GenerateRelocatedCode()
  {
    if (trampoline_addr() == 0)
    {
      error = 1;
    }

    auto code_addr = entry->addr;
    auto preferred_size = trampoline_size();
    auto origin = CodeMemBlock(code_addr, preferred_size);
    auto relocated = CodeMemBlock(0, 0);

    GenRelocateCodeAndBranch((void *)code_addr, &origin, &relocated);
    if (relocated.size == 0)
    {
      error = 1;
      return;
    }

    entry->patched = origin;
    entry->relocated = relocated;
  }

  void BackupOriginCode()
  {
    entry->backup_orig_code();
  }
};

struct InlineHookRouting : InterceptRouting
{
  addr_t fake_func;

  InlineHookRouting(Interceptor::Entry *entry, addr_t fake_func) : InterceptRouting(entry), fake_func(fake_func)
  {
  }

  ~InlineHookRouting() = default;

  addr_t TrampolineTarget() override
  {
    return fake_func;
  }

  void BuildRouting()
  {
    GenerateTrampoline();
    GenerateRelocatedCode();
    BackupOriginCode();
  }
};

PUBLIC int DoTheHook(void *address, void *fake_func, void **out_origin_func, uintptr_t VMProtectAddress)
{
  if (!address)
  {
    printf("address is 0x0\n");
    return -1;
  }

  vm_protect_address = VMProtectAddress;

  auto entry = new Interceptor::Entry((addr_t)address);
  entry->fake_func_addr = (addr_t)fake_func;

  auto routing = new InlineHookRouting(entry, (addr_t)fake_func);

  routing->BuildRouting();
  routing->Active();
  entry->routing = routing;

  if (routing->error)
  {
    printf("build routing error.\n");
    return -1;
  }

  if (out_origin_func)
  {
    *out_origin_func = (void *)entry->relocated.start_;
  }

  return 0;
}
