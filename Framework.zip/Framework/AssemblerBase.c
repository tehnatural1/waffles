
#include "AssemblerBase.h"

void
    AssemblerBase_init
    (
        AssemblerBase *assembler,
        uintptr_t fixed_addr
    )
{
    assembler->fixed_addr = fixed_addr;
    assembler->data_labels = NULL;
    assembler->data_labels_size = 0;
    assembler->data_labels_capacity = 0;
}

size_t
    AssemblerBase_pc_offset
    (
        AssemblerBase *assembler
    )
{
    return assembler->code_buffer_.buffer_size;
}

void
    AssemblerBase_set_fixed_addr
    (
        AssemblerBase *assembler,
        uintptr_t in_fixed_addr
    )
{
    assembler->fixed_addr = in_fixed_addr;
}

CodeMemBuffer*
    AssemblerBase_code_buffer
    (
        AssemblerBase *assembler
    )
{
    return &assembler->code_buffer_;
}

RelocDataLabel*
    AssemblerBase_createDataLabel
    (
        AssemblerBase *assembler,
        uint64_t data
    )
{
    RelocDataLabel *data_label = (RelocDataLabel *)malloc(sizeof(RelocDataLabel));
    if (data_label == NULL)
        return NULL;

    data_label->data_ = data;
    data_label->data_size_ = 0;

    if (assembler->data_labels_size >= assembler->data_labels_capacity) {
        size_t new_capacity = assembler->data_labels_capacity == 0 ? 1 : assembler->data_labels_capacity * 2;
        RelocDataLabel **new_data_labels = (RelocDataLabel **)realloc(assembler->data_labels, new_capacity * sizeof(RelocDataLabel *));
        if (new_data_labels == NULL) {
            free(data_label);
            return NULL;
        }
        assembler->data_labels = new_data_labels;
        assembler->data_labels_capacity = new_capacity;
    }

    assembler->data_labels[assembler->data_labels_size++] = data_label;

    return data_label;
}

void
    AssemblerBase_bindLabel
    (
        AssemblerBase *assembler,
        void *label
    )
{
    // Implementation depends on PseudoLabel and its associated functions, not provided in the original code
}

void
    AssemblerBase_relocDataLabels
    (
        AssemblerBase *assembler
    )
{
    for( size_t i = 0; i < assembler->data_labels_size; i++ )
    {
        RelocDataLabel *data_label = assembler->data_labels[i];
        // Assuming bindLabel and emit are implemented correctly
        AssemblerBase_bindLabel(assembler, data_label);
        CodeMemBuffer_emit( &assembler->code_buffer_, data_label->data_, data_label->data_size_ );
    }
}