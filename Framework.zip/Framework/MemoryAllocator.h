#ifndef __MEMORY_ALLOCATOR_H__
#define __MEMORY_ALLOCATOR_H__

#include <stdio.h>
#include <stdint.h>
#include <mach/vm_page_size.h>
#include "simple_linear_allocator.h"

#if defined(__APPLE__)
const int kMmapFd = VM_MAKE_TAG(255);
#else
const int kMmapFd = -1;
#endif

const int kMmapFdOffset = 0;

typedef struct MemoryAllocator {
    simple_linear_allocator_t *code_page_allocators;
    simple_linear_allocator_t *data_page_allocators;
    size_t code_page_allocators_count;
    size_t data_page_allocators_count;
} MemoryAllocator;

MemoryAllocator *MemoryAllocator_Shared(void);
void *MemoryAllocator_allocDataBlock(MemoryAllocator *allocator, size_t in_size);
void *MemoryAllocator_allocExecBlock(MemoryAllocator *allocator, size_t size);

#endif // __MEMORY_ALLOCATOR_H__