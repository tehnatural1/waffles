#include "MemoryAllocator.h"
#include "enums.h"
#include <sys/mman.h>
#include <unistd.h>

static
int
    GetProtectionFromMemoryPermission
    (
        MemoryPermission access
    )
{
    int prot = 0;
    if (access & kRead)
        prot |= PROT_READ;
    if (access & kWrite)
        prot |= PROT_WRITE;
    if (access & kExecute)
        prot |= PROT_EXEC;
    return prot;
}

static
int
    OSMemory_PageSize
    (
        void
    )
{
    return (int)sysconf(_SC_PAGESIZE);
}

static
int
    OSMemory_SetPermission
    (
        void *address,
        size_t size,
        MemoryPermission access
    )
{
    int prot = GetProtectionFromMemoryPermission(access);
    int ret = mprotect(address, size, prot);
    if (ret) {
        perror("OSMemory_SetPermission");
    }
    return ret == 0;
}

static
void*
    OSMemory_Allocate
    (
        size_t size,
        MemoryPermission access,
        void *fixed_address
    )
{
    int prot = GetProtectionFromMemoryPermission(access);
    int flags = MAP_PRIVATE | MAP_ANONYMOUS;
    if (fixed_address != NULL) {
        flags |= MAP_FIXED;
    }
    void *result = mmap(fixed_address, size, prot, flags, kMmapFd, kMmapFdOffset);
    if (result == MAP_FAILED)
        return NULL;
    return result;
}




MemoryAllocator*
    MemoryAllocator_Shared
    (
        void
    )
{
    static MemoryAllocator gMemoryAllocator;
    return &gMemoryAllocator;
}

void*
    MemoryAllocator_allocDataBlock
    (
        MemoryAllocator *allocator,
        size_t in_size
    )
{
    if (in_size > OSMemory_PageSize()) {
        // ERROR_LOG("alloc size too large: %d", in_size);
        return NULL;
    }

    uint8_t *result = NULL;
    for (size_t i = 0; i < allocator->data_page_allocators_count; ++i) {
        result = simple_linear_allocator_t_alloc(&allocator->data_page_allocators[i], in_size, 0);
        if (result)
            break;
    }

    if (!result) {
        void *page = OSMemory_Allocate(OSMemory_PageSize(), kNoAccess, NULL);
        OSMemory_SetPermission(page, OSMemory_PageSize(), kWrite);
        simple_linear_allocator_t_init(&allocator->data_page_allocators[allocator->data_page_allocators_count], (uint8_t *)page, OSMemory_PageSize(), 0);
        ++allocator->data_page_allocators_count;
        result = simple_linear_allocator_t_alloc(&allocator->data_page_allocators[allocator->data_page_allocators_count - 1], in_size, 0);
    }
    return result;
}

void*
    MemoryAllocator_allocExecBlock
    (
        MemoryAllocator *allocator,
        size_t size
    )
{
    if (size > OSMemory_PageSize()) {
        // ERROR_LOG("alloc size too large: %d", size);
        return NULL;
    }

    uint8_t *result = NULL;
    for (size_t i = 0; i < allocator->code_page_allocators_count; ++i) {
        result = simple_linear_allocator_t_alloc(&allocator->code_page_allocators[i], size, 0);
        if (result)
            break;
    }

    if (!result) {
        void *page = OSMemory_Allocate(OSMemory_PageSize(), kNoAccess, NULL);
        OSMemory_SetPermission(page, OSMemory_PageSize(), kRead | kExecute);
        simple_linear_allocator_t_init(&allocator->code_page_allocators[allocator->code_page_allocators_count], (uint8_t *)page, OSMemory_PageSize(), 0);
        ++allocator->code_page_allocators_count;
        result = simple_linear_allocator_t_alloc(&allocator->code_page_allocators[allocator->code_page_allocators_count - 1], size, 0);
    }
    return result;
}