#include "simple_linear_allocator.h"


void
    simple_linear_allocator_t_init
    (
        simple_linear_allocator_t *allocator,
        uint8_t *in_buffer,
        uint32_t in_capacity,
        uint32_t in_alignment
    )
{
    allocator->buffer = in_buffer;
    allocator->capacity = in_capacity;
    allocator->builtin_alignment = (in_alignment == 0) ? 1 : in_alignment;
    allocator->size = 0;
}

uint8_t*
    simple_linear_allocator_t_alloc
    (
        simple_linear_allocator_t *allocator,
        uint32_t in_size,
        uint32_t in_alignment
    )
{
    uint32_t alignment = in_alignment
                        ? in_alignment
                        : allocator->builtin_alignment;
    uint32_t gap_size = ALIGN_CEIL((uintptr_t)(allocator->buffer + allocator->size), alignment) - (uintptr_t)(allocator->buffer + allocator->size);
    allocator->size += gap_size;

    if (allocator->size + in_size > allocator->capacity)
    {
        return NULL;
    }

    uint8_t *data = allocator->buffer + allocator->size;
    allocator->size += in_size;
    return data;
}

void
    simple_linear_allocator_t_free
    (
        simple_linear_allocator_t *allocator,
        uint8_t *buf
    )
{
    // do nothing
}

uint8_t*
    simple_linear_allocator_t_cursor
    (
        simple_linear_allocator_t *allocator
    )
{
    return allocator->buffer + allocator->size;
}
