#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <ptrauth.h>
#include <dlfcn.h>
#include <time.h>
#include <errno.h>

#include <mach-o/dyld.h>
#include <mach-o/fat.h>
#include <mach-o/nlist.h>
#include <mach-o/dyld_images.h>
#include <mach/vm_map.h>
#include <mach/mach.h>

#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <inttypes.h>

#include <CoreFoundation/CoreFoundation.h>
#include <AudioToolbox/AudioUnit.h>
#include <AudioToolbox/AUComponent.h>

#include "utility/utility.h"
#include "utility/error.h"
#include "utility/debug.h"
#include "dyld_cache_format.h"


typedef int32_t
(*AudioUnitProcess_t)
    (
        AudioUnit                       inUnit,
        AudioUnitRenderActionFlags*     __nullable ioActionFlags,
        const AudioTimeStamp*           inTimeStamp,
        UInt32                          inNumberFrames,
        AudioBufferList*                ioData
    );


#if defined(__LP64__)
    typedef struct mach_header_64       mach_header_t;
    typedef struct segment_command_64   segment_command_t;
    typedef struct section_64           section_t;
    typedef struct nlist_64             nlist_t;

    #define LC_SEGMENT_ARCH_DEPENDENT LC_SEGMENT_64
#else
    typedef struct mach_header          mach_header_t;
    typedef struct segment_command      segment_command_t;
    typedef struct section              section_t;
    typedef struct nlist                nlist_t;

    #define LC_SEGMENT_ARCH_DEPENDENT LC_SEGMENT
#endif

#define SYMBOLS_FILE_EXTENSION ".symbols"

//------------------------------------------------------------------------------
//  DYNAMICALLY LINKED EXTERNAL METHODS
//------------------------------------------------------------------------------

#ifdef __cplusplus
    extern "C" {
#endif

        extern
        const char*
            dyld_shared_cache_file_path
            (

            );

        extern
        int
            __shared_region_check_np
            (
                uint64_t*               StartAddress
            );

        extern
        kern_return_t
            mach_vm_write
            (
                vm_map_t                TargetTask,
                mach_vm_address_t       Address,
                vm_offset_t             Data,
                mach_msg_type_number_t  DataCount
            );

        extern
        kern_return_t
            mach_vm_allocate
            (
                vm_map_t                Target,
                mach_vm_address_t*      Address,
                mach_vm_size_t          Size,
                int                     Flags
            );

        extern
        kern_return_t
            mach_vm_protect
            (
                vm_map_t                TargetTask,
                mach_vm_address_t       Address,
                mach_vm_size_t          Size,
                boolean_t               SetMaximum,
                vm_prot_t               NewProtection
            );

        extern
        kern_return_t
            mach_vm_deallocate
            (
                vm_map_t                Target,
                mach_vm_address_t       Address,
                mach_vm_size_t          Size
            );

#ifdef __cplusplus
    }
#endif


//------------------------------------------------------------------------------
//  DATA STRUCTURES
//------------------------------------------------------------------------------

typedef uintptr_t                                   addr_t;
typedef struct dyld_cache_header                    dyld_cache_header_t;
typedef struct dyld_cache_mapping_info              dyld_cache_mapping_info_t;
typedef struct dyld_all_image_infos                 dyld_all_image_infos_t;
typedef struct dyld_cache_local_symbols_info        dyld_cache_local_symbols_info_t;
typedef struct dyld_cache_local_symbols_entry_64    dyld_cache_local_symbols_entry_64_t;
typedef struct dyld_cache_local_symbols_entry       dyld_cache_local_symbols_entry_t;
typedef struct load_command                         load_command_t;
typedef struct symtab_command                       symtab_command_t;
typedef struct dysymtab_command                     dysymtab_command_t;
typedef struct dyld_info_command                    dyld_info_command_t;
typedef struct linkedit_data_command                linkedit_data_command_t;

typedef struct
shared_cache_ctx
    {
        // Dyld Caches
        dyld_cache_header_t*                    RuntimeSharedCache;
        dyld_cache_header_t*                    MmapSharedCache;

        // ASLR
        uintptr_t                               RuntimeSlide;
        bool                                    LatestSharedCacheFormat;

        // Symbols
        dyld_cache_local_symbols_info_t*        LocalSymbolsInfo;
        dyld_cache_local_symbols_entry_t*       LocalSymbolsEntries;
        dyld_cache_local_symbols_entry_64_t*    LocalSymbolsEntries64;

        // Tables
        nlist_t*                                SymbolTable;
        char*                                   StringTable;
    } shared_cache_ctx_t;

typedef struct
macho_ctx_t
    {
        bool                                    IsRuntimeMode;

        // Headers
        mach_header_t*                          Header;
        mach_header_t*                          CacheHeader;

        // VM Region
        uintptr_t                               LoadVmAddr;
        size_t                                  VmSize;
        uintptr_t                               VmRegionStart;
        uintptr_t                               VmRegionEnd;

        // ASLR
        uintptr_t                               Slide;
        uintptr_t                               LinkedItBase;

        // Segments
        segment_command_t*                      Segments[ 64 ];
        int                                     SegmentsCount;
        segment_command_t*                      TextSegment;
        segment_command_t*                      DataSegment;
        segment_command_t*                      TextExecSegment;
        segment_command_t*                      DataConstSegment;
        segment_command_t*                      LinkedItSegment;
        // segment_command_t*                      FIRSTSEGMENT;
        // uint8_t                                 FIRSTFOUND;

        // Commands
        symtab_command_t*                       SymbolTableCommand;
        dysymtab_command_t*                     DySymbolTableCommand;
        dyld_info_command_t*                    DyldInfoCommand;
        linkedit_data_command_t*                ExportsTrieCommand;
        linkedit_data_command_t*                ChainedFixupsCommand;

        // Tables
        nlist_t*                                SymbolTable;
        char*                                   StringTable;
        uint32_t*                               IndirectSymbolTable;
    } macho_ctx_t;


/*******************************************************************************
 * DEFINITIONS
 ******************************************************************************/


//------------------------------------------------------------------------------
//  DEFINITIONS
//------------------------------------------------------------------------------

#define ARRAY_LENGTH( ARRAY ) ( sizeof( ARRAY ) / sizeof( ARRAY[ 0 ] ) )


typedef enum
{
  RESOLVE_SYMBOL_TYPE_SYMBOL_TABLE  = 1 << 0,
  RESOLVE_SYMBOL_TYPE_EXPORTED      = 1 << 1,
  RESOLVE_SYMBOL_TYPE_ALL           = RESOLVE_SYMBOL_TYPE_SYMBOL_TABLE | RESOLVE_SYMBOL_TYPE_EXPORTED
} resolve_symbol_type_t;


static
ErrorStatus
    shared_cache_get_load_addr
    (
        OUT         dyld_cache_header_t**       LoadAddress
    )
{
    ErrorStatus                 retVal              = ERROR_FAILURE;
    addr_t                      shared_cache_base   = 0;
    task_dyld_info_data_t       task_dyld_info      = { 0 };
    mach_msg_type_number_t      count               = TASK_DYLD_INFO_COUNT;
    kern_return_t               task_info_status    = KERN_FAILURE;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    // Sanity check
    VERIFY_PARAM( LoadAddress );

    // Attempt to get shared cache base. Failure is OK.
    if( 0 != __shared_region_check_np( (uint64_t*) &shared_cache_base ) )
    {
        DEBUGL( LOG_LEVEL_WARNING, "__shared_region_check_np() Failed. Attempting task resolve.\n" );
    }

    // If base was collected nothing to do
    if( shared_cache_base )
    {
        *LoadAddress    = (dyld_cache_header_t*) shared_cache_base;
        retVal          = ERROR_SUCCESS;
    }
    else {
        // task info
        if( KERN_SUCCESS != ( task_info_status = task_info( mach_task_self(),
                                                            TASK_DYLD_INFO,
                                                            (task_info_t) &task_dyld_info,
                                                            &count ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR,
                    "task_info() Failed. retVal: %d\n",
                    task_info_status );
            retVal = ERROR_TASK_INFO;
        }
        else {
            // get dyld load address
            *LoadAddress    = (dyld_cache_header_t*)( (dyld_all_image_infos_t*)task_dyld_info.all_image_info_addr )->sharedCacheBaseAddress;
            retVal          = ERROR_SUCCESS;
        } // task_info()
    } // shared_cache_base

    // return shared_cache;
    DEBUGL( LOG_LEVEL_DEBUG,
            "retVal: %08" PRIX8 "\n",
            retVal );
    return retVal;
}

static
ErrorStatus
    shared_cache_ctx_init
    (
        IN  OUT     shared_cache_ctx_t*         Context
    )
{
    ErrorStatus                     retVal                  = ERROR_FAILURE;
    dyld_cache_header_t*            runtime_shared_cache    = NULL;
    dyld_cache_mapping_info_t*      mappings                = NULL;
    uintptr_t                       slide                   = 0;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    // Sanity check
    VERIFY_PARAM( Context );

    // Always scrub the shared cache context
    memset( Context,
            0,
            sizeof( shared_cache_ctx_t ) );

    if( ERROR_SUCCESS != ( retVal = shared_cache_get_load_addr( &runtime_shared_cache ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "shared_cache_get_load_addr() Failed\n" );
    }
    else {
        // Update shared cache pointer
        Context->RuntimeSharedCache = runtime_shared_cache;

        // Shared cache slide
        mappings    = (dyld_cache_mapping_info_t*)( (char*) runtime_shared_cache + runtime_shared_cache->mappingOffset );
        slide       = (uintptr_t) runtime_shared_cache - (uintptr_t) ( mappings[ 0 ].address );

        // Update known slide
        Context->RuntimeSlide = slide;
    } // shared_cache_get_load_addr()

    DEBUGL( LOG_LEVEL_DEBUG,
            "retVal: %08" PRIX8 "\n",
            retVal );
    return retVal;
}

static
ErrorStatus
    map_options
    (
        IN          size_t                      MapSize,
        IN          off_t                       MapOffset,
        IN          const char*                 MapFile,
        OUT         uint8_t**                   MmapBuffer
    )
{
    ErrorStatus     retVal              = ERROR_FAILURE;
    int             file_descriptor     = -1;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    // Open file
    if( 0 > ( file_descriptor = open( MapFile,
                                      O_RDONLY,
                                      0 ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "open() Failed\n" );
        retVal = ERROR_FILE_IO;
    }
    else {
        // Map to the buffer
        if( MAP_FAILED == ( *MmapBuffer = (uint8_t *) mmap( 0,
                                                            MapSize,
                                                            PROT_READ | PROT_WRITE,
                                                            MAP_PRIVATE,
                                                            file_descriptor,
                                                            MapOffset ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "mmap() Failed\n" );
            *MmapBuffer = NULL;
            retVal = ERROR_MEMORY_MAPPING;
        }
        else {
            // Success
            retVal = ERROR_SUCCESS;
        } // mmap()

        close( file_descriptor );
    } // open()

    DEBUGL( LOG_LEVEL_DEBUG,
            "retVal: %08" PRIX8 "\n",
            retVal );
    return retVal;
}

static
ErrorStatus
    map_cache
    (
        IN          const char*                 MapFile,
        IN  OUT     uint8_t**                   MmapBuffer
    )
{
    ErrorStatus     retVal          = ERROR_FAILURE;
    struct stat     file_stat       = { 0 };
    int             stat_code       = 0;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    // Stat file to map
    if( 0 != ( stat_code = stat( MapFile, &file_stat ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "stat() Failed\n" );
        retVal = ERROR_FILE_IO;
    }
    else {
        // Map the file
        retVal = map_options( file_stat.st_size,
                              0,
                              MapFile,
                              MmapBuffer );
    } // stat()

    DEBUGL( LOG_LEVEL_DEBUG,
            "retVal: %08" PRIX8 "\n",
            retVal );
    return retVal;
}

static
ErrorStatus
    shared_cache_load_symbols
    (
        IN          shared_cache_ctx_t*         Context
    )
{
    ErrorStatus     retVal                                  = ERROR_SUCCESS;
    uint64_t        localSymbolsOffset                      = 0;
    bool            latest_shared_cache_format              = true;
    char*           shared_cache_path                       = NULL;
    char            shared_cache_symbols_path[ PATH_MAX ]   = { 0 };
    uint8_t*        mmBuffer                                = NULL;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    // Get shared cache file path
    if( NULL == ( shared_cache_path = (char*)dyld_shared_cache_file_path() ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "dyld_shared_cache_file_path() Failed\n" );
        // Fail
        retVal = ERROR_CACHED_LOCATION;
    }
    else {

        (void) strncat( shared_cache_symbols_path,
                        shared_cache_path,
                        PATH_MAX );
        (void) strncat( shared_cache_symbols_path,
                        SYMBOLS_FILE_EXTENSION,
                        sizeof( SYMBOLS_FILE_EXTENSION ) );

        // Attempt to map .symbols
        if( ERROR_SUCCESS != ( retVal = map_cache( shared_cache_symbols_path, &mmBuffer ) ) )
        {
            DEBUGL( LOG_LEVEL_NOTICE,
                    "Failed to map '%s'. Assuming iOS < 15.0.",
                    shared_cache_symbols_path );

            // Ensure shared cache can be mapped
            if( 0 == Context->RuntimeSharedCache->localSymbolsSize )
            {
                DEBUGL( LOG_LEVEL_CRITICAL, "Context->RuntimeSharedCache->localSymbolsSize Invalid.\n" );
                retVal = ERROR_SYMBOL_SIZE;
            }
            else {
                // Attempt to map the shared cache
                if( ERROR_SUCCESS != ( retVal = map_options( Context->RuntimeSharedCache->localSymbolsSize,
                                                             Context->RuntimeSharedCache->localSymbolsOffset,
                                                             shared_cache_path,
                                                             &mmBuffer ) ) )
                {
                    DEBUGL( LOG_LEVEL_ERROR, "map_options() Failed.\n" );
                }
                else {
                    Context->MmapSharedCache = (dyld_cache_header_t*)
                        ( (addr_t) mmBuffer - Context->RuntimeSharedCache->localSymbolsOffset );

                    localSymbolsOffset = Context->RuntimeSharedCache->localSymbolsOffset;
                    latest_shared_cache_format = false;
                } // map_options()
            } // Context->RuntimeSharedCache->localSymbolsSize
        }
        else
        {
            DEBUGL( LOG_LEVEL_NOTICE, "map_cache() Succeeded. Assuming iOS >= 15.0\n" );
            // iOS >= 15.0
            Context->MmapSharedCache    = (dyld_cache_header_t*)mmBuffer;
            localSymbolsOffset          = Context->MmapSharedCache->localSymbolsOffset;
        } // map_cache()

        if( ERROR_SUCCESS == retVal )
        {
            Context->LatestSharedCacheFormat = latest_shared_cache_format;
            Context->LocalSymbolsInfo = (dyld_cache_local_symbols_info_t*)
                ( (char*)Context->MmapSharedCache + localSymbolsOffset );

            if( Context->LatestSharedCacheFormat )
            {
                Context->LocalSymbolsEntries64 = (dyld_cache_local_symbols_entry_64_t*)
                    ( (char*)Context->LocalSymbolsInfo + Context->LocalSymbolsInfo->entriesOffset );
            }
            else {
                Context->LocalSymbolsEntries = (dyld_cache_local_symbols_entry_t*)
                    ( (char*)Context->LocalSymbolsInfo + Context->LocalSymbolsInfo->entriesOffset );
            }

            Context->SymbolTable = (nlist_t*)( (char*)Context->LocalSymbolsInfo + Context->LocalSymbolsInfo->nlistOffset );
            Context->StringTable = ( (char*)Context->LocalSymbolsInfo ) + Context->LocalSymbolsInfo->stringsOffset;
        } // ERROR_SUCCESS == retVal
    } // dyld_shared_cache_file_path()

    DEBUGL( LOG_LEVEL_DEBUG,
            "retVal: %08" PRIX8 "\n",
            retVal );
    return retVal;
}

static
bool
    shared_cache_contains
    (
        IN          shared_cache_ctx_t*         Context,
        IN          addr_t                      Address
    )
{
    dyld_cache_header_t*    runtime_shared_cache    = NULL;
    addr_t                  region_start            = 0;
    addr_t                  region_end              = 0;
    bool                    retVal                  = false;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    if( Context )
    {
        runtime_shared_cache = Context->RuntimeSharedCache;
    }
    else
    {
        (void)shared_cache_get_load_addr( &runtime_shared_cache );
    }

    region_start    = runtime_shared_cache->sharedRegionStart + Context->RuntimeSlide;
    region_end      = region_start + runtime_shared_cache->sharedRegionSize;

    retVal          = ( ( Address >= region_start ) && ( Address < region_end ) );

    DEBUGL( LOG_LEVEL_DEBUG,
            "Contains? %s\n",
            ( true == retVal ? "YES" : "NO" ) );
    return retVal;
}

static
ErrorStatus
    shared_cache_get_symbol_table
    (
        IN          shared_cache_ctx_t*         Context,
        IN          mach_header_t*              ImageHeader,
        OUT         nlist_t**                   SymbolTable,
        OUT         uint32_t*                   SymbolTableCount,
        OUT         char**                      StringTable
    )
{
    ErrorStatus     retVal              = ERROR_NOT_FOUND;
    uint64_t        offset_in_cache     = 0;
    nlist_t*        localNlists         = NULL;
    uint32_t        localNlistCount     = 0;
    char*           localStrings        = NULL;
    uint32_t        entry_itr           = 0;
    uint32_t        localNlistStart     = 0;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    VERIFY_PARAM( Context );
    VERIFY_PARAM( ImageHeader );
    VERIFY_PARAM( SymbolTable );
    VERIFY_PARAM( SymbolTableCount );
    VERIFY_PARAM( StringTable );

    offset_in_cache = (uint64_t)ImageHeader - (uint64_t)Context->RuntimeSharedCache;

    // Iterate over each entry
    for( entry_itr = 0;
        entry_itr < Context->LocalSymbolsInfo->entriesCount;
        ++entry_itr )
    {
        // Determine Shared Cache Format
        if( Context->LatestSharedCacheFormat )
        {
            if( Context->LocalSymbolsEntries64[ entry_itr ].dylibOffset == offset_in_cache )
            {
                localNlistStart = Context->LocalSymbolsEntries64[ entry_itr ].nlistStartIndex;
                localNlistCount = Context->LocalSymbolsEntries64[ entry_itr ].nlistCount;
                localNlists     = &Context->SymbolTable[ localNlistStart ];
                // Match found
                retVal          = ERROR_SUCCESS;
                break;
            }
        }
        else {
            if( Context->LocalSymbolsEntries[ entry_itr ].dylibOffset == offset_in_cache )
            {
                localNlistStart = Context->LocalSymbolsEntries[ entry_itr ].nlistStartIndex;
                localNlistCount = Context->LocalSymbolsEntries[ entry_itr ].nlistCount;
                localNlists     = &Context->SymbolTable[ localNlistStart ];
                // Match found
                retVal          = ERROR_SUCCESS;
                break;
            }
        } // Shared Cache Format
    } // for()

    *SymbolTable        = localNlists;
    *SymbolTableCount   = (uint32_t) localNlistCount;
    *StringTable        = (char *) Context->StringTable;

    DEBUGL( LOG_LEVEL_DEBUG,
            "retVal: %08" PRIX8 "\n",
            retVal );
    return retVal;
}

static
uintptr_t
    macho_iterate_symbol_table
    (
        IN          char*               SymbolNamePattern,
        IN          nlist_t*            SymbolTable,
        IN          uint32_t            SymbolTableCount,
        IN          char*               StringTable
    )
{
    char*       symbol_name     = NULL;
    uint32_t    strtab_offset   = 0;
    uint32_t    sym_tab_itr     = 0;
    uintptr_t   n_value         = 0;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    VERIFY_PARAM( SymbolNamePattern );
    VERIFY_PARAM( SymbolTable );
    VERIFY_PARAM( StringTable );

    // Iterate through symbol table
    for( sym_tab_itr = 0;
        ( sym_tab_itr < SymbolTableCount ) && ( 0 == n_value );
        sym_tab_itr++ )
    {
        // Only entries with a stab offset are interesting
        if( SymbolTable[ sym_tab_itr ].n_value )
        {
            strtab_offset   = SymbolTable[ sym_tab_itr ].n_un.n_strx;
            symbol_name     = StringTable + strtab_offset;

            // Symbol was exact match
            if( 0 == strcmp( SymbolNamePattern, symbol_name ) )
            {
                n_value = SymbolTable[ sym_tab_itr ].n_value;
            }
            else if( ( '_' == symbol_name[ 0 ] ) &&
                     ( 0   == strcmp( SymbolNamePattern, &symbol_name[ 1 ] ) ) )
            {
                n_value = SymbolTable[ sym_tab_itr ].n_value;
            } // strcmp()
        } // SymbolTable[ sym_tab_itr ].n_value
    } // for()

    DEBUG( "n_value: %08" PRIuPTR "\n", n_value );
    return n_value;
}

static
void
    update_macho_context
    (
        IN          load_command_t*         LoadCommand,
        IN  OUT     macho_ctx_t*            Context
    )
{
    segment_command_t* curr_seg_cmd = NULL;

    switch( LoadCommand->cmd )
    {
        case LC_SEGMENT_ARCH_DEPENDENT:
        {
            curr_seg_cmd = (segment_command_t*) LoadCommand;
            Context->Segments[ Context->SegmentsCount++ ] = curr_seg_cmd;

            if( !strcmp( curr_seg_cmd->segname, "__LINKEDIT" ) )
            {
                Context->LinkedItSegment = curr_seg_cmd;
            }
            else if( !strcmp( curr_seg_cmd->segname, "__DATA" ) )
            {
                Context->DataSegment = curr_seg_cmd;
            }
            else if( !strcmp( curr_seg_cmd->segname, "__DATA_CONST" ) )
            {
                Context->DataConstSegment = curr_seg_cmd;
            }
            else if( !strcmp( curr_seg_cmd->segname, "__TEXT" ) )
            {
                Context->TextSegment = curr_seg_cmd;
            }
            else if( !strcmp( curr_seg_cmd->segname, "__TEXT_EXEC" ) )
            {
                Context->TextExecSegment = curr_seg_cmd;
            }
            break;
        }

        case LC_SYMTAB:
        {
            Context->SymbolTableCommand = (symtab_command_t*)LoadCommand;
            break;
        }

        case LC_DYSYMTAB:
        {
            Context->DySymbolTableCommand = (dysymtab_command_t*)LoadCommand;
            break;
        }

        case LC_DYLD_INFO:
        case LC_DYLD_INFO_ONLY:
        {
            Context->DyldInfoCommand = (dyld_info_command_t*)LoadCommand;
            break;
        }

        case LC_DYLD_EXPORTS_TRIE:
        {
            Context->ExportsTrieCommand = (linkedit_data_command_t*)LoadCommand;
            break;
        }

        case LC_DYLD_CHAINED_FIXUPS:
        {
            Context->ChainedFixupsCommand = (linkedit_data_command_t*)LoadCommand;
            break;
        }
    } // switch()
}

static
void
    macho_ctx_init
    (
        IN          mach_header_t*      MachHeader,
        IN          bool                RuntimeMode,
        IN          mach_header_t*      CacheHeader,
        IN  OUT     macho_ctx_t*        Context
    )
{
    load_command_t*     curr_cmd        = NULL;
    segment_command_t*  curr_seg_cmd    = NULL;
    uint32_t            macho_iter      = 0;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    Context->Header         = MachHeader;
    Context->IsRuntimeMode  = RuntimeMode;
    Context->CacheHeader    = CacheHeader;

    curr_cmd = (load_command_t*)( (uintptr_t)MachHeader + sizeof( mach_header_t ) );

    for( macho_iter = 0; macho_iter < MachHeader->ncmds; macho_iter++ )
    {
        // if (curr_cmd->cmd == LC_SEGMENT_64) {
        //     if (!Context->FIRSTSEGMENT && ((struct segment_command_64 *)curr_cmd)->filesize ) {
        //         DEBUG( "UPDATED FIRSTSEGMENT\n" );
        //         Context->FIRSTSEGMENT = (struct segment_command_64 *)curr_cmd;
        //     }
        // }
        update_macho_context( curr_cmd, Context );
        curr_cmd = (load_command_t*)( (uintptr_t)curr_cmd + curr_cmd->cmdsize );
    } // for()

    Context->Slide          = (uintptr_t)MachHeader
                            - (uintptr_t)Context->TextSegment->vmaddr;
    Context->LinkedItBase   = (uintptr_t)Context->Slide
                            + Context->LinkedItSegment->vmaddr
                            - Context->LinkedItSegment->fileoff;

    if( !RuntimeMode )
    {
        Context->LinkedItBase = (uintptr_t)( CacheHeader ? CacheHeader : MachHeader );
    }

    Context->VmRegionStart  = (uintptr_t)-1;
    Context->VmRegionEnd    = 0;

    for( macho_iter = 0; macho_iter < Context->SegmentsCount; macho_iter++ )
    {
        if( !strcmp( Context->Segments[ macho_iter ]->segname, "__PAGEZERO" ) )
        {
            continue;
        }
        if( !strcmp( Context->Segments[ macho_iter ]->segname, "__TEXT" ) )
        {
            Context->LoadVmAddr = Context->Segments[ macho_iter ]->vmaddr;
        }
        if( Context->VmRegionStart > Context->Segments[ macho_iter ]->vmaddr )
        {
            Context->VmRegionStart = Context->Segments[ macho_iter ]->vmaddr;
        }
        if( Context->VmRegionEnd < ( Context->Segments[ macho_iter ]->vmaddr + Context->Segments[ macho_iter ]->vmsize ) )
        {
            Context->VmRegionEnd    = Context->Segments[ macho_iter ]->vmaddr
                                    + Context->Segments[ macho_iter ]->vmsize;
        }
    }

    Context->VmSize = Context->VmRegionEnd - Context->VmRegionStart;

    if( Context->SymbolTableCommand )
    {
        Context->SymbolTable = (nlist_t*)( Context->LinkedItBase + Context->SymbolTableCommand->symoff );
        Context->StringTable = (char*)( Context->LinkedItBase + Context->SymbolTableCommand->stroff );
    }

    if( Context->DySymbolTableCommand )
    {
        Context->IndirectSymbolTable = (uint32_t*)( Context->LinkedItBase + Context->DySymbolTableCommand->indirectsymoff );
    }

    DEBUGL( LOG_LEVEL_INFO,
            "Header: %p: region: %" PRIuPTR " - %" PRIuPTR ", load_vmaddr: %" PRIuPTR ", vmsize: %zu, slide: %" PRIuPTR "\n",
            Context->Header, Context->VmRegionStart, Context->VmRegionEnd,
            Context->LoadVmAddr, Context->VmSize, Context->Slide );
}

static
uintptr_t
    iterate_symbol_table
    (
        IN          macho_ctx_t*        Context,
        IN          const char*         SymbolNamePattern,
        uintptr_t* retCode
    )
{
    char*       symbol_name     = NULL;
    uint32_t    symbol_itr      = 0;
    uint64_t    n_value         = 0;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    for( symbol_itr = 0; symbol_itr < Context->SymbolTableCommand->nsyms && 0 == n_value; symbol_itr++ )
    {
        if( Context->SymbolTable[ symbol_itr ].n_value )
        {
            symbol_name = Context->StringTable + Context->SymbolTable[ symbol_itr ].n_un.n_strx;

            if( 0 == strcmp( SymbolNamePattern, symbol_name ) )
            {
                n_value = Context->SymbolTable[ symbol_itr ].n_value;
                *retCode = ( Context->SymbolTable[ symbol_itr ].n_value );
            }
            else if( ( '_' == symbol_name[ 0 ] ) &&
                     ( 0   == strcmp( SymbolNamePattern, &symbol_name[ 1 ] ) ) )
            {
                n_value = Context->SymbolTable[ symbol_itr ].n_value;
                *retCode = ( Context->SymbolTable[ symbol_itr ].n_value );
            } // strcmp()
        } // Context->symtab[ symbol_itr ].n_value
    } // for()

    DEBUGL( LOG_LEVEL_DEBUG,
            "n_value found? %s\n",
            ( 0 == n_value ? "NO" : "YES" ) )
    return n_value;
}

#define ASSERT(x)

static
uintptr_t
    read_uleb128
    (
        const uint8_t** pp,
        const uint8_t* end
    )
{
    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );
    uint8_t *p = (uint8_t *)*pp;
    uint64_t result = 0;
    int bit = 0;
    do
    {
        // if (p == end)
        //     ASSERT(p == end);

        uint64_t slice = *p & 0x7f;

        if( bit < 64 )
        {
            result |= (slice << bit);
            bit += 7;
        }

        // if (bit > 63)
        //     ASSERT(bit > 63);
        // else {
        //     result |= (slice << bit);
        //     bit += 7;
        // }
    } while( *p++ & 0x80 );

    *pp = p;

    return (uintptr_t)result;
}

// dyld
// bool MachOLoaded::findExportedSymbol
// MachOLoaded::trieWalk
uint8_t *tail_walk(const uint8_t *start, const uint8_t *end, const char *symbol) {
    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );
  uint32_t visitedNodeOffsets[128];
  int visitedNodeOffsetCount = 0;
  visitedNodeOffsets[visitedNodeOffsetCount++] = 0;
  const uint8_t *p = start;
  while (p < end) {
    DEBUG( "iteration\n" );
    uint64_t terminalSize = *p++;
    if (terminalSize > 127) {
      // except for re-export-with-rename, all terminal sizes fit in one byte
      --p;
      terminalSize = read_uleb128(&p, end);
    }
    if ((*symbol == '\0') && (terminalSize != 0)) {
        DEBUG( "early return\n" );
      return (uint8_t *)p;
    }
    const uint8_t *children = p + terminalSize;
    if (children > end) {
      // diag.error("malformed trie node, terminalSize=0x%llX extends past end of trie\n", terminalSize);
      DEBUG( "Malformed trie node\n" );
      return NULL;
    }
    uint8_t childrenRemaining = *children++;
    p = children;
    uint64_t nodeOffset = 0;

    for (; childrenRemaining > 0; --childrenRemaining) {
      const char *ss = symbol;
      bool wrongEdge = false;
      // scan whole edge to get to next edge
      // if edge is longer than target symbol name, don't read past end of symbol name
      char c = *p;
      while (c != '\0') {
        if (!wrongEdge) {
          if (c != *ss)
            wrongEdge = true;
          ++ss;
        }
        ++p;
        c = *p;
      }
      if (wrongEdge) {
        // advance to next child
        ++p; // skip over zero terminator
        // skip over uleb128 until last byte is found
        while ((*p & 0x80) != 0)
          ++p;
        ++p; // skip over last byte of uleb128
        if (p > end) {
          // diag.error("malformed trie node, child node extends past end of trie\n");
          DEBUG( "child extends beyond end of trie\n" );
          return NULL;
        }
      } else {
        // the symbol so far matches this edge (child)
        // so advance to the child's node
        ++p;
        nodeOffset = read_uleb128(&p, end);
        if ((nodeOffset == 0) || (&start[nodeOffset] > end)) {
          // diag.error("malformed trie child, nodeOffset=0x%llX out of range\n", nodeOffset);
          DEBUG( "Again out of range. NULL\n" );
          return NULL;
        }
        symbol = ss;
        break;
      }
    }

    if (nodeOffset != 0) {
      if (nodeOffset > (uint64_t)(end - start)) {
        // diag.error("malformed trie child, nodeOffset=0x%llX out of range\n", nodeOffset);
        DEBUG( "out of range. NULL\n" );
        return NULL;
      }
      for (int i = 0; i < visitedNodeOffsetCount; ++i) {
        if (visitedNodeOffsets[i] == nodeOffset) {
          // diag.error("malformed trie child, cycle to nodeOffset=0x%llX\n", nodeOffset);
          DEBUG( "Another malform. NULL\n" );
          return NULL;
        }
      }
      visitedNodeOffsets[visitedNodeOffsetCount++] = (uint32_t)nodeOffset;
      p = &start[nodeOffset];
    } else
      p = end;
  }

  DEBUG( "Got to end and its NULL\n" );
  return NULL;
}


uintptr_t
    iterate_exported_symbol
    (
        macho_ctx_t* Context,
        const char *symbol_name,
        uint64_t *out_flags
    )
{
    uint32_t trieFileOffset = 0;
    uint32_t trieFileSize = 0;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    if( Context->TextSegment == NULL || Context->LinkedItSegment == NULL )
    {
        return 0;
    }

    if( Context->ExportsTrieCommand == NULL && Context->DyldInfoCommand == NULL )
        return 0;

    trieFileOffset  = ( Context->DyldInfoCommand
                        ? Context->DyldInfoCommand->export_off
                        : Context->ExportsTrieCommand->dataoff );
    trieFileSize    = ( Context->DyldInfoCommand
                        ? Context->DyldInfoCommand->export_size
                        : Context->ExportsTrieCommand->datasize );

    void *exports = (void*)(Context->LinkedItBase + trieFileOffset);

    if( exports == NULL )
        return 0;

    uint8_t *exports_start = (uint8_t *)exports;
    uint8_t *exports_end = exports_start + trieFileSize;
    uint8_t *node = (uint8_t *)tail_walk(exports_start, exports_end, symbol_name);

    if( node == NULL )
        return 0;

    const uint8_t *p = node;
    const uintptr_t flags = read_uleb128(&p, exports_end);

    if( out_flags )
        *out_flags = flags;

    if( flags & EXPORT_SYMBOL_FLAGS_REEXPORT )
    {
        const uint64_t ordinal = read_uleb128(&p, exports_end);
        const char *importedName = (const char *)p;

        if( importedName[0] == '\0' )
        {
            importedName = symbol_name;
            return 0;
        }
        // trick
        // printf("reexported symbol: %s\n", importedName);
        return (uintptr_t)importedName;
    }

    uint64_t trieValue = read_uleb128( &p, exports_end );
    return trieValue;
    #if 0
    if (off == (void *)0) {
        if (symbol_name[0] != '_' && strlen(&symbol_name[1]) >= 1) {
        char _symbol_name[1024] = {0};
        _symbol_name[0] = '_';
        strcpy(&_symbol_name[1], symbol_name);
        off = (void *)walk_exported_trie((const uint8_t *)exports, (const uint8_t *)exports + trieFileSize, _symbol_name);
        }
    }
    #endif
}




uintptr_t
    symbol_resolve_options
    (
        IN  OUT     macho_ctx_t*        Context,
        const char *symbol_name_pattern,
        resolve_symbol_type_t type,
        uintptr_t* retCode
    )
{
    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    if( type & RESOLVE_SYMBOL_TYPE_SYMBOL_TABLE )
    {
        uintptr_t result = iterate_symbol_table( Context, symbol_name_pattern, retCode );
        if (result) {
            result = result + ( Context->IsRuntimeMode ? Context->Slide : 0 );
            return result;
        }
    }

    if( type & RESOLVE_SYMBOL_TYPE_EXPORTED )
    {
        DEBUG( "type & RESOLVE_SYMBOL_TYPE_EXPORTED\n" );
        // binary exported table(uleb128)
        uint64_t flags;
        uintptr_t result = iterate_exported_symbol(Context, symbol_name_pattern, &flags);
        if (result) {
            switch (flags & EXPORT_SYMBOL_FLAGS_KIND_MASK)
            {
                case EXPORT_SYMBOL_FLAGS_KIND_REGULAR:
                {
                    result += (uintptr_t)Context->Header;
                } break;
                case EXPORT_SYMBOL_FLAGS_KIND_THREAD_LOCAL:
                {
                    result += (uintptr_t)Context->Header;
                } break;
                case EXPORT_SYMBOL_FLAGS_KIND_ABSOLUTE:
                {
                    //
                } break;
                default:
                    break;
            }
            return result;
        }
    }
    return 0;
}


#include <sys/sysctl.h>
// #include <string.h>
#include <alloca.h>
#include <mach/thread_state.h>
// #include <mach/mach_vm.h>

// mach_vm_allocate

extern char injected_arm_start __asm("section$start$__INJ_arm64e$__inj_arm64e");
extern char injected_arm_end __asm("section$end$__INJ_arm64e$__inj_arm64e");
#define DYLD_MAGIC_64 ('DYLD'* 0x100000001)
#define ARGUMENT_MAGIC_STR "ARGUMENT"
#define ARGUMENT_MAX_LENGTH 256




kern_return_t
    inject_call_to_thread_arm
    (
        mach_port_t         Task,
        mach_port_t         Thread,
        uint64_t            Function,
        uint64_t            ReturnAddress
    )
{
    arm_thread_state64_t        state       = { 0 };
    mach_msg_type_number_t      size        = ARM_THREAD_STATE64_COUNT;
    kern_return_t               ret         = KERN_SUCCESS;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    if( KERN_SUCCESS != ( ret = thread_suspend( Thread ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "thread_suspend() Failed\n" );
        goto exit;
    } // thread_suspend()

    if( KERN_SUCCESS != ( ret = thread_get_state( Thread,
                                                    ARM_THREAD_STATE64,
                                                    (thread_state_t) &state,
                                                    &size ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "thread_get_state() Failed\n" );
        goto exit;
    } // thread_get_state()

    /* Save PC to FP */
#if __DARWIN_OPAQUE_ARM_THREAD_STATE64
    state.__opaque_fp = (void *)( (uint64_t)state.__opaque_pc & 0xFFFFFFFFFFF );
#else
    state.__fp = (uint64_t)( (uint64_t)state.__pc & 0xFFFFFFFFFFF );
#endif

    /* Update PC */
    if( KERN_SUCCESS != ( ret = thread_convert_thread_state( Thread,
                                                            THREAD_CONVERT_THREAD_STATE_TO_SELF,
                                                            ARM_THREAD_STATE64,
                                                            (thread_state_t)&state,
                                                            size,
                                                            (thread_state_t)&state,
                                                            &size ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "thread_convert_thread_state() Failed. Attempting to continue\n" );
    }

    __darwin_arm_thread_state64_set_pc_fptr( state, ptrauth_sign_unauthenticated( (void *)Function,
                                                                                    ptrauth_key_function_pointer,
                                                                                    0 ) );

    if( KERN_SUCCESS != ( ret = thread_convert_thread_state( Thread,
                                                            THREAD_CONVERT_THREAD_STATE_FROM_SELF,
                                                            ARM_THREAD_STATE64,
                                                            (thread_state_t)&state,
                                                            size,
                                                            (thread_state_t)&state,
                                                            &size ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "thread_convert_thread_state() Failed. Continuing Anyway\n" );
    }

    if( KERN_SUCCESS != ( ret = thread_set_state( Thread,
                                                ARM_THREAD_STATE64,
                                                (thread_state_t) &state,
                                                size ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "thread_set_state() Failed\n" );
        goto exit;
    }

exit:
    thread_resume(Thread);
    return ret;
}



kern_return_t
    inject_stub_to_task
    (
        mach_port_t             Task,
        mach_vm_address_t*      Address,
        mach_vm_address_t*      ReturnAddress,
        const char*             Argument
    )
{
    mach_msg_type_number_t      count           = TASK_DYLD_INFO_COUNT;
    struct task_dyld_info       info            = { 0 } ;
    kern_return_t               ret             = KERN_FAILURE;
    uint8_t*                    code            = NULL;
    size_t                      code_size       = 0;
    uint64_t                    dyld_magic      = DYLD_MAGIC_64;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    if( KERN_SUCCESS != ( ret = task_info( Task,
                                            TASK_DYLD_INFO,
                                            (task_info_t) &info,
                                            &count) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "task_info() Failed\n" );
        return ret;
    }

    code_size   = &injected_arm_end - &injected_arm_start;
    code        = alloca( code_size );

    memcpy( code,
            &injected_arm_start,
            code_size );

    // Set dyld magic to this address
    *(uint64_t*)memmem( code,
                        code_size,
                        &dyld_magic,
                        sizeof( dyld_magic ) ) = info.all_image_info_addr;

    // Set Argument to the new value
    (void) strcpy( memmem( code,
                            code_size,
                            ARGUMENT_MAGIC_STR,
                            sizeof( ARGUMENT_MAGIC_STR ) ), Argument );

    //
    if( KERN_SUCCESS != ( ret = mach_vm_allocate( Task,
                                                    Address,
                                                    code_size,
                                                    VM_FLAGS_ANYWHERE ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "mach_vm_allocate() Failed\n" );
        return ret;
    }

    //
    if( KERN_SUCCESS != ( ret = mach_vm_write( Task,
                                                *Address,
                                                (vm_offset_t) code,
                                                (mach_msg_type_number_t) code_size ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "mach_vm_write() Failed\n" );
        return ret;
    }

    //
    if( KERN_SUCCESS != ( ret = vm_protect( Task,
                                            *Address,
                                            code_size,
                                            FALSE,
                                            VM_PROT_READ | VM_PROT_EXECUTE ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "vm_protect() Failed\n" );
        return ret;
    }

    *ReturnAddress = *Address + code_size - 1;

    DEBUGL( LOG_LEVEL_DEBUG, "Exit with Success\n" );
    return KERN_SUCCESS;
}


kern_return_t
    get_thread_port_for_task
    (
        mach_port_t     Task,
        mach_port_t*    Thread
    )
{
    thread_array_t              thread_list             = NULL;
    mach_msg_type_number_t      thread_list_count       = 0;
    kern_return_t               ret                     = KERN_SUCCESS;
    unsigned int                thread_itr              = 0;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    if( KERN_SUCCESS != ( ret = task_threads( Task,
                                                &thread_list,
                                                &thread_list_count ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "task_threads() Failed\n" );
        return ret;
    }

    /* The first thread returned is the first thread created in the task, which is the main thread.
       This was verified in the kernel sources. */
    *Thread = thread_list[ 0 ];

    for( thread_itr = 1; thread_itr < thread_list_count; thread_itr++ )
    {
        mach_port_destroy( mach_task_self(), thread_list[ thread_itr ] );
    }

    if( KERN_SUCCESS != ( ret = vm_deallocate( mach_task_self(),
                                                (vm_address_t) thread_list,
                                                thread_list_count * sizeof( thread_list[ 0 ] ) ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "vm_deallocate() Failed. Ignoring.\n" );
    }

    DEBUGL( LOG_LEVEL_DEBUG, "exit returning Success\n" );
    return KERN_SUCCESS;
}


kern_return_t
    inject_to_task
    (
        mach_port_t     Task,
        const char*     Argument
    )
{
    mach_port_t             thread          = 0;
    kern_return_t           ret             = KERN_SUCCESS;
    mach_vm_address_t       code_addr       = 0;
    mach_vm_address_t       ret_addr        = 0;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    if( strlen( Argument ) + 1 > ARGUMENT_MAX_LENGTH )
    {
        DEBUGL( LOG_LEVEL_ERROR, "Bad Arguement Length\n" );
        return KERN_INVALID_ARGUMENT;
    }

    if( KERN_SUCCESS != ( ret = get_thread_port_for_task( Task, &thread ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "get_thread_port_for_task() Failed\n" );
        return ret;
    }

    if( KERN_SUCCESS != ( ret = inject_stub_to_task( Task,
                                                        &code_addr,
                                                        &ret_addr,
                                                        Argument ) ) )
    {
        (void)mach_port_destroy( mach_task_self(), thread );
        DEBUGL( LOG_LEVEL_ERROR, "inject_stub_to_task() Failed\n" );
        return ret;
    }

    if( KERN_SUCCESS != ( ret = inject_call_to_thread_arm( Task,
                                                            thread,
                                                            code_addr,
                                                            ret_addr ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "inject_call_to_thread_arm() Failed\n" );
    }

    (void)mach_port_destroy( mach_task_self(), thread );
    DEBUGL( LOG_LEVEL_DEBUG,
            "ret: %08" PRIX8 "\n",
            ret );
    return ret;
}

static
ErrorStatus
    FindPidByProcessName
    (
        IN          const char*         ProcessName,
        OUT         pid_t*              ProcessPid,
        IN          bool                WaitForPid
    )
{
    ErrorStatus retVal = ERROR_FAILURE;
    mach_port_t task = 0;

    // pid_t process_pid = 0;
    size_t buf_size = 0;
    int mib[] = { CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0 };
    struct kinfo_proc* kprocbuf = NULL;
    size_t count = 0;
    size_t process_itr = 0;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    // Reset pid
    *ProcessPid = 0;

    do
    {
        DEBUG( "Looking for PID\n" );

        //
        if( 0 > sysctl( mib,
                        ARRAY_LENGTH( mib ),
                        NULL,
                        &buf_size,
                        NULL,
                        0 ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "sysctl() Failed\n" );
        }
        else
        {
            //
            if( NULL == ( kprocbuf = malloc( buf_size ) ) )
            {
                DEBUGL( LOG_LEVEL_ERROR, "malloc() Failed\n" );
            }
            else
            {
                //
                if( 0 > sysctl( mib,
                                ARRAY_LENGTH( mib ),
                                kprocbuf,
                                &buf_size,
                                NULL,
                                0 ) )
                {
                    DEBUGL( LOG_LEVEL_ERROR, "sysctl() Failed\n" );
                }
                else
                {
                    count = buf_size / sizeof( kprocbuf[ 0 ] );
                    for( process_itr = 0; process_itr < count; process_itr++ )
                    {
                        if( 0 == strcmp( kprocbuf[ process_itr ].kp_proc.p_comm, ProcessName ) )
                        {
                            *ProcessPid = kprocbuf[ process_itr ].kp_proc.p_pid;
                            break;
                        }
                    }
                }

                // Memory management
                free( kprocbuf );
            } // malloc()
        } // sysctl()
    }
    while( ( 0 == *ProcessPid ) && ( true == WaitForPid ) );

    kern_return_t ret = KERN_SUCCESS;
    if( KERN_SUCCESS != ( ret = task_for_pid( mach_task_self(),
                                                *ProcessPid,
                                                &task ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "task_for_pid() Failed\n" );
        return retVal;
    }

    char argument[] = "Injectable DYLIB";

    if( KERN_SUCCESS != ( ret = inject_to_task( task, argument ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "inject_to_task() Failed\n" );
        return retVal;
    }

    DEBUGL( LOG_LEVEL_DEBUG,
            "retVal: %08" PRIX8 "\n",
            retVal );
    return retVal;
}


#include <ptrauth.h>
uintptr_t result = 0;
OSStatus (*AudioUnitProcess_orig) ( AudioUnit                       inUnit,
			                        AudioUnitRenderActionFlags*     __nullable ioActionFlags,
									const AudioTimeStamp*           inTimeStamp,
									UInt32                          inNumberFrames,
									AudioBufferList*                ioData );


OSStatus
    testHook
    (
        AudioUnit                       inUnit,
        AudioUnitRenderActionFlags*     __nullable ioActionFlags,
        const AudioTimeStamp*           inTimeStamp,
        UInt32                          inNumberFrames,
        AudioBufferList*                ioData
    )
{
    DEBUGL( LOG_LEVEL_DEBUG, "get hooked son\n" );
    // sleep(1000000);
    // exit(0);
    OSStatus retVal = AudioUnitProcess_orig( inUnit,
                                                    ioActionFlags,
                                                    inTimeStamp,
                                                    inNumberFrames,
                                                    ioData );
    return retVal;
}






// // #include <mach/mach_vm.h>
// static void unprotect_page(void *page)
// {

//     if (mprotect(page, 0x4000, PROT_READ | PROT_WRITE) == 0)
//     {
//         DEBUGL( LOG_LEVEL_ERROR, "mprotect() Failed\n" );
//         return;
//     }

//     // mprotect_impl( page, 0x4000,  PROT_READ | PROT_WRITE);
//     kern_return_t ret = KERN_FAILURE;

//     // if( KERN_SUCCESS != ( ret = mach_vm_protect( mach_task_self(),
//     //             page, 0x4000, false, VM_PROT_READ | PROT_WRITE ) ) )
//     // {
//     //     DEBUG( "mach_vm_protect() Failed: %08X\n", ret );
//     // }



//     void *temp = malloc(0x4000);
//     memcpy(temp, page, 0x4000);
//     DEBUG( "dealloc()\n" );

//     if( KERN_SUCCESS != ( ret = mach_vm_deallocate( mach_task_self(),
//                             (mach_vm_address_t)page, 0x4000 ) ) )
//     {
//         DEBUG( "mach_vm_deallocate() Failed: %08X\n", ret );
//     }


//     if( KERN_SUCCESS != ( ret = mach_vm_allocate( mach_task_self(),
//                             (mach_vm_address_t*)&page, 0x4000, PROT_READ | PROT_EXEC ) ) )
//     {
//         DEBUG( "mach_vm_allocate() Failed: %08X\n", ret );
//     }


//     // // vm_deallocate(mach_task_self(), (vm_address_t)page, 0x4000);
//     // DEBUG("alloc call\n" );
//     // // vm_allocate( mach_task_self(), (vm_address_t *)&page, 0x4000, PROT_READ | PROT_EXEC );// VM_FLAGS_FIXED);
//     // DEBUG( "memcopy\n" );

//     memcpy(page, temp, 0x4000);
//     free(temp);
// }


typedef struct RefInst_t
{
    int                 link_type;
    uintptr_t           inst_offset;

    struct RefInst_t*   Next;
} RefInst_t;

typedef struct RelocDataLabel
{
    union Address
    {
        uint64_t    Data;
        uint8_t     DataChunks[ 8 ];
    } Address;

    uint8_t                 DataSize;
    struct RelocDataLabel*  Next;
    struct RefInst_t*       RefInsts;
} RelocDataLabel;



#define TRAMPOLINE_ARM64_ADRP_ADD_BR 3
#define TRAMPOLINE_ARM64_LDR_BR 4
#define ARM64_TMP_REG_NDX_0 17

#define ALIGN_FLOOR(address, range) ((uintptr_t)address & ~((uintptr_t)range - 1))
#define ALIGN ALIGN_FLOOR

// PC relative addressing.
enum PCRelAddressingOp
{
  PCRelAddressingFixed      = 0x10000000,
  PCRelAddressingFixedMask  = 0x1F000000,
  PCRelAddressingMask       = 0x9F000000,
  ADR                       = PCRelAddressingFixed | 0x00000000,
  ADRP                      = PCRelAddressingFixed | 0x80000000
};

enum RegisterType
{
    kRegister_32,
    kRegister_W             = kRegister_32,
    kRegister_64,
    kRegister_X             = kRegister_64,
    kRegister,

    kVRegister,
    kSIMD_FP_Register_8,
    kSIMD_FP_Register_B     = kSIMD_FP_Register_8,
    kSIMD_FP_Register_16,
    kSIMD_FP_Register_H     = kSIMD_FP_Register_16,
    kSIMD_FP_Register_32,
    kSIMD_FP_Register_S     = kSIMD_FP_Register_32,
    kSIMD_FP_Register_64,
    kSIMD_FP_Register_D     = kSIMD_FP_Register_64,
    kSIMD_FP_Register_128,
    kSIMD_FP_Register_Q     = kSIMD_FP_Register_128,

    kInvalid
};

// Unconditional branch to register.
enum UnconditionalBranchToRegisterOp
{
  UnconditionalBranchToRegisterFixed        = 0xD6000000,
  UnconditionalBranchToRegisterFixedMask    = 0xFE000000,
  UnconditionalBranchToRegisterMask         = 0xFFFFFC1F,

  BR    = UnconditionalBranchToRegisterFixed | 0x001F0000,
  BLR   = UnconditionalBranchToRegisterFixed | 0x003F0000,
  RET   = UnconditionalBranchToRegisterFixed | 0x005F0000
};

enum InstructionFields {

  // Registers.
  kRdShift  = 0,
  kRdBits   = 5,
  kRnShift  = 5,
  kRnBits   = 5,
  kRaShift  = 10,
  kRaBits   = 5,
  kRmShift  = 16,
  kRmBits   = 5,
  kRtShift  = 0,
  kRtBits   = 5,
  kRt2Shift = 10,
  kRt2Bits  = 5,
  kRsShift  = 16,
  kRsBits   = 5,

};

enum Shift
{
    NO_SHIFT    = -1,
    LSL         = 0x0,
    LSR         = 0x1,
    ASR         = 0x2,
    ROR         = 0x3,
    MSL         = 0x4
};

enum Extend
{
    NO_EXTEND   = -1,
    UXTB        = 0,
    UXTH        = 1,
    UXTW        = 2,
    UXTX        = 3,
    SXTB        = 4,
    SXTH        = 5,
    SXTW        = 6,
    SXTX        = 7
};


typedef enum RegisterType RegisterType;
typedef enum Shift Shift;
typedef enum Extend Extend;

typedef struct CPURegister
{
    int code;
    int size;
    RegisterType type;
} CPURegister;

typedef CPURegister Register;

typedef struct Operand
{
  int64_t   immediate_; // assume 0
  Register  reg_; // default: CPURegister { 0, 0, kInvalid } (InvalidRegister)

  Shift     shift_; // default: NO_SHIFT ( -1 )
  Extend    extend_; // default: NO_EXTEND ( -1 )
  int32_t   shift_extend_imm_; // default: 0
} Operand;



#define TMP_REG_0 (CPURegister){ ARM64_TMP_REG_NDX_0, 64, kRegister_64 }

#define LSHIFT( A, B, C ) \
    ( ( A & ( ( 1 << B ) - 1 ) ) << C )

#define RSHIFT( A, B, C ) \
    ( ( A >> C ) & ( ( 1 << B ) - 1 ) )

#define SUBMASK( X ) \
    ( ( 1L << ( ( X ) + 1 ) ) - 1 )

#define BITS( obj, st, fn ) \
    ( ( ( obj ) >> ( st ) ) & SUBMASK( ( fn ) - ( st ) ) )

#define RD( rd ) \
    ( rd->code << kRdShift )
#define RT( rt ) \
    ( rt->code << kRtShift )
#define RN( rn ) \
    ( rn->code << kRnShift )

#define OPT(op, attribute)      op##_##attribute
#define OPT_W(op, attribute)    op##_w_##attribute
#define OPT_X(op, attribute)    op##_x_##attribute
#define OPT_S(op, attribute)    op##_s_##attribute
#define OPT_D(op, attribute)    op##_d_##attribute
#define OPT_Q(op, attribute)    op##_q_##attribute

enum AddSubImmediateOp
{
    AddSubImmediateFixed        = 0x11000000,
    AddSubImmediateFixedMask    = 0x1F000000,
    AddSubImmediateMask         = 0xFF000000,

#define AddSubImmediateOpSub( sf, op, S ) \
    AddSubImmediateFixed \
    | LSHIFT( sf, 1, 31 ) \
    | LSHIFT( op, 1, 30 ) \
    | LSHIFT( S,  1, 29 )

    OPT_W( ADD,  imm )  = AddSubImmediateOpSub( 0, 0, 0 ),
    OPT_W( ADDS, imm )  = AddSubImmediateOpSub( 0, 0, 1 ),
    OPT_W( SUB,  imm )  = AddSubImmediateOpSub( 0, 1, 0 ),
    OPT_W( SUBS, imm )  = AddSubImmediateOpSub( 0, 1, 1 ),
    OPT_X( ADD,  imm )  = AddSubImmediateOpSub( 1, 0, 0 ),
    OPT_X( ADDS, imm )  = AddSubImmediateOpSub( 1, 0, 1 ),
    OPT_X( SUB,  imm )  = AddSubImmediateOpSub( 1, 1, 0 ),
    OPT_X( SUBS, imm )  = AddSubImmediateOpSub( 1, 1, 1 )
};

typedef enum AddSubImmediateOp AddSubImmediateOp;

enum ref_label_type_t { kLabelImm19 };

enum LoadRegLiteralOp
{
    LoadRegLiteralFixed     = 0x18000000,
    LoadRegLiteralFixedMask = 0x3B000000,
    LoadRegLiteralMask      = 0xFF000000,

#define LoadRegLiteralSub(opc, V) \
    LoadRegLiteralFixed \
    | LSHIFT( opc, 2, 30 ) \
    | LSHIFT( V,   1, 26 )

    OPT_W( LDR, literal )   = LoadRegLiteralSub( 0b00, 0 ),
    OPT_X( LDR, literal )   = LoadRegLiteralSub( 0b01, 0 ),
    OPT( LDRSW, literal )   = LoadRegLiteralSub( 0b10, 0 ),
    OPT( PRFM,  literal )   = LoadRegLiteralSub( 0b11, 0 ),
    OPT_S( LDR, literal )   = LoadRegLiteralSub( 0b00, 1 ),
    OPT_D( LDR, literal )   = LoadRegLiteralSub( 0b01, 1 ),
    OPT_Q( LDR, literal )   = LoadRegLiteralSub( 0b10, 1 ),
};


typedef
struct MemoryBuffer
{
    uint8_t* Buffer; // default: malloc( 64 )
    uint32_t BufferSize; // default: 0
    uint32_t BufferCapacity; // default: 64
} MemoryBuffer;


static
ErrorStatus
    ensure_capacity
    (
        IN          uint32_t            InputSize,
        IN  OUT     MemoryBuffer*       MemBuffer
    )
{
    ErrorStatus     retVal          = ERROR_FAILURE;
    uint32_t        new_capacity    = 0;
    uint8_t*        new_buffer      = NULL;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    // Ensure that the buffer can contain the input data
    if( MemBuffer->BufferCapacity > ( MemBuffer->BufferSize + InputSize ) )
    {
        retVal = ERROR_SUCCESS;
    }
    else {
        new_capacity = MemBuffer->BufferCapacity * 2;

        // Ensure capacity
        while( new_capacity < MemBuffer->BufferSize + InputSize )
        {
            new_capacity *= 2;
        }

        // Allocate and update buffer
        if( NULL == ( new_buffer = (uint8_t*)malloc( new_capacity ) ) )
        {
            retVal = ERROR_MEM_ALLOC;
        }
        else {
            memcpy( new_buffer,
                    MemBuffer->Buffer,
                    MemBuffer->BufferSize );

            // Memory Management
            free( MemBuffer->Buffer );

            MemBuffer->Buffer           = new_buffer;
            MemBuffer->BufferCapacity   = new_capacity;

            retVal                      = ERROR_SUCCESS;
        } // malloc()
    } // Buffer Size check

    DEBUGL( LOG_LEVEL_DEBUG,
            "retVal: %08" PRIx8 "\n",
            retVal );
    return retVal;
}

static
ErrorStatus
    Emit
    (
        IN          uint32_t            InputSize,
        IN          void*               InputData,
        IN  OUT     MemoryBuffer*       MemBuffer
    )
{
    ErrorStatus retVal = ERROR_FAILURE;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    //
    if( ERROR_SUCCESS != ( retVal = ensure_capacity( InputSize, MemBuffer ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "ensure_capactiy() Failed\n" )
    }
    else {
        memcpy( MemBuffer->Buffer + MemBuffer->BufferSize,
                InputData,
                InputSize );

        MemBuffer->BufferSize += InputSize;
    } // ensure_capactiy()

    DEBUGL( LOG_LEVEL_DEBUG,
            "retVal: %08" PRIx8 "\n",
            retVal );
    return retVal;
}


static
ErrorStatus
    Adrp
    (
        IN          Register*           Rd,
        IN          int64_t             imm,
        IN  OUT     MemoryBuffer*       MemBuffer
    )
{
    ErrorStatus     retVal      = ERROR_FAILURE;
    uint32_t        immlo       = 0;
    uint32_t        immhi       = 0;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    immlo = LSHIFT( BITS( imm >> 12, 0, 1 ),
                    2,
                    29 );
    immhi = RSHIFT( BITS( imm >> 12, 2, 20 ),
                    19,
                    5 );

    if( ERROR_SUCCESS != ( retVal = Emit( sizeof( uint32_t ),
                                          ( ADRP | RD( Rd ) | immlo | immhi ),
                                          MemBuffer ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "Emit() Failed\n" );
    }

    DEBUGL( LOG_LEVEL_DEBUG,
            "retVal: %08" PRIx8 "\n",
            retVal );
    return retVal;
}

static
ErrorStatus
    AddSubImmediate
    (
        IN          Register*           Rd,
        IN          Register*           Rn,
        IN          Operand*            Operand,
        IN          AddSubImmediateOp   op,
        IN  OUT     MemoryBuffer*       MemBuffer
    )
{
    ErrorStatus     retVal          = ERROR_FAILURE;
    int64_t         immediate       = 0;
    int32_t         imm12           = 0;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    if( Operand->reg_.code != 0 )
    {
        DEBUGL( LOG_LEVEL_ERROR, "Operand is not Immidate!\n" );
        retVal = ERROR_FAILURE;
    }
    else {
        immediate   = Operand->immediate_;
        imm12       = LSHIFT( immediate, 12, 10 );

        if( ERROR_SUCCESS != ( retVal = Emit( sizeof( uint32_t ),
                                              ( op | RD( Rd ) | RN( Rn ) | imm12 ),
                                              MemBuffer ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "Emit() Failed\n" )
        } // Emit()
    } // IsImmediate()

    DEBUGL( LOG_LEVEL_DEBUG,
            "retVal: %08" PRIx8 "\n",
            retVal );
    return retVal;
}


static
ErrorStatus
    add
    (
        const Register* Rd,
        const Register* Rn,
        int64_t imm,
        IN  OUT     MemoryBuffer*       MemBuffer
    )
{
    ErrorStatus retVal = ERROR_FAILURE;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    if( ( Rd->size == 64 ) && ( Rn->size == 64 ) )
    {
        retVal = AddSubImmediate( Rd,
                                    Rn,
                                    (Operand*)imm,
                                    OPT_X( ADD, imm ),
                                    MemBuffer );
    }
    else {
        retVal = AddSubImmediate( Rd,
                                    Rn,
                                    (Operand*)imm,
                                    OPT_W( ADD, imm ),
                                    MemBuffer );
    }

    DEBUGL( LOG_LEVEL_DEBUG,
            "retVal: %08" PRIx8 "\n",
            retVal );
    return retVal;
}

static
ErrorStatus
    AdrpAdd
    (
        Register* Rd,
        uint64_t From,
        uint64_t To,
        IN  OUT     MemoryBuffer*       MemBuffer
    )
{
    ErrorStatus     retVal          = ERROR_FAILURE;
    uint64_t        from_PAGE       = ALIGN( From, 0x1000 );
    uint64_t        to_PAGE         = ALIGN( To, 0x1000 );
    uint64_t        to_PAGEOFF      = ( uint64_t )To % 0x1000;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    if( ERROR_SUCCESS != ( retVal = Adrp( Rd,
                                          to_PAGE - from_PAGE,
                                          MemBuffer ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "Adrp() Failed\n" );
    }
    else {
        retVal = add( Rd,
                        Rd,
                        to_PAGEOFF,
                        MemBuffer );
    } // Adrp()

    DEBUGL( LOG_LEVEL_DEBUG,
            "retVal: %08" PRIx8 "\n",
            retVal );
    return retVal;
}


typedef enum LoadRegLiteralOp LoadRegLiteralOp;



static
ErrorStatus
    ldr
    (
        Register* Rt,
        int64_t imm,
        IN  OUT     MemoryBuffer*       MemBuffer
    )
{
    ErrorStatus         retVal      = ERROR_FAILURE;
    LoadRegLiteralOp    op          = kInvalid;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    switch( Rt->type )
    {
        case kRegister_32:
        {
            op = OPT_W( LDR, literal );
            break;
        }
        case kRegister_X:
        {
            op = OPT_X( LDR, literal );
            break;
        }
        case kSIMD_FP_Register_S:
        {
            op = OPT_S( LDR, literal );
            break;
        }
        case kSIMD_FP_Register_D:
        {
            op = OPT_D( LDR, literal );
            break;
        }
        case kSIMD_FP_Register_Q:
        {
            op = OPT_Q( LDR, literal );
            break;
        }
        default:
        {
            DEBUGL( LOG_LEVEL_CRITICAL, "Unexpected Register type!\n" );
            break;
        }
    }

    if( kInvalid != op )
    {
        retVal = Emit( sizeof( uint32_t ),
                        ( op | LSHIFT( imm >> 2, 26, 5 ) | RT( Rt ) ),
                        MemBuffer );
    }

    DEBUGL( LOG_LEVEL_DEBUG,
            "retVal: %08" PRIx8 "\n",
            retVal );
    return retVal;
}


static
ErrorStatus
    Ldr
    (
        IN          Register*           Rt,
        // IN          PseudoLabel*        Label,
        IN  OUT     MemoryBuffer*       MemBuffer
    )
{
    ErrorStatus retVal = ERROR_FAILURE;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );


    // Label->link_to( kLabelImm19, pc_offset() );

    // ref_inst_t* ref = NULL;

    // ref = malloc( sizeof( ref_inst_t ) );

    // ref->link_type = kLabelImm19;
    // ref->inst_offset = MemBuffer->BufferSize;


    retVal = ldr( Rt, 0, MemBuffer );

    DEBUGL( LOG_LEVEL_DEBUG,
            "retVal: %08" PRIx8 "\n",
            retVal );
    return retVal;
}



static
ErrorStatus
    CreateDataLabel
    (
        uint64_t Address
    )
{
    ErrorStatus retVal = ERROR_FAILURE;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );



    DEBUGL( LOG_LEVEL_DEBUG,
            "retVal: %08" PRIx8 "\n",
            retVal );
    return retVal;
}

static RelocDataLabel* Head = NULL;

static
void
    AddNode
    (
        RelocDataLabel* Node
    )
{
    if( NULL == Head )
    {
        Head = Node;
    }
    else {
        RelocDataLabel* temp = Head;

        while( NULL != temp->Next )
        {
            temp = temp->Next;
        }
        temp->Next = Node;
    }
}

static
ErrorStatus
    LiteralLdrBranch
    (
        uint64_t Address,
        IN  OUT     MemoryBuffer*       MemBuffer
    )
{
    ErrorStatus retVal = ERROR_FAILURE;

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    // CreateDataLabel( Address );

    RelocDataLabel* label = (RelocDataLabel*)malloc( sizeof( RelocDataLabel ) );

    label->Address.Data = Address;
    label->DataSize     = sizeof( uint64_t );
    label->Next         = NULL;

    label->RefInsts     = malloc( sizeof( RefInst_t ) );

    label->RefInsts->link_type      = kLabelImm19;
    label->RefInsts->inst_offset    = MemBuffer->BufferSize;

    AddNode( label );

    CPURegister* reg = &TMP_REG_0;

    if( ERROR_SUCCESS != ( retVal = Ldr( reg, MemBuffer ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "Ldr() Failed\n" );
    }
    else {
        retVal = Emit( sizeof( uint32_t ),
                        ( BR | RN( reg ) ),
                        MemBuffer );
    } // Ldr()

    DEBUGL( LOG_LEVEL_DEBUG,
            "retVal: %08" PRIx8 "\n",
            retVal );
    return retVal;
}

// static
//     RelocDataLabels
//     (

//     )
// {
//     RelocDataLabel* temp = Head;

//     while( NULL != temp )
//     {
//         temp->pos =


//         temp = temp->Next;
//     }

// }

static
ErrorStatus
    GenerateNormalTrampolineBuffer
    (
        addr_t From,
        addr_t To,
        IN  OUT     MemoryBuffer*       MemBuffer
    )
{
    ErrorStatus     retVal          = ERROR_FAILURE;
    int             tramp_type      = 0;
    CPURegister*    reg             = NULL;
    uint64_t        distance        = llabs( (int64_t)( From - To ) );
    uint64_t        adrp_range      = ( (uint64_t)1 << ( 2 + 19 + 12 - 1 ) );

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );

    if( distance < adrp_range )
    {
        DEBUGL( LOG_LEVEL_INFO, "Trampoline: TRAMPOLINE_ARM64_ADRP_ADD_BR\n" );

        tramp_type  = TRAMPOLINE_ARM64_ADRP_ADD_BR;
        reg         = &TMP_REG_0;

        if( ERROR_SUCCESS != ( retVal = AdrpAdd( reg,
                                                From,
                                                To,
                                                MemBuffer ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "AdrpAdd() Failed\n" );
        }
        else {
            retVal = Emit( sizeof( uint32_t ),
                            ( BR | RN( reg ) ),
                            MemBuffer );
        }
    }
    else {
        DEBUGL( LOG_LEVEL_INFO, "Trampoline: TRAMPOLINE_ARM64_LDR_BR\n" );

        tramp_type = TRAMPOLINE_ARM64_LDR_BR;

        retVal = LiteralLdrBranch( (uint64_t)To, MemBuffer );
    }

    // Bind all labels
    // RelocDataLabels();




    DEBUGL( LOG_LEVEL_DEBUG,
            "retVal: %08" PRIx8 "\n",
            retVal );
    return retVal;
}










typedef struct CodeMemBlock
{
    addr_t start;
    size_t size;
} CodeMemBlock;

typedef struct relo_ctx_t
{
  addr_t cursor;
  uint32_t relocated_insn_count;

  CodeMemBlock* origin;
  CodeMemBlock* relocated;
  MemoryBuffer* relocated_buffer;
} relo_ctx_t;






void
    GenRelocateCodeAndBranch
    (
        void *buffer,
        CodeMemBlock *origin,
        CodeMemBlock *relocated
    )
{

}

static
void
    GenerateRelocatedCode
    (
        uintptr_t CodeAddr
    )
{
    CodeMemBlock* origin = malloc( sizeof( CodeMemBlock ) );
    CodeMemBlock* relocated = malloc( sizeof( CodeMemBlock ) );

    origin->start = CodeAddr;
    origin->size = 64;

    GenRelocateCodeAndBranch((void *)CodeAddr, origin, relocated);




}

static
ErrorStatus
    GenerateTrampoline
    (
        IN      void*           Address,
        IN      void*           FakeFunction,
        OUT     void**          OriginalFunction
    )
{
    ErrorStatus retVal = ERROR_FAILURE;

    addr_t from = Address;
    addr_t to = (addr_t)FakeFunction;

    // GenerateNearTrampolineBuffer(from, to)

    MemoryBuffer* AssembleBuffer = malloc( sizeof( MemoryBuffer ) );

    AssembleBuffer->Buffer = malloc( 64 );
    AssembleBuffer->BufferSize = 0;
    AssembleBuffer->BufferCapacity = 64;


    GenerateNormalTrampolineBuffer( from, to, AssembleBuffer );

    GenerateRelocatedCode( from );

    return retVal;
}






#include "dobby.h"


int main()
{






    // select_target_framework( "CoreAudio" );
    // select_target_framework2( "CoreAudio", "CoreAudioProcess" );


    // /System/Library/PrivateFrameworks/AudioToolboxCore.framework/Versions/A/AudioToolboxCore

    // void* audioUnitLib = NULL;

    // if( NULL == ( audioUnitLib = dlopen( "/System/Library/Frameworks/AudioUnit.framework/Versions/A/AudioUnit", RTLD_LAZY ) ) )
    // {
    //     printf( "Failed to open AudioUnit framework\n" );
    // }
    // else {
    //     if( NULL == ( AudioUnitProcess_orig = dlsym( audioUnitLib, "AudioUnitProcess" ) ) )
    //     {
    //         printf( "AudioUnitProcess symbol not found\n" );
    //     }
    //     else {
    //         printf( "Successfully linked AudioUnitProcess!\n" );
    //     }

    //     dlclose( audioUnitLib );
    // }

    DEBUGL( LOG_LEVEL_DEBUG, "enter\n" );
    DEBUG( "SUCCA\n" );


    uint32_t img_cnt = 0;
    uint32_t img_itr = 0;
    mach_header_t* mach_header = NULL;
    char* image_name = NULL;




    // char* framework_image = "/System/Library/PrivateFrameworks/AudioToolboxCore.framework/Versions/A/AudioToolboxCore";
    char framework_image[] = "AudioToolboxCore";
    const char symbol_name_pattern[] = "AudioUnitProcess";


    img_cnt = _dyld_image_count();

    for( img_itr = 0; img_itr < img_cnt; img_itr++ )
    {
        // printf(  "%x\n", img_itr );
        if( NULL == ( image_name = (char*)_dyld_get_image_name( img_itr ) ) )
            continue;

        // printf( "Image Name: %s\n", image_name );

        if( !strnstr( (const char*)image_name, (const char*)framework_image, PATH_MAX ) )
            continue;

        if( NULL == ( mach_header = (mach_header_t*)_dyld_get_image_header( img_itr ) ) )
            continue;

        nlist_t *symtab = NULL;
        uint32_t symtab_count = 0;
        char *strtab = NULL;

        const char* cache_path = dyld_shared_cache_file_path();

        DEBUGL( LOG_LEVEL_INFO,
                "Cache Path: %s\n",
                cache_path );

        static shared_cache_ctx_t shared_cache_ctx;
        shared_cache_ctx_init(&shared_cache_ctx);
        shared_cache_load_symbols(&shared_cache_ctx);

        if( shared_cache_ctx.MmapSharedCache )
        {
            if( shared_cache_contains( &shared_cache_ctx, (addr_t)mach_header ) )
            {
                shared_cache_get_symbol_table( &shared_cache_ctx,
                                                mach_header,
                                                &symtab,
                                                &symtab_count,
                                                &strtab );
            }
        }

        if( symtab && strtab )
        {
            result = macho_iterate_symbol_table( (char*) symbol_name_pattern,
                                                 symtab,
                                                 symtab_count,
                                                 strtab );
        }
        if( result )
        {
            result = result + shared_cache_ctx.RuntimeSlide;
            DEBUGL( LOG_LEVEL_NOTICE, "result = result + shared_cache_ctx.RuntimeSlide\n" );
            // return (void *)result;
            return 0;
        }

        macho_ctx_t MachoContext = { 0 };

        macho_ctx_init(mach_header,true, NULL, &MachoContext);
        // result = macho_ctx.symbol_resolve(symbol_name_pattern);
        uintptr_t retCode = NULL;
        result = symbol_resolve_options( &MachoContext, symbol_name_pattern, RESOLVE_SYMBOL_TYPE_ALL, &retCode );

        retCode = retCode + ( MachoContext.IsRuntimeMode ? MachoContext.Slide : 0 );

        if( result )
        {
            DEBUGL( LOG_LEVEL_NOTICE,
                    "Resolved Symbol: %" PRIuPTR "\n",
                    result );
            DEBUGL( LOG_LEVEL_NOTICE,
                    "AudioUnitProcess: %" PRIuPTR "\n",
                    (uintptr_t)( AudioUnitProcess ) );
            DEBUGL( LOG_LEVEL_NOTICE,
                    "retCode: %" PRIuPTR "\n",
                    (uintptr_t)(retCode) );
            DEBUGL( LOG_LEVEL_NOTICE,
                    "RuntimeSlide: %X\n",
                    (uintptr_t)( MachoContext.IsRuntimeMode ? MachoContext.Slide : 0 ) );

            AudioUnit                       inUnit                  = NULL;
            AudioUnitRenderActionFlags*     ioActionFlags           = NULL;
            const AudioTimeStamp*           inTimeStamp             = NULL;
            AudioBufferList*                ioData                  = NULL;
            uint32_t                        inNumberFrames          = 0;

            OSStatus error_code1 = ((AudioUnitProcess_t)result)( inUnit,
                                                ioActionFlags,
                                                inTimeStamp,
                                                inNumberFrames,
                                                ioData );
            DEBUGL( LOG_LEVEL_NOTICE,
                    "error_code1: 0x%X\n",
                    error_code1 );

            // uintptr_t* xcode = result;
            // xcode -= MachoContext.Slide;
            // *xcode = *(uintptr_t*)testHook;

            DEBUGL( LOG_LEVEL_NOTICE,
                    "AudioUnitProcess: %" PRIuPTR "\n",
                    (uintptr_t)( AudioUnitProcess ) );


            // *(OSStatus*)(result - MachoContext.Slide) = testHook;

            // *(AudioUnitProcess_t*)result = testHook;

            error_code1 = ((AudioUnitProcess_t)result)( inUnit,
                                                ioActionFlags,
                                                inTimeStamp,
                                                inNumberFrames,
                                                ioData );
            DEBUGL( LOG_LEVEL_NOTICE,
                    "error_code1: 0x%X\n",
                    error_code1 );


            // return (void *)result;

            // *(OSStatus*)result = *(OSStatus*)testHook;


            // *(OSStatus*)(&result) = testHook;

            // *(OSStatus*)&result = testHook;

            // DobbyHook( (void*)result, testHook, (void**)&AudioUnitProcess_orig );

            DEBUGL( LOG_LEVEL_INFO, "Calling ORIGINAL\n" );
            error_code1 = AudioUnitProcess( inUnit, ioActionFlags, inTimeStamp, inNumberFrames, ioData );
            DEBUGL( LOG_LEVEL_NOTICE,
                    "error_code1: 0x%X\n",
                    error_code1 );

        // #include <ptrauth.h>

        // __builtin_pac_strip();
        // __builtin_pac_sing();


        //    #include "dobby.h"

        //     if( 0 != DobbyHook( (void*)result, testHook, (void**)&AudioUnitProcess_orig ) )
        //     {
        //         DEBUGL( LOG_LEVEL_ERROR, "DobbyHook Failed\n" );
        //     }

        //     OSStatus error_code = AudioUnitProcess( inUnit,ioActionFlags,inTimeStamp,inNumberFrames,ioData );
        //     DEBUGL( LOG_LEVEL_NOTICE,
        //             "AudioUnitProcess(): %X\n",
        //             error_code );



            // OSStatus error_code1 = ((AudioUnitProcess_t)result)( inUnit,
            //                                     ioActionFlags,
            //                                     inTimeStamp,
            //                                     inNumberFrames,
            //                                     ioData );
            // DEBUGL( LOG_LEVEL_NOTICE,
            //         "error_code1: %X\n",
            //         error_code1 );
            // return (void *)result;

            // unprotect_page((void *)(((uintptr_t)result) & ~0x3FFF));




            // // MachoContext.VmRegionEnd

            // // uintptr_t slide = (uintptr_t)MachoContext.Header - MachoContext.FIRSTSEGMENT->vmaddr; // Segments[0]->vmaddr;
            // void **address = (void **)( MachoContext.DataConstSegment->vmaddr + MachoContext.Slide );
            // void **end = (void **)( MachoContext.DataConstSegment->vmaddr + MachoContext.DataConstSegment->vmsize + MachoContext.Slide );

            // // void **address = (void **)(&MachoContext.VmRegionStart + MachoContext.Slide);
            // // void **end = (void **)(&MachoContext.VmRegionEnd + MachoContext.Slide);

            // bool printed = false;

            // while( address < end )
            // {
            //     if( !printed )
            //     {
            //         DEBUG( "iteration!\n" );
            //         printed = true;
            //     }

            //     DEBUG( "Checking Address: %" PRIuPTR "\n", ((uintptr_t)*address & 0xFFFFFFFFFFF) );

            //     if( ( (uintptr_t)*address & 0xFFFFFFFFFFF ) == ( (uintptr_t)(AudioUnitProcess) & 0xFFFFFFFFFFF ) )
            //     {
            //         DEBUG( "OK doing it.\n" );
            //         unprotect_page((void *)(((uintptr_t)address) & ~0x3FFF));

            //         *address = ptrauth_sign_unauthenticated( (void *)((uintptr_t)&testHook & 0xFFFFFFFFFFF),
            //                                                  ptrauth_key_function_pointer,
            //                                                  address );
            //     }
            //     address++;
            // }

            // DEBUG( "loop must be done?\n" );

            // ptrauth_sign_unauthenticated( &testHook, ptrauth_key_function_pointer, result );

            // OSStatus error_code = AudioUnitProcess(inUnit,ioActionFlags,inTimeStamp,inNumberFrames,ioData);

            // kern_return_t error_code = ((AudioUnitProcess_t)result)( inUnit,
            //                                     ioActionFlags,
            //                                     inTimeStamp,
            //                                     inNumberFrames,
            //                                     ioData );
            // DEBUG( "error_code: %X\n", error_code );
            // return (void *)result;




            // const struct load_command *cmd = (typeof(cmd))(mach_header + 1);
            // const struct segment_command_64 *first = NULL;
            // const struct segment_command_64 *data = NULL;
            // for (unsigned i = 0; i < mach_header->ncmds; i++, cmd = (typeof(cmd)) ((char*) cmd + cmd->cmdsize)) {
            //     if (cmd->cmd == LC_SEGMENT_64) {
            //         if (!first && ((typeof(first))cmd)->filesize ) {
            //             first = (typeof(first)) cmd;
            //         }
            // #ifndef __arm64__
            //         if (strcmp(((typeof(data))cmd)->segname, "__DATA") == 0) {
            // #else
            //         if (strcmp(((typeof(data))cmd)->segname, "__DATA_CONST") == 0) {
            // #endif
            //             data = (typeof(data))cmd;
            //             break;
            //         }
            //     }
            // }
            // uintptr_t slide = (uintptr_t)mach_header - first->vmaddr;
            // void **address = (void **)(data->vmaddr + slide);
            // void **end = (void **)(data->vmaddr + data->vmsize + slide);
            // while (address < end) {
            // #if __arm64__
            //     if (((uintptr_t)*address & 0xFFFFFFFFFFF) == ((uintptr_t)(AudioUnitProcess) & 0xFFFFFFFFFFF)) {
            //         DEBUG( "Yup found it brah\n" );
            //         unprotect_page((void *)(((uintptr_t)address) & ~0x3FFF));
            //         *address = ptrauth_sign_unauthenticated((void *)((uintptr_t)&testHook & 0xFFFFFFFFFFF), ptrauth_key_function_pointer, address);
            //     }
            // #else
            //     if (*address == xpc_dictionary_get_int64) {
            //         *address = xpc_dictionary_get_int64_hook;
            //     }
            // #endif
            //     address++;
            // }

            // OSStatus error_code = AudioUnitProcess(inUnit,ioActionFlags,inTimeStamp,inNumberFrames,ioData);
            // DEBUG( "error_code: %X\n", error_code );


        }
        else {
            printf( "Did not resolve\n" );
        }

        // #include "audio/dobby.h"
        // void* dobbySym = DobbySymbolResolver( NULL, "AudioUnitProcess" );

        // printf( "DobbySymbol: %X\n", dobbySym );

    }

    return 0;
}