#ifndef __PSEUDO_LABEL_H__
#define __PSEUDO_LABEL_H__

#include <stdio.h>
#include <stdint.h>
#include "CodeMemBuffer.h"

typedef struct ref_inst_t
{
    int link_type;
    size_t inst_offset;
} ref_inst_t;

typedef struct PseudoLabel
{
    uintptr_t pos;
    ref_inst_t *ref_insts;
    size_t ref_insts_count;
} PseudoLabel;

PseudoLabel*
    PseudoLabel_create
    (
        uintptr_t pos
    );

void
    PseudoLabel_destroy
    (
        PseudoLabel* label
    );

void
    PseudoLabel_link_to
    (
        PseudoLabel* label,
        int link_type,
        size_t pc_offset
    );


void
    PseudoLabel_link_confused_instructions
    (
        PseudoLabel* label,
        CodeMemBuffer* buffer
    );

#endif // __PSEUDO_LABEL_H__