
// -----------------------------------------------------------------------------
//  INCLUDES
// -----------------------------------------------------------------------------

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <mach/mach.h>
#include <mach/vm_page_size.h>
#include <stddef.h>
#include <limits.h>

#if __has_feature( ptrauth_calls )
    #include <ptrauth.h>
#endif

#if __APPLE__
    #include <libkern/OSCacheControl.h>
#endif

#include "Hook/InlineHook.h"
#include "Hook/Assembler.h"

#include "utility/utility.h"
#include "utility/error.h"

#include "Memory/MemoryTracker.h"
#include "Memory/MemoryAllocator.h"

// Binary Warfare Zone & Reconnaissance
// Binary Warfare & System Reconnaissance

// -----------------------------------------------------------------------------
//  STRUCTURES & DEFINITIONS
// -----------------------------------------------------------------------------

#define W( RegisterID ) (Register)      \
{                                       \
    .RegisterId     = RegisterID,       \
    .RegisterSize   = 32,               \
    .RegisterType   = kRegister_32      \
}

#define X( RegisterID ) (Register)      \
{                                       \
    .RegisterId     = RegisterID,       \
    .RegisterSize   = 64,               \
    .RegisterType   = kRegister_64      \
}

#define MEMOP_ADDR( ADDRESS_MODE ) (MemOperand)     \
{                                                   \
    .Base           = TMP_REG_0,                    \
    .Offset         = 0,                            \
    .AddressMode    = ADDRESS_MODE                  \
}

#define ARM64_TMP_REG_NDX_0 17

#define ALIGN_FLOOR( ADDRESS, RANGE ) \
    ( (uintptr_t) ADDRESS & ~( (uintptr_t) RANGE - 1 ) )

#define arm64_trunc_page( x ) \
    ( ( x ) & ( ~( 0x1000 - 1 ) ) )

// Generate a bitmask with 'BitShift + 1' bits set to 1.
#define GENERATE_BIT_MASK( BitShift ) \
    ( ( 1L << ( ( BitShift ) + 1 ) ) - 1 )

// Extract bits from 'Bits' starting at position 'StartBit' to 'EndBit' (inclusive).
#define GET_BITS( Bits, StartBit, EndBit ) \
    ( ( ( Bits ) >> ( StartBit ) ) & GENERATE_BIT_MASK( ( EndBit ) - ( StartBit ) ) )

// Extract a single bit from 'Bits' at position 'BitPos'.
#define GET_BIT( Bits, BitPos ) \
    ( ( ( Bits ) >> ( BitPos ) ) & 1 )

// Set a specific bit in 'Bits' at position 'BitPos' to 'Bit' (0 or 1).
#define SET_BIT( Bits, BitPos, Bit ) \
    ( Bits = ( ( ( ~( 1 << ( BitPos ) ) ) & ( Bits ) ) | ( ( Bit ) << ( BitPos ) ) ) )

// Set bits in 'Bits' from position 'StartBit' to 'EndBit' with bits from 'ReplacementBits'.
#define SET_BITS( Bits, StartBit, EndBit, ReplacementBits ) \
    ( Bits = ( ( ( ~( GENERATE_BIT_MASK( ( EndBit ) - ( StartBit ) ) << ( StartBit ) ) ) & ( Bits ) ) \
                | ( ( ReplacementBits ) << ( StartBit ) ) ) )


// Unconditional branch.
typedef enum UnconditionalBranchOp {
    UnconditionalBranchFixed            = 0x14000000,
    UnconditionalBranchFixedMask        = 0x7C000000,
    UnconditionalBranchMask             = 0xFC000000,
    B                                   = UnconditionalBranchFixed | 0x00000000,
    BL                                  = UnconditionalBranchFixed | 0x80000000,
} UnconditionalBranchOp;

// Compare and branch.
typedef enum CompareBranchOp {
    CompareBranchFixed      = 0x34000000,
    CompareBranchFixedMask  = 0x7E000000,
} CompareBranchOp;

// Conditional branch.
typedef enum ConditionalBranchOp {
    ConditionalBranchFixed      = 0x54000000,
    ConditionalBranchFixedMask  = 0xFE000000,
    ConditionalBranchMask       = 0xFF000010,
} ConditionalBranchOp;

// Test and branch.
typedef enum TestBranchOp {
    TestBranchFixed         = 0x36000000,
    TestBranchFixedMask     = 0x7E000000,
} TestBranchOp;



typedef struct InterceptRouting InterceptRouting;

typedef struct Trampoline {
    MemoryRange         Buffer;
} Trampoline;

typedef struct InterceptorEntry {
    uintptr_t           HookFunctionAddress;
    uintptr_t           Address;
    MemoryRange         Patched;
    MemoryRange         Relocated;
    InterceptRouting*   Routing;
    uint8_t*            OriginalCode;
} InterceptorEntry;

struct {
    uint32_t            Rd         : 5;    // Destination register
    uint32_t            immhi      : 19;   // 19-bit upper immediate
    uint32_t            dummy_0    : 5;    // Must be 10000 == 0x10
    uint32_t            immlo      : 2;    // 2-bit lower immediate
    uint32_t            op         : 1;    // 0 = ADR, 1 = ADRP
} InstructionDecoder;

typedef struct RelocationContext {
    uintptr_t           Cursor;
    MemoryRange*        BaseAddress;
    MemoryRange         RelocatedBlock;
    MemoryBuffer*       RelocatedBuffer;
} RelocationContext;

typedef struct InterceptRouting {
    InterceptorEntry*       InterceptEntry;
    Trampoline*             Trampoline;
    uintptr_t               HookFunction;
    __typeof( vm_protect )* VMProtect;
} InterceptRouting;

// -----------------------------------------------------------------------------
//  GLOBALS
// -----------------------------------------------------------------------------

static const Register   TMP_REG_0   = X( ARM64_TMP_REG_NDX_0 );

static MemoryAllocator  gMemoryAllocator;

// -----------------------------------------------------------------------------
//  PROTOTYPES
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
//  IMPLEMENTATION
// -----------------------------------------------------------------------------

static
BWSR_STATUS
    ApplyCodePatch
    (
        IN          InterceptRouting*       Routing,
        IN          void*                   Address,
        IN          uint8_t*                Buffer,
        IN          uint32_t                BufferSize
    )
{
    BWSR_STATUS     retVal              = ERROR_FAILURE;
    uintptr_t       patchPage           = ALIGN_FLOOR( Address, vm_page_size );
    uintptr_t       remapDestPage       = patchPage;
    kern_return_t   kernReturn          = KERN_FAILURE;
    uint32_t        pageBoundary        = 0;
    uint32_t        crossOverBoundary   = 0;
    uintptr_t       crossOverPage       = 0;

    __NOT_NULL( Address, Buffer );
    __GREATER_THAN_0( BufferSize );

    // Handle case where patch crosses over page boundary
    if( ( (uintptr_t)Address + BufferSize ) > ( patchPage + vm_page_size ) )
    {
        pageBoundary = ( patchPage + vm_page_size - (uintptr_t)Address );

        if( ERROR_SUCCESS != ( retVal = ApplyCodePatch( Routing,
                                                        (void*) Address,
                                                        Buffer,
                                                        pageBoundary ) ) )
        {
            return retVal;
        } // ApplyCodePatch()

        crossOverPage       = (uintptr_t)Address + pageBoundary;
        crossOverBoundary   = BufferSize - pageBoundary;

        return ApplyCodePatch( Routing,
                               (void*) crossOverPage,
                               Buffer + pageBoundary,
                               crossOverBoundary );
    }

    if( KERN_SUCCESS != ( kernReturn = Routing->VMProtect( mach_task_self(),
                                                           remapDestPage,
                                                           vm_page_size,
                                                           false,
                                                           ( VM_PROT_READ | VM_PROT_WRITE | VM_PROT_COPY ) ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR,
                "vm_protect() Failed: %s\n",
                mach_error_string( kernReturn ) );
        retVal = ERROR_MEMORY_PERMISSION;
    }
    else {
        memcpy( (void*) ( patchPage + ( (uint64_t)Address - remapDestPage ) ),
                Buffer,
                BufferSize );

        if( KERN_SUCCESS != ( kernReturn = Routing->VMProtect( mach_task_self(),
                                                               remapDestPage,
                                                               vm_page_size,
                                                               false,
                                                               ( VM_PROT_READ | VM_PROT_EXECUTE ) ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR,
                    "vm_protect() Failed: %s\n",
                    mach_error_string( kernReturn ) );
            retVal = ERROR_MEMORY_PERMISSION;
        }
        else {
            retVal = ERROR_SUCCESS;
        } // Routing->VMProtect()
    } // Routing->VMProtect()

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
BWSR_STATUS
    Interceptor_BackupOriginalCode
    (
        IN          InterceptorEntry*       Entry
    )
{
    BWSR_STATUS     retVal              = ERROR_FAILURE;
    uint8_t*        originalCode        = NULL;
    uint32_t        trampolineSize      = 0;

    __NOT_NULL( Entry );

    originalCode   = (uint8_t*) Entry->Address;
    trampolineSize = Entry->Patched.Size;

    if( NULL == ( Entry->OriginalCode = (uint8_t*) BwsrMalloc( trampolineSize ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "BwsrMalloc() Failed\n" );
        retVal = ERROR_MEM_ALLOC;
    }
    else {
        memcpy( Entry->OriginalCode,
                originalCode,
                trampolineSize );

        retVal = ERROR_SUCCESS;
    } // BwsrMalloc()

    __DEBUG_RETVAL( retVal );
    return retVal;
}


static
BWSR_STATUS
    GenerateNormalTrampolineBuffer
    (
        IN  OUT     Trampoline**            TrampolineBuffer,
        IN          uintptr_t               From,
        IN          uintptr_t               To
    )
{
    BWSR_STATUS     retVal          = ERROR_FAILURE;
    Assembler       assembler       = { 0 };
    uint64_t        distance        = 0;
    uint64_t        adrpRange       = 0;
    uint8_t*        buffer          = NULL;
    uint32_t        value           = 0;

    __NOT_NULL( TrampolineBuffer );

    if( ERROR_SUCCESS != ( retVal = Assembler_Initialize( &assembler, From ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "Assembler_Initialize() Failed\n" );
    }
    else {
        distance    = llabs( (int64_t) ( From - To ) );
        adrpRange   = ( UINT32_MAX - 1 );

        if( distance < adrpRange )
        {
            if( ERROR_SUCCESS != ( retVal = Assembler_ADRP_ADD( &assembler.Buffer,
                                                                (Register*) &TMP_REG_0,
                                                                From,
                                                                To ) ) )
            {
                DEBUGL( LOG_LEVEL_ERROR, "Assembler_ADRP_ADD() Failed\n" );
            }
            else {
                value  = ( BR | ( ARM64_TMP_REG_NDX_0 << kRnShift ) );
                retVal = Assembler_Write32BitInstruction( &assembler.Buffer, value );
            } // Assembler_ADRP_ADD()
        }
        else {
            retVal = Assembler_LiteralLdrBranch( &assembler, (uint64_t)To );
        } // distance < adrp_range

        if( ERROR_SUCCESS == retVal )
        {
            if( ERROR_SUCCESS != ( retVal = Assembler_WriteRelocationDataToPageBuffer( &assembler ) ) )
            {
                DEBUGL( LOG_LEVEL_ERROR, "Assembler_WriteRelocationDataToPageBuffer() Failed\n" );
            }
            else {
                if( NULL == ( buffer = (uint8_t*) BwsrMalloc( assembler.Buffer.BufferSize ) ) )
                {
                    DEBUGL( LOG_LEVEL_ERROR, "BwsrMalloc() Failed\n" );
                    retVal = ERROR_MEM_ALLOC;
                }
                else {
                    memcpy( buffer,
                            assembler.Buffer.Buffer,
                            assembler.Buffer.BufferSize );

                    if( NULL == ( *TrampolineBuffer = (Trampoline*) BwsrMalloc( sizeof( Trampoline ) ) ) )
                    {
                        DEBUGL( LOG_LEVEL_ERROR, "BwsrMalloc() Failed\n" );
                        free( buffer );
                        retVal = ERROR_MEM_ALLOC;
                    }
                    else {
                        ( *TrampolineBuffer )->Buffer.Start = (uintptr_t)buffer;
                        ( *TrampolineBuffer )->Buffer.Size  = assembler.Buffer.BufferSize;
                    } // BwsrMalloc()
                } // BwsrMalloc()
            } // Assembler_WriteRelocationDataToPageBuffer()
        } // SUCCESS
    } // Assembler_Initialize()

    (void) Assembler_Release( &assembler );

    __DEBUG_RETVAL( retVal )
    return retVal;
}

static
uintptr_t
    GetContextCursor
    (
        IN          RelocationContext*      Context
    )
{
    return (uintptr_t)( Context->BaseAddress->Start + ( Context->Cursor - Context->BaseAddress->Start ) );
}


static inline int64_t SignExtend(unsigned long x, int M, int N)
{
    char sign_bit = GET_BIT( x, N - 1 );
    unsigned long sign_mask = 0 - sign_bit;
    x |= ( ( sign_mask >> M ) << M );
    return (int64_t)x;
}

static inline int64_t Imm26Offset(uint32_t Instruction)
{
    int64_t offset;
    {
        int64_t imm26 = GET_BITS( Instruction, 0, 25 );
        offset = ( imm26 << 2 );
    }
    offset = SignExtend( offset, 28, 64 );
    DEBUGL( LOG_LEVEL_INFO, "OFFSET: %lld\n", offset );
    return offset;
}
static inline int64_t Imm19Offset(uint32_t Instruction)
{
    int64_t offset;
    {
        offset = ( GET_BITS( Instruction, 5, 23 ) << 2 );
    }
    offset = SignExtend( offset, 21, 64 );
    return offset;
}
static inline int64_t ImmHiImmLoOffset(uint32_t Instruction)
{
    *(uint32_t*) &InstructionDecoder = Instruction;

    int64_t imm = InstructionDecoder.immlo + ( InstructionDecoder.immhi << 2 );
    imm = SignExtend( imm, 21, 64 );
    return imm;
}
static inline int64_t ImmHiImmLoZero12Offset(uint32_t Instruction)
{
    int64_t imm = ImmHiImmLoOffset( Instruction );
    imm = imm << 12;
    return imm;
}
static inline int64_t Imm14Offset(uint32_t Instruction)
{
    int64_t offset;
    {
        int64_t imm14 = GET_BITS( Instruction, 5, 18 );
        offset = ( imm14 << 2 );
    }
    offset = SignExtend( offset, 16, 64 );
    return offset;
}

static
BWSR_STATUS
    AssemblerCodeBuilder_FinalizeFromAssembler
    (
        IN          InterceptRouting*       Routing,
        IN          Assembler*              Assembler,
        IN          MemoryRange*            MemRange
    )
{
    BWSR_STATUS     retVal      = ERROR_FAILURE;
    MemoryRange*    block       = NULL;

    __NOT_NULL( Routing,
                Assembler,
                MemRange )

    if( Assembler->FixedAddress )
    {
        retVal = ERROR_SUCCESS;
    }
    else {
        if( ERROR_SUCCESS != ( retVal = MemoryAllocator_AllocateExecutionBlock( &block,
                                                                                &gMemoryAllocator,
                                                                                Assembler->Buffer.BufferSize ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "MemoryAllocator_AllocateExecutionBlock() Failed\n" );
        }
        else {
            Assembler->FixedMemoryRange = (uintptr_t)block;
            Assembler->FixedAddress     = block->Start;
        } // MemoryAllocator_AllocateExecutionBlock()
    } // fixed_addr

    if( ERROR_SUCCESS == retVal )
    {
        DEBUGL( LOG_LEVEL_NOTICE, "Patching hooked function call into function address...\n" );

        if( ERROR_SUCCESS != ( retVal = ApplyCodePatch( Routing,
                                                        (void*) Assembler->FixedAddress,
                                                        Assembler->Buffer.Buffer,
                                                        Assembler->Buffer.BufferSize ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "ApplyCodePatch() Failed\n" );
        }
        else {
            MemRange->Start = Assembler->FixedAddress;
            MemRange->Size  = Assembler->Buffer.BufferSize;
        } // ApplyCodePatch()
    }

    return retVal;
}

static
BWSR_STATUS
    WriteInstructionToBuffer_UnconditionalBranchFixed
    (
        IN          RelocationContext*      Context,
        IN  OUT     Assembler*              Assembler,
        IN          uint32_t                Instruction
    )
{
    BWSR_STATUS         retVal              = ERROR_FAILURE;
    uintptr_t           cursorOffset        = 0;
    RelocationData*     relocationData      = NULL;
    uint32_t            value               = 0;

    __NOT_NULL( Context, Assembler )
    __GREATER_THAN_0( Instruction )

    cursorOffset = GetContextCursor( Context ) + Imm26Offset( Instruction );

    if( ERROR_SUCCESS != ( retVal = Assembler_CreateRelocationData( &relocationData,
                                                                    Assembler,
                                                                    cursorOffset ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "Assembler_CreateRelocationData() Failed\n" );
    }
    else {
        if( ERROR_SUCCESS != ( retVal = Assembler_WriteInstruction_LDR( &Assembler->Buffer,
                                                                        (Register*) &TMP_REG_0,
                                                                        relocationData ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "Assembler_WriteInstruction_LDR() Failed\n" );
        }
        else {
            if( BL == ( Instruction & UnconditionalBranchMask ) )
            {
                value = ( BLR | ( ARM64_TMP_REG_NDX_0 << kRnShift ) );
            }
            else {
                value = ( BR  | ( ARM64_TMP_REG_NDX_0 << kRnShift ) );
            } // BLR or BL

            retVal = Assembler_Write32BitInstruction( &Assembler->Buffer, value );
        } // Assembler_WriteInstruction_LDR()
    } // Assembler_CreateRelocationData()

    // if( relocationData->ReferenceInstructions )
    // {
    //     BwsrFree( relocationData->ReferenceInstructions );
    // }

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
BWSR_STATUS
    WriteInstructionToBuffer_LiteralLoadRegisterFixed
    (
        IN          RelocationContext*      Context,
        IN  OUT     Assembler*              Assembler,
        IN          uint32_t                Instruction
    )
{
    BWSR_STATUS     retVal          = ERROR_FAILURE;
    uintptr_t       cursorOffset    = 0;
    char            opc             = 0;
    int             rt              = 0;

    __NOT_NULL( Context, Assembler )
    __GREATER_THAN_0( Instruction )

    cursorOffset = GetContextCursor( Context ) + Imm19Offset( Instruction );
    rt  = GET_BITS( Instruction, 0,  4  );
    opc = GET_BITS( Instruction, 30, 31 );

    if( ERROR_SUCCESS != ( retVal = Assembler_MOV( &Assembler->Buffer,
                                                   (Register*) &TMP_REG_0,
                                                   cursorOffset ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "Assembler_MOV() Failed\n" );
    }
    else {
        if( 0b00 == opc )
        {
            retVal = Assembler_LoadStore( &Assembler->Buffer,
                                          LDR_x,
                                          &W( rt ),
                                          &MEMOP_ADDR( AddrModeOffset ) );
        }
        else if( 0b01 == opc )
        {
            retVal = Assembler_LoadStore( &Assembler->Buffer,
                                          LDR_x,
                                          &X( rt ),
                                          &MEMOP_ADDR( AddrModeOffset ) );
        }
        else {
            DEBUGL( LOG_LEVEL_WARNING,
                    "Unexpected opcode: %c\n",
                    opc );
            retVal = ERROR_UNIMPLEMENTED;
        } // opcode
    } // Assembler_MOV()

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
BWSR_STATUS
    WriteInstructionToBuffer_PCRelAddressingFixed_ADR
    (
        IN          RelocationContext*      Context,
        IN  OUT     Assembler*              Assembler,
        IN          uint32_t                Instruction
    )
{
    BWSR_STATUS     retVal          = ERROR_FAILURE;
    uintptr_t       cursorOffset    = 0;
    int             rd              = 0;

    __NOT_NULL( Context, Assembler )
    __GREATER_THAN_0( Instruction )

    rd  = GET_BITS( Instruction, 0, 4 );
    cursorOffset = GetContextCursor( Context ) + ImmHiImmLoOffset( Instruction );

    retVal = Assembler_MOV( &Assembler->Buffer,
                            &X( rd ),
                            cursorOffset );

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
BWSR_STATUS
    WriteInstructionToBuffer_PCRelAddressingFixed_ADRP
    (
        IN          RelocationContext*      Context,
        IN  OUT     Assembler*              Assembler,
        IN          uint32_t                Instruction
    )
{
    BWSR_STATUS     retVal          = ERROR_FAILURE;
    uintptr_t       cursorOffset    = 0;

    __NOT_NULL( Context, Assembler )
    __GREATER_THAN_0( Instruction )

    cursorOffset = GetContextCursor( Context ) + ImmHiImmLoZero12Offset( Instruction );
    cursorOffset = arm64_trunc_page( cursorOffset );

    retVal = Assembler_MOV( &Assembler->Buffer,
                            &X( GET_BITS( Instruction, 0, 4 ) ),
                            cursorOffset );

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
BWSR_STATUS
    WriteInstructionToBuffer_ConditionalBranchFixed
    (
        IN          RelocationContext*      Context,
        IN  OUT     Assembler*              Assembler,
        IN          uint32_t                Instruction
    )
{
    BWSR_STATUS         retVal              = ERROR_FAILURE;
    uintptr_t           cursorOffset        = 0;
    uint32_t            instruction         = 0;
    char                bitSetPos           = 0;
    RelocationData*     relocationData      = NULL;
    uint32_t            value               = 0;

    __NOT_NULL( Context, Assembler )
    __GREATER_THAN_0( Instruction )

    cursorOffset    = GetContextCursor( Context ) + Imm19Offset( Instruction );
    instruction     = Instruction;
    bitSetPos       = GET_BITS( Instruction, 0, 3 ) ^ 1;

    SET_BITS( instruction, 0, 3, bitSetPos );
    SET_BITS( instruction, 5, 23, 3 );

    if( ERROR_SUCCESS != ( retVal = Assembler_CreateRelocationData( &relocationData,
                                                                    Assembler,
                                                                    cursorOffset ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "Assembler_CreateRelocationData() Failed\n" );
    }
    else {
        if( ERROR_SUCCESS != ( retVal = Assembler_Write32BitInstruction( &Assembler->Buffer, instruction ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "Assembler_Write32BitInstruction() Failed\n" );
        }
        else {
            if( ERROR_SUCCESS != ( retVal = Assembler_WriteInstruction_LDR( &Assembler->Buffer,
                                                                            (Register*) &TMP_REG_0,
                                                                            relocationData ) ) )
            {
                DEBUGL( LOG_LEVEL_ERROR, "Assembler_WriteInstruction_LDR() Failed\n" );
            }
            else {
                value  = ( BR | ( ARM64_TMP_REG_NDX_0 << kRnShift ) );
                retVal = Assembler_Write32BitInstruction( &Assembler->Buffer, value );
            } // Assembler_WriteInstruction_LDR()
        } // Assembler_Write32BitInstruction()
    } // Assembler_CreateRelocationData()

    // if( relocationData->ReferenceInstructions )
    // {
    //     BwsrFree( relocationData->ReferenceInstructions );
    // }

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
BWSR_STATUS
    WriteInstructionToBuffer_CompareBranchFixed
    (
        IN          RelocationContext*      Context,
        IN  OUT     Assembler*              Assembler,
        IN          uint32_t                Instruction
    )
{
    BWSR_STATUS         retVal              = ERROR_FAILURE;
    uintptr_t           cursorOffset        = 0;
    uint32_t            instruction         = 0;
    char                op                  = 0;
    RelocationData*     relocationData      = NULL;
    uint32_t            value               = 0;

    __NOT_NULL( Context, Assembler )
    __GREATER_THAN_0( Instruction )

    cursorOffset    = GetContextCursor( Context ) + Imm19Offset( Instruction );
    instruction     = Instruction;
    op              = GET_BIT( Instruction, 24 ) ^ 1;

    SET_BIT( instruction, 24, op );
    SET_BITS( instruction, 5, 23, 3 );

    if( ERROR_SUCCESS != ( retVal = Assembler_CreateRelocationData( &relocationData,
                                                                    Assembler,
                                                                    cursorOffset ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "Assembler_CreateRelocationData() Failed\n" );
    }
    else {
        if( ERROR_SUCCESS != ( retVal = Assembler_Write32BitInstruction( &Assembler->Buffer, instruction ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "Assembler_Write32BitInstruction() Failed\n" );
        }
        else {
            if( ERROR_SUCCESS != ( retVal = Assembler_WriteInstruction_LDR( &Assembler->Buffer,
                                                                            (Register*) &TMP_REG_0,
                                                                            relocationData ) ) )
            {
                DEBUGL( LOG_LEVEL_ERROR, "Assembler_WriteInstruction_LDR() Failed\n" );
            }
            else {
                value  = ( BR | ( ARM64_TMP_REG_NDX_0 << kRnShift ) );
                retVal = Assembler_Write32BitInstruction( &Assembler->Buffer, value );
            } // Assembler_WriteInstruction_LDR()
        } // Assembler_Write32BitInstruction()
    } // Assembler_CreateRelocationData()

    // if( relocationData->ReferenceInstructions )
    // {
    //     BwsrFree( relocationData->ReferenceInstructions );
    // }

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
BWSR_STATUS
    WriteInstructionToBuffer_TestBranchFixed
    (
        IN          RelocationContext*      Context,
        IN  OUT     Assembler*              Assembler,
        IN          uint32_t                Instruction
    )
{
    BWSR_STATUS         retVal              = ERROR_FAILURE;
    uintptr_t           cursorOffset        = 0;
    uint32_t            instruction         = 0;
    char                op                  = 0;
    RelocationData*     relocationData      = NULL;
    uint32_t            value               = 0;

    __NOT_NULL( Context, Assembler );
    __GREATER_THAN_0( Instruction );

    cursorOffset    = GetContextCursor( Context ) + Imm14Offset( Instruction );
    instruction     = Instruction;
    op              = GET_BIT( Instruction, 24 ) ^ 1;

    SET_BIT( instruction, 24, op );
    SET_BITS( instruction, 5, 18, 3 );

    if( ERROR_SUCCESS != ( retVal = Assembler_CreateRelocationData( &relocationData,
                                                                    Assembler,
                                                                    cursorOffset ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "Assembler_CreateRelocationData() Failed\n" );
    }
    else {
        if( ERROR_SUCCESS != ( retVal = Assembler_Write32BitInstruction( &Assembler->Buffer, instruction ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "Assembler_Write32BitInstruction() Failed\n" );
        }
        else {
            if( ERROR_SUCCESS != ( retVal = Assembler_WriteInstruction_LDR( &Assembler->Buffer,
                                                                            (Register*) &TMP_REG_0,
                                                                            relocationData ) ) )
            {
                DEBUGL( LOG_LEVEL_ERROR, "Assembler_WriteInstruction_LDR() Failed\n" );
            }
            else {
                value  = ( BR | ( ARM64_TMP_REG_NDX_0 << kRnShift ) );
                retVal = Assembler_Write32BitInstruction( &Assembler->Buffer, value );
            } // Assembler_WriteInstruction_LDR()
        } // Assembler_Write32BitInstruction()
    } // Assembler_CreateRelocationData()

    // if( relocationData->ReferenceInstructions )
    // {
    //     BwsrFree( relocationData->ReferenceInstructions );
    // }

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
BWSR_STATUS
    RelocationContext_Relocate
    (
        IN          InterceptRouting*       Routing,
        IN  OUT     RelocationContext*      Context,
        IN          bool                    Branch
    )
{
    BWSR_STATUS     retVal          = ERROR_FAILURE;
    Assembler       assembler       = { 0 };
    uint32_t        instruction     = 0;

    __NOT_NULL( Context );

    retVal = Assembler_Initialize( &assembler, 0 );

    Context->RelocatedBuffer = (MemoryBuffer*) &assembler.Buffer;

    while( ( ( Context->Cursor - Context->BaseAddress->Start ) < Context->BaseAddress->Size ) &&
           ( ERROR_SUCCESS == retVal ) )
    {
        // record_relo_start();

        instruction = *(uint32_t *)GetContextCursor( Context );

        if( UnconditionalBranchFixed == ( instruction & UnconditionalBranchFixedMask ) )
        {
            retVal = WriteInstructionToBuffer_UnconditionalBranchFixed( Context,
                                                                        &assembler,
                                                                        instruction );
        }
        else if( LiteralLoadRegisterFixed == ( instruction & LiteralLoadRegisterFixedMask ) )
        {
            retVal = WriteInstructionToBuffer_LiteralLoadRegisterFixed( Context,
                                                                        &assembler,
                                                                        instruction );
        }
        else if( ( PCRelAddressingFixed == ( instruction & PCRelAddressingFixedMask ) ) &&
                 ( ADR                  == ( instruction & PCRelAddressingMask      ) ) )
        {
            retVal = WriteInstructionToBuffer_PCRelAddressingFixed_ADR( Context,
                                                                        &assembler,
                                                                        instruction );
        }
        else if( ( PCRelAddressingFixed == ( instruction & PCRelAddressingFixedMask ) ) &&
                 ( ADRP                 == ( instruction & PCRelAddressingMask      ) ) )
        {
            retVal = WriteInstructionToBuffer_PCRelAddressingFixed_ADRP( Context,
                                                                         &assembler,
                                                                         instruction );
        }
        else if( ConditionalBranchFixed == ( instruction & ConditionalBranchFixedMask ) )
        {
            retVal = WriteInstructionToBuffer_ConditionalBranchFixed( Context,
                                                                      &assembler,
                                                                      instruction );
        }
        else if( CompareBranchFixed == ( instruction & CompareBranchFixedMask ) )
        {
            retVal = WriteInstructionToBuffer_CompareBranchFixed( Context,
                                                                  &assembler,
                                                                  instruction );
        }
        else if( TestBranchFixed == ( instruction & TestBranchFixedMask ) )
        {
            retVal = WriteInstructionToBuffer_TestBranchFixed( Context,
                                                               &assembler,
                                                               instruction );
        }
        else {
            retVal = Assembler_Write32BitInstruction( &assembler.Buffer, instruction );
        }

        Context->Cursor += sizeof( uint32_t );
    } // while()

    if( ERROR_SUCCESS == retVal )
    {
        Context->BaseAddress->Size = ( Context->Cursor - Context->BaseAddress->Start );

        // TODO: if last instr is unlink branch, ignore it
        if( true == Branch )
        {
            retVal = Assembler_LiteralLdrBranch( &assembler, GetContextCursor( Context ) );
        }

        if( ERROR_SUCCESS == retVal )
        {
            if( ERROR_SUCCESS != ( retVal = Assembler_WriteRelocationDataToPageBuffer( &assembler ) ) )
            {
                DEBUGL( LOG_LEVEL_ERROR, "Assembler_WriteRelocationDataToPageBuffer() Failed\n" );
            }
            else {
                retVal = AssemblerCodeBuilder_FinalizeFromAssembler( Routing,
                                                                    &assembler,
                                                                    &Context->RelocatedBlock );
            } // Assembler_WriteRelocationDataToPageBuffer()
        } // Assembler_LiteralLdrBranch()
    } // Error check

    (void) Assembler_Release( &assembler );

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
BWSR_STATUS
    GenRelocateCodeAndBranch
    (
        IN          InterceptRouting*       Routing,
        IN          MemoryRange*            BaseAddress,
        IN  OUT     MemoryRange*            Relocated,
        IN          bool                    Branch
    )
{
    BWSR_STATUS         retVal      = ERROR_FAILURE;
    RelocationContext   context     = { 0 };

    context.BaseAddress = BaseAddress;
    context.Cursor      = BaseAddress->Start;

    retVal = RelocationContext_Relocate( Routing, &context, Branch );

    *Relocated = context.RelocatedBlock;

    return retVal;
}

static
BWSR_STATUS
    InterceptRouting_init
    (
        IN  OUT     InterceptRouting**          Routing,
        IN          InterceptorEntry*           Entry,
        IN          uintptr_t                   FakeFunction
    )
{
    BWSR_STATUS retVal = ERROR_FAILURE;

    if( NULL == ( *Routing = (InterceptRouting*) BwsrMalloc( sizeof( InterceptRouting ) ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "malloc() Failed\n" );
        retVal = ERROR_MEM_ALLOC;
    }
    else {
        ( *Routing )->InterceptEntry     = Entry;
        ( *Routing )->Trampoline         = NULL;
        ( *Routing )->HookFunction       = FakeFunction;

        retVal = ERROR_SUCCESS;
    } // BwsrMalloc()

    return retVal;
}

static
BWSR_STATUS
    Active
    (
        IN  OUT     InterceptRouting*           Routing
    )
{
    BWSR_STATUS     retVal              = ERROR_FAILURE;
    size_t          trampolineSize      = 0;
    uintptr_t       bufferStart         = 0;

    __NOT_NULL( Routing );

    trampolineSize  = Routing->Trampoline->Buffer.Size;
    bufferStart     = Routing->Trampoline->Buffer.Start;

    DEBUGL( LOG_LEVEL_NOTICE, "Patching Trampoline into Intercept Address...\n" );

    retVal = ApplyCodePatch( Routing,
                             (void*) Routing->InterceptEntry->Address,
                             (uint8_t*) bufferStart,
                             trampolineSize );

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
BWSR_STATUS
    GenerateRelocatedCode
    (
        IN          InterceptRouting*           Routing
    )
{
    BWSR_STATUS     retVal          = ERROR_FAILURE;
    size_t          trampoline_size = 0;
    uintptr_t       buffer_start    = 0;

    __NOT_NULL( Routing );

    trampoline_size = Routing->Trampoline->Buffer.Size;
    buffer_start    = Routing->Trampoline->Buffer.Start;

    if( buffer_start == 0 )
    {
        DEBUGL( LOG_LEVEL_ERROR, "Routing failed. Cannot continue\n" );
        retVal = ERROR_ROUTING_FAILURE;
    }
    else {
        Routing->InterceptEntry->Patched.Start      = Routing->InterceptEntry->Address;
        Routing->InterceptEntry->Patched.Size       = trampoline_size;
        Routing->InterceptEntry->Relocated.Start    = 0;
        Routing->InterceptEntry->Relocated.Size     = 0;

        retVal = GenRelocateCodeAndBranch( Routing,
                                           &Routing->InterceptEntry->Patched,
                                           &Routing->InterceptEntry->Relocated,
                                           true );

        if( ( ERROR_SUCCESS == retVal                                  ) &&
            ( 0             == Routing->InterceptEntry->Relocated.Size ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "Routing failed. Cannot continue\n" );
            retVal = ERROR_ROUTING_FAILURE;
        }
    }

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
BWSR_STATUS
    GenerateTrampoline
    (
        IN          InterceptRouting*           Routing
    )
{
    BWSR_STATUS     retVal      = ERROR_FAILURE;
    uintptr_t       from        = Routing->InterceptEntry->Address;
    uintptr_t       to          = Routing->HookFunction;

    __NOT_NULL( Routing );

    retVal = GenerateNormalTrampolineBuffer( &Routing->Trampoline,
                                             from,
                                             to );

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
BWSR_STATUS
    BuildRoutingAndActivateHook
    (
        IN          InterceptRouting*           Routing
    )
{
    BWSR_STATUS retVal = ERROR_FAILURE;

    __NOT_NULL( Routing );

    if( ERROR_SUCCESS != ( retVal = GenerateTrampoline( Routing ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "GenerateTrampoline() Failed\n" );
    }
    else {
        if( ERROR_SUCCESS != ( retVal = GenerateRelocatedCode( Routing ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "GenerateRelocatedCode() Failed\n" );
        }
        else {
            if( ERROR_SUCCESS != ( retVal = Interceptor_BackupOriginalCode( Routing->InterceptEntry ) ) )
            {
                DEBUGL( LOG_LEVEL_ERROR, "Interceptor_BackupOriginalCode() Failed\n" );
            }
            else {
                retVal = Active( Routing );
            } // Interceptor_BackupOriginalCode()
        } // GenerateRelocatedCode()
    } // GenerateTrampoline()

    __DEBUG_RETVAL( retVal );
    return retVal;
}


typedef struct InterceptorTracker {
    InterceptorEntry*           Entry;
    struct InterceptorTracker*  Next;
    struct InterceptorTracker*  Previous;
} InterceptorTracker;


static InterceptorTracker gInterceptorTracker =
{
    .Entry      = NULL,
    .Next       = &gInterceptorTracker,
    .Previous   = &gInterceptorTracker
};

static
BWSR_STATUS
    INTERNAL_InterceptorTracker_Initialize
    (
        IN  OUT     InterceptorTracker**        Tracker
    )
{
    BWSR_STATUS retVal = ERROR_FAILURE;

    __NOT_NULL( Tracker )

    if( NULL == ( *Tracker = (InterceptorTracker*) BwsrMalloc( sizeof( InterceptorTracker ) ) ) )
    {
        retVal = ERROR_MEM_ALLOC;
    }
    else {
        if( NULL == ( ( *Tracker )->Entry = (InterceptorEntry*) BwsrMalloc( sizeof( InterceptorEntry ) ) ) )
        {
            retVal = ERROR_MEM_ALLOC;
            free( *Tracker );
        }
        else {
            ( *Tracker )->Next                  = &gInterceptorTracker;
            ( *Tracker )->Previous              = gInterceptorTracker.Previous;
            gInterceptorTracker.Previous->Next  = *Tracker;
            gInterceptorTracker.Previous        = *Tracker;

            retVal = ERROR_SUCCESS;
        } // BwsrMalloc()
    } // BwsrMalloc()

    return retVal;
}

static
void
    INTERNAL_InterceptorTracker_Release
    (
        IN  OUT     InterceptorTracker*         Tracker
    )
{
    __NOT_NULL_RETURN_VOID( Tracker );

    if( NULL != Tracker->Entry )
    {
        if( NULL != Tracker->Entry->Routing )
        {
            if( NULL != Tracker->Entry->Routing->Trampoline )
            {
                if( Tracker->Entry->Routing->Trampoline->Buffer.Start )
                {
                    BwsrFree( (void*)Tracker->Entry->Routing->Trampoline->Buffer.Start );
                }

                BwsrFree( Tracker->Entry->Routing->Trampoline );
                Tracker->Entry->Routing->Trampoline = NULL;
            }

            BwsrFree( Tracker->Entry->Routing );
            Tracker->Entry->Routing = NULL;
        }

        if( NULL != Tracker->Entry->OriginalCode )
        {
            BwsrFree( Tracker->Entry->OriginalCode );
            Tracker->Entry->OriginalCode = NULL;
        }

        BwsrFree( Tracker->Entry );
    }

    Tracker->Previous->Next     = Tracker->Next;
    Tracker->Next->Previous     = Tracker->Previous;
    Tracker->Next               = NULL;
    Tracker->Previous           = NULL;

    BwsrFree( Tracker );
}

static
BWSR_STATUS
    InterceptRouting_Initialize
    (
        IN  OUT     InterceptorEntry**          Entry
    )
{
    BWSR_STATUS             retVal          = ERROR_FAILURE;
    InterceptorTracker*     tracker         = NULL;

    if( ERROR_SUCCESS != ( retVal = INTERNAL_InterceptorTracker_Initialize( &tracker ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "INTERNAL_InterceptorTracker_Initialize() Failed\n" );
    }
    else {
        *Entry = tracker->Entry;
    } // INTERNAL_InterceptorTracker_Initialize()

    return retVal;
}

BWSR_API
BWSR_STATUS
    BWSR_InlineHook
    (
        IN          void*           Address,
        IN          void*           FakeFunction,
        IN  OUT     void**          OriginalFunctionAddress,
        IN          uintptr_t       VMProtectAddress
    )
{
    BWSR_STATUS         retVal      = ERROR_FAILURE;
    InterceptorEntry*   entry       = NULL;
    InterceptRouting*   routing     = NULL;

    __NOT_NULL( Address, FakeFunction );

    if( ERROR_SUCCESS != ( retVal = InterceptRouting_Initialize( &entry ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "InterceptRouting_Initialize() Failed\n" );
    }
    else {
        entry->Address              = (uintptr_t) Address;
        entry->HookFunctionAddress  = (uintptr_t) FakeFunction;

        if( ERROR_SUCCESS != ( retVal = InterceptRouting_init( &routing,
                                                               entry,
                                                               (uintptr_t) FakeFunction ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "InterceptRouting_init() Failed\n" );
        }
        else {

            routing->VMProtect = (__typeof(vm_protect)*) VMProtectAddress;

#if __has_feature(ptrauth_calls)

            ptrauth_sign_unauthenticated( (void*) routing->VMProtect, ptrauth_key_asia, 0 );

#endif

            if( ERROR_SUCCESS != ( retVal = BuildRoutingAndActivateHook( routing ) ) )
            {
                DEBUGL( LOG_LEVEL_ERROR, "BuildRoutingAndActivateHook() Failed\n" );
            }
            else {
                entry->Routing = routing;

                if( NULL != OriginalFunctionAddress )
                {
                    *OriginalFunctionAddress = (void *)entry->Relocated.Start;
                }

                retVal = ERROR_SUCCESS;
            } // BuildRoutingAndActivateHook()
        } // InterceptRouting_init()
    } // InterceptRouting_Initialize()

    __DEBUG_RETVAL( retVal );
    return retVal;
}

BWSR_API
BWSR_STATUS
    BWSR_DestroyHook
    (
        IN          void*           Address
    )
{
    BWSR_STATUS             retVal      = ERROR_FAILURE;
    InterceptorTracker*     tracker     = gInterceptorTracker.Next;

    __NOT_NULL( Address )

    retVal = ERROR_NOT_FOUND;

    while( ( tracker != &gInterceptorTracker ) && ( ERROR_NOT_FOUND == retVal ) )
    {
        if( NULL != tracker->Entry )
        {
            if( tracker->Entry->Patched.Start == (uintptr_t)Address )
            {
                retVal = ApplyCodePatch( tracker->Entry->Routing,
                                         (void*) tracker->Entry->Patched.Start,
                                         tracker->Entry->OriginalCode,
                                         tracker->Entry->Patched.Size );

                INTERNAL_InterceptorTracker_Release( tracker );
            }
        }

        tracker = tracker->Next;
    } // while()

    if( gInterceptorTracker.Next == &gInterceptorTracker )
    {
        if( NULL != gMemoryAllocator.Allocators )
        {
            BwsrFree( gMemoryAllocator.Allocators );
            gMemoryAllocator.Allocators = NULL;
            gMemoryAllocator.AllocatorCount = 0;
        }
    }

    return retVal;
}
