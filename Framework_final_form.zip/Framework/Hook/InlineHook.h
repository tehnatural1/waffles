
#ifdef __cplusplus
extern "C" {
#endif

int BWSR_InlineHook(void *address, void *fake_func, void **out_origin_func, uintptr_t datShitBrah);

int BWSR_DestroyHook(void* Address);

#ifdef __cplusplus
}
#endif