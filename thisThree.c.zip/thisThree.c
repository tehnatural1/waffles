#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <mach/mach.h>
#include <mach/vm_page_size.h>
#include <stddef.h>
#include <unistd.h>
#include <sys/mman.h>
#include <limits.h>
#include "thisThree.h"

#if __has_feature(ptrauth_calls)
  #include <ptrauth.h>
#endif

#if __APPLE__
  #include <libkern/OSCacheControl.h>
#endif

typedef struct InterceptRouting InterceptRouting;
typedef struct CodeMemBuffer CodeMemBuffer;

#define IN
#define OUT

#define ALIGN ALIGN_FLOOR
#define ALIGN_FLOOR( ADDRESS, RANGE )   ( (uintptr_t) ADDRESS & ~( (uintptr_t) RANGE - 1 ) )
#define ALIGN_CEIL( ADDRESS, RANGE )    ( ( (uintptr_t) ADDRESS + (uintptr_t) RANGE - 1 ) & ~( (uintptr_t)RANGE - 1 ) )

#define arm64_trunc_page( x )           ( ( x ) & ( ~( 0x1000 - 1 ) ) )
#define LeftShift( a, b, c )            ( ( a & ( ( 1 << b ) - 1 ) ) << c )
#define submask( x )                    ( ( 1L << ( ( x ) + 1 ) ) - 1 )
#define bits( obj, st, fn )             ( ( ( obj ) >> ( st ) ) & submask( ( fn ) - ( st ) ) )
#define bit( obj, st )                  ( ( ( obj ) >> ( st ) ) & 1 )
#define set_bit( obj, st, bit )         obj = ( ( ( ~( 1 << st ) ) & obj ) | ( bit << st ) )
#define set_bits( obj, st, fn, bits )   obj = ( ( ( ~( submask( fn - st ) << st ) ) & obj ) | ( bits << st ) )

// #define SHIFT_BITS_LEFT( bits,  )

#define Rd( rd )  ( rd->reg_id << kRdShift  )
#define Rt( rt )  ( rt->reg_id << kRtShift  )
#define Rt2( rt ) ( rt->reg_id << kRt2Shift )
#define Rn( rn )  ( rn->reg_id << kRnShift  )
#define Rm( rm )  ( rm->reg_id << kRmShift  )

enum InstructionFields
{
    kRdShift    = 0,
    kRnShift    = 5,
    kRmShift    = 16,
    kRtShift    = 0,
    kRt2Shift   = 10,
};

static uintptr_t vm_protect_address = 0x1234567;

enum ref_label_type_t
{
    kLabelImm19
};

// Exception.
enum ExceptionOp
{
    ExceptionFixed                      = 0xD4000000,
    BRK                                 = ExceptionFixed | 0x00200000,
};

enum PCRelAddressingOp
{
    PCRelAddressingFixed                = 0x10000000,
    PCRelAddressingFixedMask            = 0x1F000000,
    PCRelAddressingMask                 = 0x9F000000,
    ADR                                 = PCRelAddressingFixed | 0x00000000,
    ADRP                                = PCRelAddressingFixed | 0x80000000,
};

// Unconditional branch.
enum UnconditionalBranchOp
{
    UnconditionalBranchFixed            = 0x14000000,
    UnconditionalBranchFixedMask        = 0x7C000000,
    UnconditionalBranchMask             = 0xFC000000,
    B                                   = UnconditionalBranchFixed | 0x00000000,
    BL                                  = UnconditionalBranchFixed | 0x80000000,
};

// Unconditional branch to register.
enum UnconditionalBranchToRegisterOp
{
    UnconditionalBranchToRegisterFixed  = 0xD6000000,
    BR                                  = UnconditionalBranchToRegisterFixed | 0x001F0000,
    BLR                                 = UnconditionalBranchToRegisterFixed | 0x003F0000,
};

typedef enum
{
    LoadStorePairOffsetFixed            = 0x29000000,
} LoadStorePairOffsetOp;
typedef enum
{
    LoadStorePairPostIndexFixed         = 0x28800000,
} LoadStorePairPostIndexOp;
typedef enum
{
    LoadStorePairPreIndexFixed          = 0x29800000,
} LoadStorePairPreIndexOp;

typedef enum
{
    AddSubImmediateFixed                = 0x11000000,
    ADD_w_imm                           = AddSubImmediateFixed | ( 0b00 << 31 ) | ( 0b00 << 30 ),
    SUB_w_imm                           = AddSubImmediateFixed | ( 0b00 << 31 ) | ( 0b01 << 30 ),
    ADD_x_imm                           = AddSubImmediateFixed | ( 0b01 << 31 ) | ( 0b00 << 30 ),
    SUB_x_imm                           = AddSubImmediateFixed | ( 0b01 << 31 ) | ( 0b01 << 30 ),
} AddSubImmediateOp;

typedef enum
{
    LiteralLoadRegisterFixed            = 0x18000000,
    LiteralLoadRegisterFixedMask        = 0x3B000000,
    LDR_w_literal                       = LiteralLoadRegisterFixed | ( 0b00 << 30 ) | ( 0 << 26 ),
    LDR_x_literal                       = LiteralLoadRegisterFixed | ( 0b01 << 30 ) | ( 0 << 26 ),
    LDR_s_literal                       = LiteralLoadRegisterFixed | ( 0b00 << 30 ) | ( 1 << 26 ),
    LDR_d_literal                       = LiteralLoadRegisterFixed | ( 0b01 << 30 ) | ( 1 << 26 ),
    LDR_q_literal                       = LiteralLoadRegisterFixed | ( 0b10 << 30 ) | ( 1 << 26 ),
} LoadRegLiteralOp;

// Load/store
typedef enum
{
    STR_x                               = ( 0b11 << 30 ) | ( 0b00 << 22 ),
    LDR_x                               = ( 0b11 << 30 ) | ( 0b01 << 22 ),
} LoadStoreOp;

typedef enum
{
    STP_x                               = ( 0b10 << 30 ) | ( 0b00 << 26 ) | ( 0b00 << 22 ),
    LDP_x                               = ( 0b10 << 30 ) | ( 0b00 << 26 ) | ( 0b01 << 22 ),
    STP_q                               = ( 0b10 << 30 ) | ( 0b01 << 26 ) | ( 0b00 << 22 ),
    LDP_q                               = ( 0b10 << 30 ) | ( 0b01 << 26 ) | ( 0b01 << 22 ),
} LoadStorePairOp;

typedef enum
{
    LoadStoreUnsignedOffsetFixed        = 0x39000000,
} LoadStoreUnsignedOffset;

// Move wide immediate.
typedef enum
{
    MoveWideImmediateFixed              = 0x12800000,
    MOVZ                                = 0x40000000,
    MOVK                                = 0x60000000,
} MoveWideImmediateOp;

// Logical (immediate and shifted register).
typedef enum
{
  // NOT = 0x00200000,
  // AND = 0x00000000,
  // BIC = AND | NOT,
  ORR = 0x20000000,
  // ORN = ORR | NOT,
  // EOR = 0x40000000,
  // EON = EOR | NOT,
  // ANDS = 0x60000000,
  // BICS = ANDS | NOT
} LogicalOp;

// Logical shifted register.
typedef enum
{
    LogicalShiftedFixed = 0x0A000000,
} LogicalShiftedOp;

// Compare and branch.
typedef enum
{
    CompareBranchFixed      = 0x34000000,
    CompareBranchFixedMask  = 0x7E000000,
} CompareBranchOp;

// Conditional branch.
typedef enum
{
    ConditionalBranchFixed      = 0x54000000,
    ConditionalBranchFixedMask  = 0xFE000000,
    ConditionalBranchMask       = 0xFF000010,
} ConditionalBranchOp;

// Test and branch.
typedef enum
{
    TestBranchFixed         = 0x36000000,
    TestBranchFixedMask     = 0x7E000000,
} TestBranchOp;

typedef enum
{
    NO_SHIFT    = -1,
    LSL         = 0x0,
    LSR         = 0x1,
    ASR         = 0x2,
    ROR         = 0x3,
    MSL         = 0x4
} Shift;

typedef enum
{
  NO_EXTEND = -1,
  UXTB = 0,
  UXTH = 1,
  UXTW = 2,
  UXTX = 3,
  SXTB = 4,
  SXTH = 5,
  SXTW = 6,
  SXTX = 7
} Extend;

typedef enum
{
  kNoAccess,

  kRead = 1,
  kWrite = 2,
  kExecute = 4,

  kReadWrite = kRead | kWrite,
  kReadExecute = kRead | kExecute,
  kReadWriteExecute = kRead | kWrite | kExecute,
} MemoryPermission;

typedef enum
{
    AddrModeOffset,
    AddrModePreIndex,
    AddrModePostIndex
} AddrMode;

typedef enum
{
  kRegister_32,
  kRegister_W = kRegister_32,
  kRegister_64,
  kRegister_X = kRegister_64,
  kRegister,

  kVRegister,
  kSIMD_FP_Register_8,
  kSIMD_FP_Register_B = kSIMD_FP_Register_8,
  kSIMD_FP_Register_16,
  kSIMD_FP_Register_H = kSIMD_FP_Register_16,
  kSIMD_FP_Register_32,
  kSIMD_FP_Register_S = kSIMD_FP_Register_32,
  kSIMD_FP_Register_64,
  kSIMD_FP_Register_D = kSIMD_FP_Register_64,
  kSIMD_FP_Register_128,
  kSIMD_FP_Register_Q = kSIMD_FP_Register_128,

  kInvalid
} RegisterType;

#define KERN_RETURN_ERROR(kr, failure)                   \
  do                                                     \
  {                                                      \
    if (kr != KERN_SUCCESS)                              \
    {                                                    \
      printf("mach error: %s\n", mach_error_string(kr)); \
      return failure;                                    \
    }                                                    \
  } while (0);

#define PUBLIC __attribute__((visibility("default")))

typedef uintptr_t addr_t;

typedef struct CodeMemBlock_s
{
  addr_t start_;
  size_t size;
} CodeMemBlock;

typedef struct Register_s
{
  int reg_id;
  int reg_size_;
  RegisterType reg_type_;
} CPURegister;

typedef CPURegister Register;

typedef struct Trampoline
{
//   int type;
  CodeMemBlock buffer;
  struct Trampoline* forward_trampoline;
} Trampoline;

typedef struct InterceptorEntry_s
{
    uint32_t id;
    addr_t fake_func_addr;

    addr_t addr;

    CodeMemBlock patched;
    CodeMemBlock relocated;

    InterceptRouting *routing;

    uint8_t *origin_code_;
} InterceptorEntry;

typedef struct ref_inst_t
{
    int link_type;
    size_t inst_offset;
} ref_inst_t;

typedef struct PseudoLabel
{
  CodeMemBuffer *code_buffer;
  size_t ref_insts_count;
  ref_inst_t* ref_insts;
  addr_t pc_offset;
} PseudoLabel;

typedef struct RelocDataLabel
{
  PseudoLabel label;
  uint8_t data_[8];
  uint8_t data_size_;
} RelocDataLabel;

typedef struct CodeMemBuffer {
    uint8_t *buffer;
    uint32_t buffer_size;
    uint32_t buffer_capacity;
} CodeMemBuffer;

typedef struct Operand
{
  int64_t immediate_;
  Register* reg_;

  Shift shift_;
  Extend extend_;
  int32_t shift_extend_imm_;
} Operand;

typedef struct MemOperand
{
  Register base_;
  Register reg_offset_;
  int64_t offset_;

  Shift shift_;
  Extend extend_;
  uint32_t shift_extend_imm_;

  AddrMode addrmode_;
} MemOperand;

typedef struct AssemblerBase
{
    addr_t fixed_addr;
    CodeMemBuffer code_buffer_;

    RelocDataLabel** data_labels;
    size_t data_labels_size;
    size_t data_labels_capacity;
} AssemblerBase;

struct
{
    uint32_t Rd : 5;      // Destination register
    uint32_t immhi : 19;  // 19-bit upper immediate
    uint32_t dummy_0 : 5; // Must be 10000 == 0x10
    uint32_t immlo : 2;   // 2-bit lower immediate
    uint32_t op : 1;      // 0 = ADR, 1 = ADRP
} instruction_decoder;

typedef struct relo_ctx_t
{
  addr_t cursor;
  uint32_t relocated_insn_count;

  CodeMemBlock* origin;
  CodeMemBlock relocated;
  CodeMemBuffer* relocated_buffer;
} relo_ctx_t;

typedef struct simple_linear_allocator_t {
    uint8_t *buffer;
    uint32_t size;
    uint32_t capacity;
    uint32_t builtin_alignment;
} simple_linear_allocator_t;

typedef struct MemoryAllocator {
    simple_linear_allocator_t *code_page_allocators;
    simple_linear_allocator_t *data_page_allocators;
    size_t code_page_allocators_count;
    size_t data_page_allocators_count;
} MemoryAllocator;

struct InterceptRouting
{
  InterceptorEntry* entry;
  Trampoline*       trampoline;
  Trampoline*       near_trampoline;
  int               error;
  addr_t            fake_func;
};

PUBLIC
int
    DobbyCodePatch
    (
        void *address,
        uint8_t *buffer,
        uint32_t buffer_size
    )
{
    if( ( NULL == address     ) ||
        ( NULL == buffer      ) ||
        ( 0    == buffer_size ) )
    {
        return -1;
    }

    size_t page_size = vm_page_size;
    addr_t patch_page = ALIGN_FLOOR( address, page_size );
    addr_t remap_dest_page = patch_page;
    kern_return_t kr;

    // cross over page
    if( (addr_t)address + buffer_size > patch_page + page_size )
    {
        void*    address_a      = address;
        uint8_t* buffer_a       = buffer;
        uint32_t buffer_size_a  = ( patch_page + page_size - (addr_t)address );
        int ret = DobbyCodePatch( address_a, buffer_a, buffer_size_a );
        if (ret == -1)
        {
            return ret;
        }

        void *address_b = (void *)((addr_t)address + buffer_size_a);
        uint8_t *buffer_b = buffer + buffer_size_a;
        uint32_t buffer_size_b = buffer_size - buffer_size_a;
        ret = DobbyCodePatch(address_b, buffer_b, buffer_size_b);
        return ret;
    }

    static __typeof(vm_protect) *vm_protect_fn = NULL;
    if (vm_protect_fn == NULL)
    {
        vm_protect_fn = (__typeof(vm_protect) *)vm_protect_address;
        if (vm_protect_fn == NULL)
        {
            vm_protect_fn = (__typeof(vm_protect) *)vm_protect_address;
        }
#if __has_feature(ptrauth_calls)
#include <ptrauth.h>
        ptrauth_sign_unauthenticated((void *)vm_protect_fn, ptrauth_key_asia, 0);
#endif
    }

    kr = vm_protect_fn( mach_task_self(),
                        remap_dest_page,
                        page_size,
                        false,
                        (VM_PROT_READ | VM_PROT_WRITE | VM_PROT_COPY));

    KERN_RETURN_ERROR(kr, -1);

    memcpy( (void *)(patch_page + ((uint64_t)address - remap_dest_page)),
            buffer,
            buffer_size);

    kr = vm_protect_fn( mach_task_self(),
                        remap_dest_page,
                        page_size,
                        false,
                        VM_PROT_READ | VM_PROT_EXECUTE );

    KERN_RETURN_ERROR( kr, -1 );

    return 0;
}

void
    Interceptor_Entry_backup_orig_code
    (
        InterceptorEntry* entry
    )
{
    uint8_t* orig = (uint8_t*)entry->addr;
    uint32_t tramp_size = entry->patched.size;
    entry->origin_code_ = ( uint8_t* )malloc( tramp_size );
    memcpy( entry->origin_code_, orig, tramp_size );
}

void
    PseudoLabel_link_to
    (
        PseudoLabel* label,
        int link_type,
        size_t pc_offset
    )
{
    label->ref_insts_count++;

    if( NULL == label->ref_insts )
    {
        label->ref_insts = (ref_inst_t*)malloc( sizeof(ref_inst_t ) );
    }
    else {
        label->ref_insts = (ref_inst_t*)realloc(label->ref_insts, label->ref_insts_count * sizeof(ref_inst_t));
    }

    if( NULL == label->ref_insts )
    {
        // Handle memory allocation failure
        return;
    }

    label->ref_insts[ label->ref_insts_count - 1 ].link_type    = link_type;
    label->ref_insts[ label->ref_insts_count - 1 ].inst_offset  = pc_offset;
}

void
    CodeMemBuffer_emit
    (
        CodeMemBuffer *code_buffer,
        uint8_t *in_buffer,
        int size
    )
{
    // Ensure capacity
    if (code_buffer->buffer_size + size > code_buffer->buffer_capacity)
    {
        uint32_t new_capacity = code_buffer->buffer_capacity * 2;
        while (new_capacity < code_buffer->buffer_size + size)
        {
            new_capacity *= 2;
        }

        code_buffer->buffer = (uint8_t*)realloc( code_buffer->buffer, new_capacity );

        if (code_buffer->buffer == NULL)
        {
            // Handle memory allocation failure
            return;
        }
        // code_buffer->buffer = new_buffer;
        code_buffer->buffer_capacity = new_capacity;
    }
    // Copy the input buffer into the code buffer
    memcpy(code_buffer->buffer + code_buffer->buffer_size, in_buffer, size);
    code_buffer->buffer_size += size;
}

static inline uint32_t encode_imm19_offset(uint32_t instr, int64_t offset)
{
  uint32_t imm19 = bits((offset >> 2), 0, 18);
  set_bits(instr, 5, 23, imm19);
  return instr;
}

void
  PseudoLabel_link_confused_instructions
  (
    PseudoLabel* label,
    CodeMemBuffer* buffer
  )
{
  printf( "CAW CAW MOTHERFUCKER\n" );
  for( size_t i = 0; i < label->ref_insts_count; ++i )
  {
    int64_t fixup_offset = label->pc_offset - label->ref_insts[i].inst_offset;

    uint32_t inst = *(int32_t*)( buffer->buffer + label->ref_insts[i].inst_offset );
    uint32_t new_inst = 0;

    if (label->ref_insts[i].link_type == 0) {
        new_inst = encode_imm19_offset(inst, fixup_offset);
    }

    *(int32_t*)( buffer->buffer + label->ref_insts[i].inst_offset ) = new_inst;
  }
}

Register InvalidRegister = { 0, 0, kInvalid };

void
    Assembler_Initialize
    (
        AssemblerBase*  assembler,
        addr_t          fixed_address
    )
{
    assembler->fixed_addr                   = fixed_address;
    assembler->code_buffer_.buffer          = (uint8_t *)malloc( 64 );
    assembler->code_buffer_.buffer_size     = 0;
    assembler->code_buffer_.buffer_capacity = 64;
    assembler->data_labels                  = NULL;
    assembler->data_labels_size             = 0;
    assembler->data_labels_capacity         = 0;
}

RelocDataLabel*
    AssemblerBase_createDataLabel
    (
        AssemblerBase *assembler,
        uint64_t data
    )
{
    RelocDataLabel *data_label = (RelocDataLabel *)malloc(sizeof(RelocDataLabel));
    if( data_label == NULL )
    {
        return NULL;
    }

    memcpy( data_label->data_, &data, sizeof( uint64_t ) );

    if( assembler->data_labels_size >= assembler->data_labels_capacity )
    {
        printf( "assembler->data_labels_capacity: %zu\n", assembler->data_labels_capacity );

        size_t new_capacity = ( ( assembler->data_labels_capacity == 0 ) ? 1 : ( assembler->data_labels_capacity * 2 ) );
        RelocDataLabel** new_data_labels = NULL;
        if( NULL == assembler->data_labels )
        {
            new_data_labels = (RelocDataLabel **)malloc( new_capacity * sizeof(RelocDataLabel *) );
        }
        else {
            new_data_labels = (RelocDataLabel **)realloc(assembler->data_labels, new_capacity * sizeof(RelocDataLabel *));
        }
        if (new_data_labels == NULL) {
            free(data_label);
            return NULL;
        }
        assembler->data_labels = new_data_labels;
        assembler->data_labels_capacity = new_capacity;
    }

    data_label->data_size_ = (uint8_t)sizeof( uint64_t );
    data_label->label.ref_insts_count = 0;
    data_label->label.pc_offset = 0;
    data_label->label.ref_insts = NULL;

    assembler->data_labels[ assembler->data_labels_size++ ] = data_label;
    return data_label;
}

void
    AssemblerBase_bindLabel
    (
        AssemblerBase *assembler,
        PseudoLabel *label
    )
{
    label->pc_offset = assembler->code_buffer_.buffer_size;
    if( 0 != label->ref_insts_count )
    {
      PseudoLabel_link_confused_instructions( label, &assembler->code_buffer_ );
    }
}

void
    AssemblerBase_relocDataLabels
    (
        AssemblerBase *assembler
    )
{
    printf( "AssemblerBase_relocDataLabels() enter\n" );
    for( size_t i = 0; i < assembler->data_labels_size; i++ )
    {
        RelocDataLabel *data_label = assembler->data_labels[i];
        AssemblerBase_bindLabel( assembler, &data_label->label );
        CodeMemBuffer_emit( &assembler->code_buffer_, data_label->data_, data_label->data_size_ );
    }
}

// LoadStore
static
int32_t
    OpEncode_LoadStorePair
    (
        IN          LoadStorePairOp         Op,
        IN          CPURegister*            RegisterRt,
        IN          const MemOperand*       addr
    )
{
    int         imm7        = 0;
    int32_t     scale       = 2;
    int32_t     opc         = bits( Op, 30, 31 );

    if( kRegister > RegisterRt->reg_type_ )
    {
      scale += bit( opc, 1 );
    }
    else if( kVRegister < RegisterRt->reg_type_ )
    {
      scale += opc;
    }

    imm7 = (int)( addr->offset_ >> scale );

    return LeftShift( imm7, 7, 15 );
}

// register operation size, 32 bits or 64 bits
static
int32_t
    OpEncode_sf
    (
        IN          const Register*         Reg
    )
{
    int32_t retVal = 0;

    if( 64 == Reg->reg_size_ )
    {
        retVal = INT32_MIN;
    }

    return retVal;
}

// LogicalShift
static
int32_t
    OpEncode_LogicalShift
    (
        IN          const Register*         RegisterRd,
        IN          const Register*         RegisterRn,
        IN          const Operand*          Operand
    )
{
    return( OpEncode_sf( RegisterRd )
            | LeftShift( Operand->shift_, 2, 22 )
            | Rm( Operand->reg_ )
            | LeftShift( Operand->shift_extend_imm_, 6, 10 )
            | Rn( RegisterRn )
            | Rd( RegisterRd ) );
}

// LogicalImmeidate
static
int32_t
    OpEncode_LogicalImmediate
    (
        IN          const Register*         RegisterRd,
        IN          const Register*         RegisterRn,
        IN          const Operand*          Operand
    )
{
    int64_t imm     = Operand->immediate_;
    int32_t immr    = bits( imm, 0, 5  );
    int32_t imms    = bits( imm, 6, 11 );

    return( OpEncode_sf( RegisterRd )
            | LeftShift( immr, 6, 16 )
            | LeftShift( imms, 6, 10 )
            | Rd( RegisterRd )
            | Rn( RegisterRn ) );
}

static inline uint16_t Low16Bits( uint32_t value )
{
  return (uint16_t)( value & 0xffff );
}

static inline uint16_t High16Bits( uint32_t value )
{
  return (uint16_t)( value >> 16 );
}

static inline uint32_t Low32Bits( uint64_t value )
{
  return (uint32_t)( value );
}

static inline uint32_t High32Bits( uint64_t value )
{
  return (uint32_t)( value >> 32 );
}

#define W( code ) (CPURegister) { code, 32, kRegister_32 }
#define X( code ) (CPURegister) { code, 64, kRegister_64 }
#define ARM64_TMP_REG_NDX_0 17

static const Register   TMP_REG_0   = X( ARM64_TMP_REG_NDX_0 );
static const Register   SP          = (Register) { 31, 64, kRegister_64 };
static const Register   xzr         = (Register) { 31, 64, kRegister_64 };
static const Register   wzr         = (Register) { 31, 32, kRegister_32 };


static
void
    AssemblerBase_Emit
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          uint32_t                Value
    )
{
    CodeMemBuffer_emit( CodeBuffer,
                        (uint8_t*) &Value,
                        sizeof( uint32_t ) );
}

static
void
    AssemblerBase_LogicalShift
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          const Register*         RegisterRd,
        IN          const Register*         RegisterRn,
        IN          const Operand*          Operand,
        IN          LogicalOp               Op
    )
{
    int32_t combinedOp = OpEncode_LogicalShift( RegisterRd,
                                                RegisterRn,
                                                Operand );

    AssemblerBase_Emit( CodeBuffer, Op | LogicalShiftedFixed | combinedOp );
}

static
void
    AssemblerBase_LogicalImmediate
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          const Register*         RegisterRd,
        IN          const Register*         RegisterRn,
        IN          const Operand*          Operand,
        IN          LogicalOp               Op
    )
{
    int32_t combinedOp = OpEncode_LogicalImmediate( RegisterRd,
                                                    RegisterRn,
                                                    Operand );

    AssemblerBase_Emit( CodeBuffer, Op | combinedOp );
}

static
void
    AssemblerBase_Logical
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          const Register*         RegisterRd,
        IN          const Register*         RegisterRn,
        IN          const Operand*          Operand,
        IN          LogicalOp               Op
    )
{
    if( 0 == Operand->reg_->reg_id )
    {
        AssemblerBase_LogicalImmediate( CodeBuffer,
                                        RegisterRd,
                                        RegisterRn,
                                        Operand,
                                        Op );
    }
    else {
        AssemblerBase_LogicalShift( CodeBuffer,
                                    RegisterRd,
                                    RegisterRn,
                                    Operand,
                                    Op );
    }
}

static
void
    AssemblerBase_AddSubImmediate
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          const Register*         RegisterRd,
        IN          const Register*         RegisterRn,
        IN          const Operand*          Operand,
        IN          AddSubImmediateOp       Op
    )
{
    if( 0 == Operand->reg_->reg_id )
    {
        int32_t imm12 = LeftShift( Operand->immediate_, 12, 10 );

        AssemblerBase_Emit( CodeBuffer, Op
                                        | Rd( RegisterRd )
                                        | Rn( RegisterRn )
                                        | imm12 );
    }
}

static
void
    AssemblerBase_MoveWide
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          Register*               RegisterRd,
        IN          uint64_t                Immediate,
        IN          int                     Shift,
        IN          MoveWideImmediateOp     Op
    )
{
    if( 0 < Shift )
    {
        Shift /= 16;
    }
    else {
        Shift = 0;
    }

    int32_t imm16 = LeftShift ( Immediate,
                                16,
                                5 );

    AssemblerBase_Emit( CodeBuffer, MoveWideImmediateFixed
                                    | Op
                                    | OpEncode_sf( RegisterRd )
                                    | LeftShift( Shift, 2, 21 )
                                    | imm16
                                    | Rd( RegisterRd ) );
}

static
void
    AssemblerBase_LoadStorePair
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          LoadStorePairOp         Op,
        IN          const Register*         RegisterRt,
        IN          const Register*         RegisterRt2,
        IN          const MemOperand*       Addr
    )
{
    int32_t combinedOp  = ( OpEncode_LoadStorePair( Op, RegisterRt, Addr )
                            | Rt2( RegisterRt2 )
                            | ( Addr->base_.reg_id << kRnShift )
                            | Rt( RegisterRt ) );
    int32_t addrModeOp  = LoadStorePairPostIndexFixed;

    if( AddrModeOffset == Addr->addrmode_ )
    {
        addrModeOp = LoadStorePairOffsetFixed;
    }
    else if( AddrModePreIndex == Addr->addrmode_ )
    {
        addrModeOp = LoadStorePairPreIndexFixed;
    }

    AssemblerBase_Emit( CodeBuffer, Op
                                    | addrModeOp
                                    | combinedOp );
}

static
void
    AssemblerBase_LoadStore
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          LoadStoreOp             Op,
        IN          const CPURegister*      RegisterRt,
        IN          const MemOperand*       addr
    )
{
    int64_t     imm12   = addr->offset_;
    int         scale   = 0;

    if( AddrModeOffset == addr->addrmode_ )
    {
        if( LoadStoreUnsignedOffsetFixed == ( Op & LoadStoreUnsignedOffsetFixed ) )
        {
            scale = bits( Op, 30, 31 );
        }

        imm12 = addr->offset_ >> scale;

        AssemblerBase_Emit( CodeBuffer, LoadStoreUnsignedOffsetFixed
                                        | Op
                                        | LeftShift( imm12, 12, 10 )
                                        | ( addr->base_.reg_id << kRnShift )
                                        | Rt( RegisterRt ) );
    }
}

static
void
    AssemblerBase_EmitLoadRegLiteral
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          LoadRegLiteralOp        Op,
        IN          CPURegister*            RegisterRt,
        IN          int64_t                 Immediate
    )
{
    const int32_t encoding  = ( Op
                                | LeftShift( Immediate >> 2, 26, 5 )
                                | Rt( RegisterRt ) );

    AssemblerBase_Emit( CodeBuffer, encoding);
}

#define OPERAND_IMMEDIATE( IMMEDIATE )  (Operand) { .immediate_         = IMMEDIATE,            \
                                                    .reg_               = &InvalidRegister,     \
                                                    .shift_             = NO_SHIFT,             \
                                                    .extend_            = NO_EXTEND,            \
                                                    .shift_extend_imm_  = 0 }
#define OPERAND_REGISTER( REGISTER )    (Operand) { .immediate_         = 0,                    \
                                                    .reg_               = (Register*)REGISTER,  \
                                                    .shift_             = LSL,                  \
                                                    .extend_            = NO_EXTEND,            \
                                                    .shift_extend_imm_  = 0 }

/**
 * The ADD instruction performs integer addition. It evaluates the result for both signed and unsigned integer operands and sets the OF and CF flags to indicate a carry (overflow) in the signed or unsigned result, respectively.
 */
void
    Assemble_add
    (
        CodeMemBuffer* code_buffer,
        const Register* rd,
        const Register* rn,
        int64_t Immediate
    )
{
    AddSubImmediateOp op = ADD_w_imm;

    if( rd->reg_size_ == 64 && rn->reg_size_ == 64 )
    {
        op = ADD_x_imm;
    }

    AssemblerBase_AddSubImmediate( code_buffer,
                                    rd,
                                    rn,
                                    &OPERAND_IMMEDIATE( Immediate ),
                                    op );
}


void Assemble_orr(CodeMemBuffer* code_buffer, const Register* rd, const Register* rn, const Operand* operand)
{
    AssemblerBase_Logical( code_buffer, rd, rn, operand, ORR );
}

void Assemble_movz(CodeMemBuffer* code_buffer, const Register* rd, uint64_t imm, int shift )
{
    AssemblerBase_MoveWide( code_buffer, (Register*)rd, imm, shift, MOVZ );
}

void Assemble_movk(CodeMemBuffer* code_buffer, const Register* rd, uint64_t imm, int shift )
{
    AssemblerBase_MoveWide( code_buffer, (Register*)rd, imm, shift, MOVK );
}

void Assemble_mov(CodeMemBuffer* code_buffer, const Register* rd, const Register* rn)
{
    printf( "I LIke the wayyyaaayy you movve dun dun a\n" );
    if( ( rd->reg_id == SP.reg_id ) || ( rn->reg_id == SP.reg_id ) )
    {
        Assemble_add(code_buffer, rd, rn, 0);
    }
    else
    {
        // Operand operand = OPERAND_REGISTER( rn );
        if( rd->reg_size_ == 64 )
        {
            Assemble_orr( code_buffer, rd, &xzr, &OPERAND_REGISTER( rn ) );
        }
        else {
            Assemble_orr( code_buffer, rd, &wzr, &OPERAND_REGISTER( rn ) );
        }
    }
}

void Assemble_stp(CodeMemBuffer* code_buffer, const Register* rt, const Register* rt2, const MemOperand* dst)
{
    if( rt->reg_type_ == kSIMD_FP_Register_128 )
    {
        AssemblerBase_LoadStorePair( code_buffer, STP_q, rt, rt2, dst );
    }
    else if( rt->reg_type_ == kRegister_X )
    {
        AssemblerBase_LoadStorePair( code_buffer, STP_x, rt, rt2, dst );
    }
    else {
        printf("THIS CODE SHOULD BE UNREACHABLE\n");
    }
}

void Assemble_ldp(CodeMemBuffer* code_buffer, const Register* rt, const Register* rt2, const MemOperand* src)
{
    if (rt->reg_type_ == kSIMD_FP_Register_128)
    {
        AssemblerBase_LoadStorePair( code_buffer, LDP_q, (CPURegister*)rt, (CPURegister*)rt2, src );
    }
    else if (rt->reg_type_ == kRegister_X)
    {
        AssemblerBase_LoadStorePair( code_buffer, LDP_x, (CPURegister*)rt, (CPURegister*)rt2, src );
    }
    else
    {
        printf("THIS CODE SHOULD BE UNREACHABLE\n");
    }
}

void Assemble_str(CodeMemBuffer* code_buffer, const CPURegister* rt, const MemOperand* src)
{
    AssemblerBase_LoadStore( code_buffer, STR_x, rt, src );
}

void Assemble_ldr(CodeMemBuffer* code_buffer, const CPURegister* rt, const MemOperand* src)
{
    AssemblerBase_LoadStore( code_buffer, LDR_x, rt, src );
}

void Assemble_ldr_imm(CodeMemBuffer* code_buffer, Register* rt, int64_t imm)
{
    LoadRegLiteralOp op = LiteralLoadRegisterFixed;
    switch ( rt->reg_type_ )
    {
        case kRegister_32:
        {
            op = LDR_w_literal;
            break;
        }

        case kRegister_X:
        {
            op = LDR_x_literal;
            break;
        }

        case kSIMD_FP_Register_S:
        {
            op = LDR_s_literal;
            break;
        }

        case kSIMD_FP_Register_D:
        {
            op = LDR_d_literal;
            break;
        }

        case kSIMD_FP_Register_Q:
        {
            op = LDR_q_literal;
            break;
        }

        default:
        {
            printf("THIS CODE SHOULD BE UNREACHABLE\n");
            break;
        }
    }
    // EmitLoadRegLiteral(op, rt, imm);
    AssemblerBase_EmitLoadRegLiteral( code_buffer, op, rt, imm );
}

void Assemble_blr(CodeMemBuffer* code_buffer, Register* rn)
{
    AssemblerBase_Emit( code_buffer, BLR | Rn(rn) );
}

void Assemble_br(CodeMemBuffer* code_buffer, Register* rn)
{
    AssemblerBase_Emit( code_buffer, BR | Rn(rn) );
}

void Assemble_b(CodeMemBuffer* code_buffer, int64_t imm)
{
    int32_t imm26 = bits( imm >> 2, 0, 25 );
    AssemblerBase_Emit( code_buffer, B | imm26 );
}

void Assemble_sub(CodeMemBuffer* code_buffer, const Register* rd, const Register* rn, int64_t imm)
{
    // Operand operand = { .immediate_ = imm, .reg_ = &InvalidRegister, .shift_ = NO_SHIFT, .extend_ = NO_EXTEND, .shift_extend_imm_ = 0 };
    if( rd->reg_size_ == 64 && rn->reg_size_ == 64 )
    {
        AssemblerBase_AddSubImmediate( code_buffer, rd, rn, &OPERAND_IMMEDIATE( imm ), SUB_x_imm );
    }
    else {
        AssemblerBase_AddSubImmediate( code_buffer, rd, rn, &OPERAND_IMMEDIATE( imm ), SUB_w_imm );
    }
}

/**
 * The ADRP instruction shifts a signed, 21-bit immediate left by 12 bits,
 * adds it to the value of the program counter with the bottom 12 bits
 * cleared to zero, and then writes the result to a general-purpose register
 */
void Assemble_adrp( CodeMemBuffer* code_buffer, const Register* rd, int64_t imm )
{
    uint32_t immlo = LeftShift( bits( imm >> 12, 0, 1  ), 2, 29 );
    uint32_t immhi = LeftShift( bits( imm >> 12, 2, 20 ), 19, 5 );
    AssemblerBase_Emit( code_buffer, ADRP | Rd(rd) | immlo | immhi );
}

void Assemble_brk(CodeMemBuffer* code_buffer, int code)
{
    AssemblerBase_Emit( code_buffer, BRK | LeftShift( code, 16, 5 ) );
}

void TurboAssemble_AdrpAdd(CodeMemBuffer* code_buffer, Register* rd, uint64_t from, uint64_t to)
{
    uint64_t from_PAGE  = ALIGN( from, 0x1000 );
    uint64_t to_PAGE    = ALIGN( to,   0x1000 );
    uint64_t to_PAGEOFF = (uint64_t)to % 0x1000;

    Assemble_adrp( code_buffer, rd, to_PAGE - from_PAGE );
    Assemble_add( code_buffer, rd, rd, to_PAGEOFF );
}

void TurboAssemble_Mov(CodeMemBuffer* code_buffer, Register* rd, uint64_t imm)
{
    const uint32_t w0 = Low32Bits(imm);
    const uint32_t w1 = High32Bits(imm);
    const uint16_t h0 = Low16Bits(w0);
    const uint16_t h1 = High16Bits(w0);
    const uint16_t h2 = Low16Bits(w1);
    const uint16_t h3 = High16Bits(w1);
    Assemble_movz( code_buffer, rd, h0, 0 );
    Assemble_movk( code_buffer, rd, h1, 16 );
    Assemble_movk( code_buffer, rd, h2, 32 );
    Assemble_movk( code_buffer, rd, h3, 48 );
}

void TurboAssemble_Ldr(CodeMemBuffer* code_buffer, Register* rt, PseudoLabel *label)
{
    PseudoLabel_link_to( label, kLabelImm19, code_buffer->buffer_size );
    Assemble_ldr_imm( code_buffer, rt, 0 );
}

// void TurboAssemble_CallFunction(CodeMemBuffer* code_buffer, ExternalReference function)
// {
//     // Mov( (Register*) &TMP_REG_0, (uint64_t)function.address);
//     TurboAssemble_Mov( code_buffer, (Register*) &TMP_REG_0, (uint64_t)function.address );
//     // blr( (Register*) &TMP_REG_0 );
//     Assemble_blr( code_buffer, (Register*) &TMP_REG_0 );
// }

void LiteralLdrBranch(AssemblerBase* assembler, uint64_t address)
{
    RelocDataLabel* label = AssemblerBase_createDataLabel( assembler, address );
    TurboAssemble_Ldr( &assembler->code_buffer_, (Register*) &TMP_REG_0, &label->label );
    Assemble_br( &assembler->code_buffer_, (Register*) &TMP_REG_0 );
}

typedef AssemblerBase TurboAssembler;

Trampoline *GenerateNormalTrampolineBuffer(addr_t from, addr_t to)
{
    TurboAssembler turbo_assembler_;
    Assembler_Initialize( &turbo_assembler_, from );

    // int tramp_type = 0;
    uint64_t distance = llabs( (int64_t) ( from - to ) );
    uint64_t adrp_range = UINT32_MAX - 1; // ((uint64_t)1 << (2 + 19 + 12 - 1));

    if( distance < adrp_range )
    {
        /**
         * ADRP ADD BR
         */

        // tramp_type = TRAMPOLINE_ARM64_ADRP_ADD_BR;
        TurboAssemble_AdrpAdd( &turbo_assembler_.code_buffer_, (Register*) &TMP_REG_0, from, to );
        Assemble_br( &turbo_assembler_.code_buffer_, (Register*) &TMP_REG_0 );
    }
    else
    {
        // tramp_type = TRAMPOLINE_ARM64_LDR_BR;
        LiteralLdrBranch( &turbo_assembler_, (uint64_t)to );
    }

    // bind all labels
    AssemblerBase_relocDataLabels( &turbo_assembler_ );

    CodeMemBuffer * tramp_buffer = &turbo_assembler_.code_buffer_; // code_buffer();

    // uint8_t *copy_buf = (uint8_t *)operator new( tramp_buffer->buffer_size );
    uint8_t *copy_buf = (uint8_t *)malloc( tramp_buffer->buffer_size );
    memcpy(copy_buf, tramp_buffer->buffer, tramp_buffer->buffer_size);

    Trampoline* tramp = (Trampoline*)malloc( sizeof( Trampoline ) );
    // tramp->type = tramp_type;
    tramp->buffer.start_ = (addr_t)copy_buf;
    tramp->buffer.size = tramp_buffer->buffer_size;
    return tramp;
}

addr_t
    relo_ctx_cursor
    (
        // relo_ctx_t* context
        CodeMemBlock* memblock,
        addr_t cursor
    )
{
    // return context
    return (addr_t)( memblock->start_ + ( cursor - memblock->start_ ) );
}

static inline bool inst_is_b_bl(uint32_t instr)
{
  return (instr & UnconditionalBranchFixedMask) == UnconditionalBranchFixed;
}
static inline bool inst_is_ldr_literal(uint32_t instr)
{
  return ((instr & LiteralLoadRegisterFixedMask) == LiteralLoadRegisterFixed);
}
static inline bool inst_is_adr(uint32_t instr)
{
  return (instr & PCRelAddressingFixedMask) == PCRelAddressingFixed && (instr & PCRelAddressingMask) == ADR;
}
static inline bool inst_is_adrp(uint32_t instr)
{
  return (instr & PCRelAddressingFixedMask) == PCRelAddressingFixed && (instr & PCRelAddressingMask) == ADRP;
}
static inline bool inst_is_b_cond(uint32_t instr)
{
  return (instr & ConditionalBranchFixedMask) == ConditionalBranchFixed;
}
static inline bool inst_is_compare_b(uint32_t instr)
{
  return (instr & CompareBranchFixedMask) == CompareBranchFixed;
}
static inline bool inst_is_test_b(uint32_t instr)
{
  return (instr & TestBranchFixedMask) == TestBranchFixed;
}

static inline int64_t SignExtend(unsigned long x, int M, int N)
{
  char sign_bit = bit(x, M - 1);
  unsigned long sign_mask = 0 - sign_bit;
  x |= ((sign_mask >> M) << M);
  return (int64_t)x;
}

static inline int decode_rt(uint32_t instr)
{
  return bits(instr, 0, 4);
}
static inline int decode_rd(uint32_t instr)
{
  return bits(instr, 0, 4);
}

static inline int64_t decode_imm26_offset(uint32_t instr)
{
  int64_t offset;
  {
    int64_t imm26 = bits(instr, 0, 25);
    offset = (imm26 << 2);
  }
  offset = SignExtend(offset, 2 + 26, 64);
  return offset;
}
static inline int64_t decode_imm19_offset(uint32_t instr)
{
  int64_t offset;
  {
    int64_t imm19 = bits( instr, 5, 23 );
    offset = (imm19 << 2);
  }
  offset = SignExtend(offset, 2 + 19, 64);
  return offset;
}
static inline int64_t decode_immhi_immlo_offset(uint32_t instr)
{
  *(uint32_t*) &instruction_decoder = instr;

  int64_t imm = instruction_decoder.immlo + ( instruction_decoder.immhi << 2 );
  imm = SignExtend( imm, 2 + 19, 64 );
  return imm;
}
static inline int64_t decode_immhi_immlo_zero12_offset(uint32_t instr)
{
  int64_t imm = decode_immhi_immlo_offset(instr);
  imm = imm << 12;
  return imm;
}
static inline int64_t decode_imm14_offset(uint32_t instr)
{
  int64_t offset;
  {
    int64_t imm14 = bits(instr, 5, 18);
    offset = (imm14 << 2);
  }
  offset = SignExtend(offset, 2 + 14, 64);
  return offset;
}

void
    simple_linear_allocator_t_init
    (
        simple_linear_allocator_t *allocator,
        uint8_t *in_buffer,
        uint32_t in_capacity,
        uint32_t in_alignment
    )
{
    allocator->buffer = in_buffer;
    allocator->capacity = in_capacity;
    allocator->builtin_alignment = in_alignment;
    allocator->size = 0;
}

uint8_t*
    simple_linear_allocator_t_alloc
    (
        simple_linear_allocator_t *allocator,
        uint32_t in_size,
        uint32_t in_alignment
    )
{
    uint32_t alignment = ( in_alignment != 0 ) ? in_alignment : allocator->builtin_alignment;
    uint32_t gap_size = ALIGN_CEIL((uintptr_t)( allocator->buffer + allocator->size ), alignment) - (uintptr_t)( allocator->buffer + allocator->size );
    allocator->size += gap_size;

    if (allocator->size + in_size > allocator->capacity)
    {
      return NULL;
    }

    uint8_t* data = (uint8_t*)(allocator->buffer + allocator->size);
    // DEBUG_LOG("alloc: %p - %p", data, in_size);

    allocator->size += in_size;
    return data;
}


const int kMmapFd = VM_MAKE_TAG(255);
const int kMmapFdOffset = 0;

static int GetProtectionFromMemoryPermission(MemoryPermission access)
{
  int prot = 0;
  if (access & kRead)
    prot |= PROT_READ;
  if (access & kWrite)
    prot |= PROT_WRITE;
  if (access & kExecute)
    prot |= PROT_EXEC;
  return prot;
}

static
int
    OSMemory_SetPermission
    (
        void *address,
        size_t size,
        MemoryPermission access
    )
{
    int prot = GetProtectionFromMemoryPermission(access);
    int ret = mprotect(address, size, prot);
    if (ret) {
        perror("OSMemory_SetPermission");
    }
    return ret == 0;
}

static
int
    OSMemory_PageSize
    (
        void
    )
{
    return (int)sysconf(_SC_PAGESIZE);
}

static
void*
    OSMemory_Allocate
    (
        size_t size,
        MemoryPermission access,
        void *fixed_address
    )
{
    int prot = GetProtectionFromMemoryPermission(access);
    int flags = MAP_PRIVATE | MAP_ANONYMOUS;
    if (fixed_address != NULL)
    {
        flags |= MAP_FIXED;
    }

    void *result = mmap(fixed_address, size, prot, flags, kMmapFd, kMmapFdOffset);
    if (result == MAP_FAILED)
        return NULL;
    return result;
}

CodeMemBlock*
    MemoryAllocator_allocExecBlock
    (
        MemoryAllocator *allocator,
        size_t size
    )
{
    if (size > OSMemory_PageSize()) {
        // ERROR_LOG("alloc size too large: %d", size);
        return NULL;
    }

    uint8_t *result = NULL;
    for (size_t i = 0; i < allocator->code_page_allocators_count; ++i) {
        printf( "doing iter on execblock\n" );
        result = simple_linear_allocator_t_alloc(&allocator->code_page_allocators[i], size, 0);
        if (result)
            break;
    }

    if( !result )
    {
        void *page = OSMemory_Allocate(OSMemory_PageSize(), kNoAccess, NULL);
        OSMemory_SetPermission( page, OSMemory_PageSize(), kReadExecute );
        allocator->code_page_allocators_count++;

        if( NULL == allocator->code_page_allocators )
        {
            allocator->code_page_allocators = (simple_linear_allocator_t*)malloc( sizeof( simple_linear_allocator_t ) );
        }
        else {
            allocator->code_page_allocators = (simple_linear_allocator_t*)realloc(allocator->code_page_allocators, allocator->code_page_allocators_count * sizeof(simple_linear_allocator_t));
        }
        simple_linear_allocator_t_init(&allocator->code_page_allocators[allocator->code_page_allocators_count - 1], (uint8_t *)page, OSMemory_PageSize(), 8);
        result = simple_linear_allocator_t_alloc(&allocator->code_page_allocators[allocator->code_page_allocators_count - 1], size, 0);
    }

    CodeMemBlock* retVal = (CodeMemBlock*)malloc( sizeof( CodeMemBlock ) );
    retVal->start_ = (addr_t)result;
    retVal->size = size;

    return retVal;
}

static MemoryAllocator gMemoryAllocator;

void
    AssemblerCodeBuilder_FinalizeFromTurboAssembler
    (
        AssemblerBase *assembler,
        CodeMemBlock* CodeBlock
    )
{
    CodeMemBuffer* code_buffer = &assembler->code_buffer_;
    addr_t fixed_addr = (addr_t)assembler->fixed_addr;

    if( !fixed_addr )
    {
        size_t buffer_size = 0;
        buffer_size = code_buffer->buffer_size;

        CodeMemBlock* block = (CodeMemBlock*)MemoryAllocator_allocExecBlock( &gMemoryAllocator, buffer_size );
        if (block->start_ == 0)
            return;

        fixed_addr = block->start_;
        assembler->fixed_addr = fixed_addr;
    }

    DobbyCodePatch((void *)fixed_addr, code_buffer->buffer, code_buffer->buffer_size);

    CodeBlock->start_ = fixed_addr;
    CodeBlock->size = code_buffer->buffer_size;
}

int
  relo_ctx_t_relocate
  (
    relo_ctx_t* ctx,
    bool branch
  )
{
    TurboAssembler turbo_assembler_;
    Assembler_Initialize( &turbo_assembler_, 0 );

    ctx->relocated_buffer = (CodeMemBuffer*) &turbo_assembler_.code_buffer_;

    int64_t offset = 0;

    while( ( ctx->cursor - ctx->origin->start_ ) < ctx->origin->size )
    {
        // record_relo_start();

        uint32_t inst = *(uint32_t *)relo_ctx_cursor( ctx->origin, ctx->cursor );

        if (inst_is_b_bl(inst))
        {
            offset = decode_imm26_offset(inst);
            addr_t dst = relo_ctx_cursor( ctx->origin, ctx->cursor ) + offset;
            RelocDataLabel* dst_data_label = AssemblerBase_createDataLabel( &turbo_assembler_, dst );
            // turbo_assembler_.Ldr( (Register*) &TMP_REG_0, &dst_data_label->label);
            TurboAssemble_Ldr( &turbo_assembler_.code_buffer_, (Register*) &TMP_REG_0, &dst_data_label->label );
            if ((inst & UnconditionalBranchMask) == BL)
            {
                Assemble_blr( &turbo_assembler_.code_buffer_, (Register*) &TMP_REG_0 );
            }
            else
            {
                Assemble_br( &turbo_assembler_.code_buffer_, (Register*) &TMP_REG_0 );
            }
        }
        else if (inst_is_ldr_literal(inst))
        {
            offset = decode_imm19_offset(inst);
            addr_t dst = relo_ctx_cursor( ctx->origin, ctx->cursor ) + offset;

            int rt = decode_rt(inst);
            char opc = bits(inst, 30, 31);

            TurboAssemble_Mov( &turbo_assembler_.code_buffer_, (Register*) &TMP_REG_0, dst );
            MemOperand memOperand = { .base_ = TMP_REG_0, .reg_offset_ = InvalidRegister, .offset_ = 0, .addrmode_ = AddrModeOffset, .shift_ = NO_SHIFT, .extend_ = NO_EXTEND, .shift_extend_imm_ = 0  };
            if (opc == 0b00)
            {
                const CPURegister temp = W( rt );
                Assemble_ldr( &turbo_assembler_.code_buffer_, &temp, &memOperand );
            }
            else if (opc == 0b01)
            {
                const CPURegister temp = X(rt);
                Assemble_ldr( &turbo_assembler_.code_buffer_, &temp, &memOperand );
            }
            else {
                printf("UNIMPLEMENTED\n");
            }
        }
        else if (inst_is_adr(inst))
        {
            offset = decode_immhi_immlo_offset(inst);
            addr_t dst = relo_ctx_cursor( ctx->origin, ctx->cursor ) + offset;

            int rd = decode_rd(inst);

            Register temp = X(rd);
            TurboAssemble_Mov( &turbo_assembler_.code_buffer_, &temp, dst );
        }
        else if (inst_is_adrp(inst))
        {
            offset = decode_immhi_immlo_zero12_offset(inst);
            addr_t dst = relo_ctx_cursor( ctx->origin, ctx->cursor ) + offset;
            dst = arm64_trunc_page(dst);

            int rd = decode_rd(inst);

            Register temp = X(rd);
            TurboAssemble_Mov( &turbo_assembler_.code_buffer_, &temp, dst );
        }
        else if (inst_is_b_cond(inst))
        {
            offset = decode_imm19_offset(inst);
            addr_t dst = relo_ctx_cursor( ctx->origin, ctx->cursor ) + offset;

            uint32_t branch_inst = inst;
            char cond = bits(inst, 0, 3);
            cond = cond ^ 1;
            set_bits(branch_inst, 0, 3, cond);

            offset = 4 * 3;
            uint32_t imm19 = offset >> 2;
            set_bits(branch_inst, 5, 23, imm19);
            RelocDataLabel* dst_data_label = AssemblerBase_createDataLabel( &turbo_assembler_, dst );

            AssemblerBase_Emit( &turbo_assembler_.code_buffer_, branch_inst );
            TurboAssemble_Ldr( &turbo_assembler_.code_buffer_, (Register*) &TMP_REG_0, &dst_data_label->label );
            Assemble_br( &turbo_assembler_.code_buffer_, (Register*) &TMP_REG_0 );
        }
        else if (inst_is_compare_b(inst))
        {
            offset = decode_imm19_offset(inst);
            addr_t dst = relo_ctx_cursor( ctx->origin, ctx->cursor ) + offset;

            uint32_t branch_inst = inst;
            char op = bit(inst, 24);
            op = op ^ 1;
            set_bit(branch_inst, 24, op);

            offset = 4 * 3;
            uint32_t imm19 = offset >> 2;
            set_bits(branch_inst, 5, 23, imm19);

            RelocDataLabel* dst_data_label = AssemblerBase_createDataLabel( &turbo_assembler_, dst );

            AssemblerBase_Emit( &turbo_assembler_.code_buffer_, branch_inst );
            TurboAssemble_Ldr( &turbo_assembler_.code_buffer_, (Register*) &TMP_REG_0, &dst_data_label->label );
            Assemble_br( &turbo_assembler_.code_buffer_, (Register*) &TMP_REG_0 );
        }
        else if (inst_is_test_b(inst))
        {
            offset = decode_imm14_offset(inst);
            addr_t dst = relo_ctx_cursor( ctx->origin, ctx->cursor ) + offset;

            uint32_t branch_inst = inst;
            char op = bit(inst, 24);
            op = op ^ 1;
            set_bit(branch_inst, 24, op);

            offset = 4 * 3;
            uint32_t imm14 = offset >> 2;
            set_bits(branch_inst, 5, 18, imm14);

            RelocDataLabel* dst_data_label = AssemblerBase_createDataLabel( &turbo_assembler_, dst );

            AssemblerBase_Emit( &turbo_assembler_.code_buffer_, branch_inst );
            TurboAssemble_Ldr( &turbo_assembler_.code_buffer_, (Register*) &TMP_REG_0, &dst_data_label->label );
            Assemble_br( &turbo_assembler_.code_buffer_, (Register*) &TMP_REG_0 );
        }
        else {
            AssemblerBase_Emit( &turbo_assembler_.code_buffer_, inst );
        }

        ctx->cursor += sizeof(uint32_t);
    }

    // correct_final_relo_size();
    ctx->origin->size = ( ctx->cursor - ctx->origin->start_ );

    // TODO: if last instr is unlink branch, ignore it
    if (branch)
    {
        LiteralLdrBranch( &turbo_assembler_, relo_ctx_cursor( ctx->origin, ctx->cursor ) );
    }

    AssemblerBase_relocDataLabels( &turbo_assembler_ );
    AssemblerCodeBuilder_FinalizeFromTurboAssembler( &turbo_assembler_, &ctx->relocated );

    return 0;
}

void GenRelocateCode(void *buffer, CodeMemBlock *origin, CodeMemBlock *relocated, bool branch)
{
    relo_ctx_t ctx;
    ctx.origin = origin;
    ctx.cursor = origin->start_;
    relo_ctx_t_relocate( &ctx, branch );
    *relocated = ctx.relocated;
}

void GenRelocateCodeAndBranch(void *buffer, CodeMemBlock *origin, CodeMemBlock *relocated)
{
  GenRelocateCode(buffer, origin, relocated, true);
}

void
    InterceptRouting_init
    (
        InterceptRouting*       routing,
        InterceptorEntry*       entry,
        addr_t                  fake_func
    )
{
    routing->entry              = entry;
    routing->trampoline         = NULL;
    routing->near_trampoline    = NULL;
    routing->error              = 0;
    routing->fake_func          = fake_func;
}

void
    Active
    (
        InterceptRouting*   routing
    )
{
    size_t trampoline_size  = 0;
    addr_t buffer_start     = 0;

    if( routing->near_trampoline )
    {
        trampoline_size = routing->near_trampoline->buffer.size;
        buffer_start    = routing->near_trampoline->buffer.start_;
    }
    else {
        trampoline_size = routing->trampoline->buffer.size;
        buffer_start    = routing->trampoline->buffer.start_;
    }

    int ret = DobbyCodePatch((void *)routing->entry->addr, (uint8_t *)buffer_start, trampoline_size);
    routing->error |= (ret != 0);
}

void
    GenerateRelocatedCode
    (
        InterceptRouting* routing
    )
{

    size_t trampoline_size = 0;
    addr_t buffer_start = 0;

    if( routing->near_trampoline )
    {
        trampoline_size = routing->near_trampoline->buffer.size;
        buffer_start = routing->near_trampoline->buffer.start_;
    }
    else {
        trampoline_size = routing->trampoline->buffer.size;
        buffer_start = routing->trampoline->buffer.start_;
    }

    if (buffer_start == 0)
    {
      routing->error = 1;
    }

    addr_t code_addr = routing->entry->addr;

    routing->entry->patched.start_      = code_addr;
    routing->entry->patched.size        = trampoline_size;
    routing->entry->relocated.start_    = 0;
    routing->entry->relocated.size      = 0;

    GenRelocateCodeAndBranch((void *)code_addr, &routing->entry->patched, &routing->entry->relocated);
    if( routing->entry->relocated.size == 0 )
    {
      routing->error = 1;
      return;
    }
}

void
    BackupOriginCode
    (
        InterceptRouting* routing
    )
{
    Interceptor_Entry_backup_orig_code( routing->entry );
}

bool
    GenerateTrampoline
    (
        InterceptRouting* routing
    )
{
    addr_t from = routing->entry->addr;
    addr_t to = routing->fake_func;

    if (!routing->near_trampoline)
    {
      routing->trampoline = GenerateNormalTrampolineBuffer(from, to);
    }
    return true;
}

void
  BuildRouting
  (
    InterceptRouting* routing
  )
{
    GenerateTrampoline( routing );
    GenerateRelocatedCode( routing );
    BackupOriginCode( routing );
}

PUBLIC int DoTheHook(void *address, void *fake_func, void **out_origin_func, uintptr_t VMProtectAddress)
{
    if (!address)
    {
        printf("address is 0x0\n");
        return -1;
    }

    vm_protect_address = VMProtectAddress;

    InterceptorEntry* entry = (InterceptorEntry*)malloc( sizeof( InterceptorEntry ) );
    entry->addr = (addr_t)address;
    entry->fake_func_addr = (addr_t)fake_func;

    InterceptRouting* routing = (InterceptRouting*)malloc( sizeof( InterceptRouting ) );
    InterceptRouting_init( routing, entry, (addr_t)fake_func );

    BuildRouting( routing );
    Active( routing );

    entry->routing = routing;

    if (routing->error)
    {
        printf("build routing error.\n");
        return -1;
    }

    if (out_origin_func)
    {
        *out_origin_func = (void *)entry->relocated.start_;
    }

    return 0;
}
