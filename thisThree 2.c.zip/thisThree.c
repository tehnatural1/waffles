#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <mach/mach.h>
#include <mach/vm_page_size.h>
#include <stddef.h>
#include <unistd.h>
#include <sys/mman.h>
#include <limits.h>
#include "thisThree.h"
#include "utility/utility.h"
#include "utility/error.h"

#if __has_feature( ptrauth_calls )
    #include <ptrauth.h>
#endif

#if __APPLE__
    #include <libkern/OSCacheControl.h>
#endif

typedef struct InterceptRouting InterceptRouting;
typedef struct CodeMemBuffer CodeMemBuffer;

#define ALIGN_FLOOR( ADDRESS, RANGE )   ( (uintptr_t) ADDRESS & ~( (uintptr_t) RANGE - 1 ) )
#define ALIGN_CEIL( ADDRESS, RANGE )    ( ( (uintptr_t) ADDRESS + (uintptr_t) RANGE - 1 ) & ~( (uintptr_t)RANGE - 1 ) )

#define arm64_trunc_page( x )           ( ( x ) & ( ~( 0x1000 - 1 ) ) )
#define LeftShift( a, b, c )            ( ( a & ( ( 1 << b ) - 1 ) ) << c )
#define submask( x )                    ( ( 1L << ( ( x ) + 1 ) ) - 1 )
#define bits( obj, st, fn )             ( ( ( obj ) >> ( st ) ) & submask( ( fn ) - ( st ) ) )
#define bit( obj, st )                  ( ( ( obj ) >> ( st ) ) & 1 )
#define set_bit( obj, st, bit )         obj = ( ( ( ~( 1 << st ) ) & obj ) | ( bit << st ) )
#define set_bits( obj, st, fn, bits )   obj = ( ( ( ~( submask( fn - st ) << st ) ) & obj ) | ( bits << st ) )

#define Rd( rd )  ( rd->RegisterId << kRdShift  )
#define Rt( rt )  ( rt->RegisterId << kRtShift  )
#define Rt2( rt ) ( rt->RegisterId << kRt2Shift )
#define Rn( rn )  ( rn->RegisterId << kRnShift  )
#define Rm( rm )  ( rm->RegisterId << kRmShift  )

#define OPERAND_IMMEDIATE( IMMEDIATE )  (Operand) { .Immediate              = IMMEDIATE,            \
                                                    .Register               = &InvalidRegister,     \
                                                    .Shift                  = NO_SHIFT,             \
                                                    .ShiftExtendImmediate   = 0 }
#define OPERAND_REGISTER( REGISTER )    (Operand) { .Immediate              = 0,                    \
                                                    .Register               = (Register*)REGISTER,  \
                                                    .Shift                  = LSL,                  \
                                                    .ShiftExtendImmediate   = 0 }
#define MEMOP_ADDR( ADDRESS_MODE )   (MemOperand) { .Base = TMP_REG_0,                              \
                                                    .Offset = 0,                                    \
                                                    .AddressMode = ADDRESS_MODE }

enum InstructionFields
{
    kRdShift    = 0,
    kRnShift    = 5,
    kRmShift    = 16,
    kRtShift    = 0,
    kRt2Shift   = 10,
};

static uintptr_t vm_protect_address = 0x1234567;

enum ref_label_type_t
{
    kLabelImm19
};

// Exception.
enum ExceptionOp
{
    ExceptionFixed                      = 0xD4000000,
    BRK                                 = ExceptionFixed | 0x00200000,
};

enum PCRelAddressingOp
{
    PCRelAddressingFixed                = 0x10000000,
    PCRelAddressingFixedMask            = 0x1F000000,
    PCRelAddressingMask                 = 0x9F000000,
    ADR                                 = PCRelAddressingFixed | 0x00000000,
    ADRP                                = PCRelAddressingFixed | 0x80000000,
};

// Unconditional branch.
enum UnconditionalBranchOp
{
    UnconditionalBranchFixed            = 0x14000000,
    UnconditionalBranchFixedMask        = 0x7C000000,
    UnconditionalBranchMask             = 0xFC000000,
    B                                   = UnconditionalBranchFixed | 0x00000000,
    BL                                  = UnconditionalBranchFixed | 0x80000000,
};

// Unconditional branch to register.
enum UnconditionalBranchToRegisterOp
{
    UnconditionalBranchToRegisterFixed  = 0xD6000000,
    BR                                  = UnconditionalBranchToRegisterFixed | 0x001F0000,
    BLR                                 = UnconditionalBranchToRegisterFixed | 0x003F0000,
};

typedef enum {
    LoadStorePairOffsetFixed            = 0x29000000,
    LoadStorePairPostIndexFixed         = 0x28800000,
    LoadStorePairPreIndexFixed          = 0x29800000,
} LoadStorePair;

typedef enum
{
    AddSubImmediateFixed                = 0x11000000,
    ADD_w_imm                           = AddSubImmediateFixed | ( 0b00 << 31 ) | ( 0b00 << 30 ),
    SUB_w_imm                           = AddSubImmediateFixed | ( 0b00 << 31 ) | ( 0b01 << 30 ),
    ADD_x_imm                           = AddSubImmediateFixed | ( 0b01 << 31 ) | ( 0b00 << 30 ),
    SUB_x_imm                           = AddSubImmediateFixed | ( 0b01 << 31 ) | ( 0b01 << 30 ),
} AddSubImmediateOp;

typedef enum
{
    LiteralLoadRegisterFixed            = 0x18000000,
    LiteralLoadRegisterFixedMask        = 0x3B000000,
    LDR_w_literal                       = LiteralLoadRegisterFixed | ( 0b00 << 30 ) | ( 0 << 26 ),
    LDR_x_literal                       = LiteralLoadRegisterFixed | ( 0b01 << 30 ) | ( 0 << 26 ),
    LDR_s_literal                       = LiteralLoadRegisterFixed | ( 0b00 << 30 ) | ( 1 << 26 ),
    LDR_d_literal                       = LiteralLoadRegisterFixed | ( 0b01 << 30 ) | ( 1 << 26 ),
    LDR_q_literal                       = LiteralLoadRegisterFixed | ( 0b10 << 30 ) | ( 1 << 26 ),
} LoadRegLiteralOp;

// Load/store
typedef enum
{
    STR_x                               = ( 0b11 << 30 ) | ( 0b00 << 22 ),
    LDR_x                               = ( 0b11 << 30 ) | ( 0b01 << 22 ),
} LoadStoreOp;

typedef enum
{
    STP_x                               = ( 0b10 << 30 ) | ( 0b00 << 26 ) | ( 0b00 << 22 ),
    LDP_x                               = ( 0b10 << 30 ) | ( 0b00 << 26 ) | ( 0b01 << 22 ),
    STP_q                               = ( 0b10 << 30 ) | ( 0b01 << 26 ) | ( 0b00 << 22 ),
    LDP_q                               = ( 0b10 << 30 ) | ( 0b01 << 26 ) | ( 0b01 << 22 ),
} LoadStorePairOp;

typedef enum
{
    LoadStoreUnsignedOffsetFixed        = 0x39000000,
} LoadStoreUnsignedOffset;

// Move wide immediate.
typedef enum
{
    MoveWideImmediateFixed              = 0x12800000,
    MOVZ                                = 0x40000000,
    MOVK                                = 0x60000000,
} MoveWideImmediateOp;

// Logical (immediate and shifted register).
typedef enum
{
    // NOT = 0x00200000,
    // AND = 0x00000000,
    // BIC = AND | NOT,
    ORR = 0x20000000,
    // ORN = ORR | NOT,
    // EOR = 0x40000000,
    // EON = EOR | NOT,
    // ANDS = 0x60000000,
    // BICS = ANDS | NOT
} LogicalOp;

// Logical shifted register.
typedef enum
{
    LogicalShiftedFixed = 0x0A000000,
} LogicalShiftedOp;

// Compare and branch.
typedef enum
{
    CompareBranchFixed      = 0x34000000,
    CompareBranchFixedMask  = 0x7E000000,
} CompareBranchOp;

// Conditional branch.
typedef enum
{
    ConditionalBranchFixed      = 0x54000000,
    ConditionalBranchFixedMask  = 0xFE000000,
    ConditionalBranchMask       = 0xFF000010,
} ConditionalBranchOp;

// Test and branch.
typedef enum
{
    TestBranchFixed         = 0x36000000,
    TestBranchFixedMask     = 0x7E000000,
} TestBranchOp;

typedef enum
{
    NO_SHIFT    = -1,
    LSL         = 0x0,
    LSR         = 0x1,
    ASR         = 0x2,
    ROR         = 0x3,
    MSL         = 0x4
} Shift;

typedef enum
{
    kNoAccess,

    kRead               = 1,
    kWrite              = 2,
    kExecute            = 4,

    kReadWrite          = kRead | kWrite,
    kReadExecute        = kRead | kExecute,
    kReadWriteExecute   = kRead | kWrite | kExecute,
} MemoryPermission;

typedef enum
{
    AddrModeOffset,
    AddrModePreIndex,
    AddrModePostIndex
} AddrMode;

typedef enum
{
    kRegister_32,
    kRegister_W = kRegister_32,
    kRegister_64,
    kRegister_X = kRegister_64,
    kRegister,

    kVRegister,
    kSIMD_FP_Register_8,
    kSIMD_FP_Register_B = kSIMD_FP_Register_8,
    kSIMD_FP_Register_16,
    kSIMD_FP_Register_H = kSIMD_FP_Register_16,
    kSIMD_FP_Register_32,
    kSIMD_FP_Register_S = kSIMD_FP_Register_32,
    kSIMD_FP_Register_64,
    kSIMD_FP_Register_D = kSIMD_FP_Register_64,
    kSIMD_FP_Register_128,
    kSIMD_FP_Register_Q = kSIMD_FP_Register_128,

    kInvalid
} RegisterType;

#define PUBLIC __attribute__((visibility("default")))


typedef struct CodeMemBlock {
    uintptr_t   Start;
    size_t      Size;
} CodeMemBlock;

typedef struct CodeMemBuffer {
    uint8_t*    Buffer;
    uint32_t    BufferSize;
    uint32_t    BufferCapacity;
} CodeMemBuffer;

typedef struct Register_s {
    int             RegisterId;
    int             RegisterSize;
    RegisterType    RegisterType;
} CPURegister;

typedef CPURegister Register;

typedef struct Trampoline {
    CodeMemBlock        Buffer;
} Trampoline;

typedef struct InterceptorEntry {
    uintptr_t           HookFunctionAddress;
    uintptr_t           Address;
    CodeMemBlock        Patched;
    CodeMemBlock        Relocated;
    InterceptRouting*   Routing;
    uint8_t*            OriginalCode;
} InterceptorEntry;

typedef struct ref_inst_t {
    int link_type;
    size_t inst_offset;
} ref_inst_t;

typedef struct PseudoLabel {
    size_t      ref_insts_count;
    ref_inst_t* ref_insts;
    uintptr_t   PcOffset;
} PseudoLabel;

typedef struct RelocDataLabel {
    PseudoLabel Label;
    uint8_t     Data[ 8 ];
    uint8_t     DataSize;
} RelocDataLabel;

typedef struct Operand {
    int64_t     Immediate;
    Register*   Register;
    Shift       Shift;
    int32_t     ShiftExtendImmediate;
} Operand;

typedef struct MemOperand {
    Register    Base;
    int64_t     Offset;
    AddrMode    AddressMode;
} MemOperand;

typedef struct AssemblerBase {
    uintptr_t           FixedAddress;
    CodeMemBuffer       CodeBuffer;
    RelocDataLabel**    DataLabels;
    size_t              DataLabelsSize;
    size_t              DataLabelsCapacity;
} AssemblerBase;

struct {
    uint32_t Rd         : 5;    // Destination register
    uint32_t immhi      : 19;   // 19-bit upper immediate
    uint32_t dummy_0    : 5;    // Must be 10000 == 0x10
    uint32_t immlo      : 2;    // 2-bit lower immediate
    uint32_t op         : 1;    // 0 = ADR, 1 = ADRP
} instruction_decoder;

typedef struct relo_ctx_t {
    uintptr_t       Cursor;
    CodeMemBlock*   Origin;
    CodeMemBlock    RelocatedBlock;
    CodeMemBuffer*  RelocatedBuffer;
} relo_ctx_t;

typedef struct allocator_t {
    uint8_t*    Buffer;
    uint32_t    Size;
    uint32_t    Capacity;
    uint32_t    BuiltinAlignment;
} allocator_t;

typedef struct MemoryAllocator {
    allocator_t*    CodePages;
    size_t          CodePageCount;
} MemoryAllocator;

typedef struct InterceptRouting {
    InterceptorEntry*  InterceptEntry;
    Trampoline*        Trampoline;
    uintptr_t          HookFunction;
} InterceptRouting;


Register InvalidRegister    = { 0, 0, kInvalid };

const int kMmapFd           = VM_MAKE_TAG( 255 );
const int kMmapFdOffset     = 0;

#define W( code ) (CPURegister) { .RegisterId = code, .RegisterSize = 32, .RegisterType = kRegister_32 }
#define X( code ) (CPURegister) { .RegisterId = code, .RegisterSize = 64, .RegisterType = kRegister_64 }
#define ARM64_TMP_REG_NDX_0 17

static const Register   TMP_REG_0   = X( ARM64_TMP_REG_NDX_0 );
static const Register   SP          = (Register) { 31, 64, kRegister_64 };
static const Register   xzr         = (Register) { 31, 64, kRegister_64 };
static const Register   wzr         = (Register) { 31, 32, kRegister_32 };

static MemoryAllocator gMemoryAllocator;

static
ErrorStatus
    ApplyCodePatch
    (
        IN          void*           Address,
        IN          uint8_t*        Buffer,
        IN          uint32_t        BufferSize
    )
{
    ErrorStatus     retVal              = ERROR_FAILURE;
    uintptr_t       patchPage           = ALIGN_FLOOR( Address, vm_page_size );
    uintptr_t       remapDestPage       = patchPage;
    kern_return_t   kernReturn          = KERN_FAILURE;
    uint32_t        pageBoundary        = 0;
    uint32_t        crossOverBoundary   = 0;
    uintptr_t       crossOverPage       = 0;

    __VERIFY_PARAM( Address, Buffer );

    if( 0 == BufferSize )
    {
        return ERROR_INVALID_ARGUMENT;
    }

    // Handle case where patch crosses over page boundary
    if( ( (uintptr_t)Address + BufferSize ) > ( patchPage + vm_page_size ) )
    {
        pageBoundary = ( patchPage + vm_page_size - (uintptr_t)Address );

        if( ERROR_INVALID_ARGUMENT == ( retVal = ApplyCodePatch( (void*) Address,
                                                                 Buffer,
                                                                 pageBoundary ) ) )
        {
            return retVal;
        }

        crossOverPage       = (uintptr_t)Address + pageBoundary;
        crossOverBoundary   = BufferSize - pageBoundary;

        return ApplyCodePatch( (void*) crossOverPage,
                                Buffer + pageBoundary,
                                crossOverBoundary );
    }

    __typeof(vm_protect) *vm_protect_fn = (__typeof(vm_protect) *)vm_protect_address;

#if __has_feature(ptrauth_calls)

    ptrauth_sign_unauthenticated((void *)vm_protect_fn, ptrauth_key_asia, 0);

#endif

    if( KERN_SUCCESS != ( kernReturn = vm_protect_fn( mach_task_self(),
                                                      remapDestPage,
                                                      vm_page_size,
                                                      false,
                                                      ( VM_PROT_READ | VM_PROT_WRITE | VM_PROT_COPY ) ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR,
                "vm_protect() Failed: %s\n",
                mach_error_string( kernReturn ) );
        retVal = ERROR_MEMORY_PERMISSION;
    }
    else {

        memcpy( (void*) ( patchPage + ( (uint64_t)Address - remapDestPage ) ),
                Buffer,
                BufferSize );

        if( KERN_SUCCESS != ( kernReturn = vm_protect_fn( mach_task_self(),
                                                          remapDestPage,
                                                          vm_page_size,
                                                          false,
                                                          ( VM_PROT_READ | VM_PROT_EXECUTE ) ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR,
                    "vm_protect() Failed: %s\n",
                    mach_error_string( kernReturn ) );
            retVal = ERROR_MEMORY_PERMISSION;
        }
        else {
            retVal = ERROR_SUCCESS;
        } // vm_protect_fn()
    } // vm_protect_fn()

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
ErrorStatus
    Interceptor_Entry_backup_orig_code
    (
        IN          InterceptorEntry*       Entry
    )
{
    ErrorStatus     retVal              = ERROR_FAILURE;
    uint8_t*        originalCode        = NULL;
    uint32_t        trampolineSize      = 0;

    __VERIFY_PARAM( Entry );

    originalCode   = (uint8_t*) Entry->Address;
    trampolineSize = Entry->Patched.Size;

    if( NULL == ( Entry->OriginalCode = (uint8_t*) malloc( trampolineSize ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "malloc() Failed\n" );
        retVal = ERROR_MEM_ALLOC;
    }
    else {
        memcpy( Entry->OriginalCode,
                originalCode,
                trampolineSize );

        retVal = ERROR_SUCCESS;
    } // malloc()

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
ErrorStatus
    PseudoLabel_link_to
    (
        IN          PseudoLabel*        Label,
        IN          int                 LinkType,
        IN          size_t              PCOffset
    )
{
    ErrorStatus     retVal      = ERROR_FAILURE;
    size_t          refSize     = 0;

    __VERIFY_PARAM( Label );

    Label->ref_insts_count++;
    refSize = Label->ref_insts_count * sizeof( ref_inst_t );

    if( NULL == Label->ref_insts )
    {
        Label->ref_insts = (ref_inst_t*) malloc( refSize );
    }
    else {
        Label->ref_insts = (ref_inst_t*) realloc( Label->ref_insts, refSize );
    }

    if( NULL == Label->ref_insts )
    {
        DEBUGL( LOG_LEVEL_ERROR, "malloc() Failed\n" );
        Label->ref_insts_count = 0;
        retVal = ERROR_MEM_ALLOC;
    }
    else {
        Label->ref_insts[ Label->ref_insts_count - 1 ].link_type    = LinkType;
        Label->ref_insts[ Label->ref_insts_count - 1 ].inst_offset  = PCOffset;
        retVal = ERROR_SUCCESS;
    }

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
ErrorStatus
    CodeMemBuffer_emit
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          uint8_t*                InputBuffer,
        IN          int                     InputBufferSize
    )
{
    ErrorStatus     retVal      = ERROR_SUCCESS;
    uint32_t        capacity    = 0;

    __VERIFY_PARAM( CodeBuffer, InputBuffer );

    if( ( CodeBuffer->BufferSize + InputBufferSize ) > CodeBuffer->BufferCapacity )
    {
        capacity = CodeBuffer->BufferCapacity * 2;

        while( capacity < ( CodeBuffer->BufferSize + InputBufferSize ) )
        {
            capacity *= 2;
        }

        if( NULL == ( CodeBuffer->Buffer = (uint8_t*)realloc( CodeBuffer->Buffer, capacity ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "realloc() Failed\n" );
            CodeBuffer->BufferSize = 0;
            retVal = ERROR_MEM_ALLOC;
        }
        else {
            CodeBuffer->BufferCapacity = capacity;
        } // realloc()
    }

    if( ERROR_SUCCESS == retVal )
    {
        memcpy( ( CodeBuffer->Buffer + CodeBuffer->BufferSize ),
                InputBuffer,
                InputBufferSize );

        CodeBuffer->BufferSize += InputBufferSize;
    }

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
void
    PseudoLabel_link_confused_instructions
    (
        IN          PseudoLabel*        Label,
        IN  OUT     CodeMemBuffer*      CodeBuffer
    )
{
    int64_t     fixupOffset     = 0;
    uint32_t    instruction     = 0;
    uint32_t    newInstruction  = 0;
    size_t      i               = 0;

    __DEBUG_FUNCTION_START__;

    for( i = 0; i < Label->ref_insts_count; ++i )
    {
        fixupOffset     = Label->PcOffset - Label->ref_insts[ i ].inst_offset;
        instruction     = *(int32_t*)( CodeBuffer->Buffer + Label->ref_insts[ i ].inst_offset );
        newInstruction  = 0;

        if( 0 == Label->ref_insts[ i ].link_type )
        {
            set_bits( instruction, 5, 23, bits( ( fixupOffset >> 2 ), 0, 18 ) );
            newInstruction = instruction;
        }

        *(int32_t*)( CodeBuffer->Buffer + Label->ref_insts[ i ].inst_offset ) = newInstruction;
    } // for()

    __DEBUG_FUNCTION_EXIT__;
}

static
ErrorStatus
    Assembler_Initialize
    (
        IN          AssemblerBase*      Assembler,
        IN          uintptr_t           FixedAddress
    )
{
    ErrorStatus retVal = ERROR_FAILURE;

    __VERIFY_PARAM( Assembler );

    if( NULL == ( Assembler->CodeBuffer.Buffer = (uint8_t*) malloc( 64 ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "malloc() Failed\n" );
        retVal = ERROR_MEM_ALLOC;
    }
    else {
        Assembler->FixedAddress                 = FixedAddress;
        Assembler->CodeBuffer.BufferSize        = 0;
        Assembler->CodeBuffer.BufferCapacity    = 64;
        Assembler->DataLabels                   = NULL;
        Assembler->DataLabelsSize               = 0;
        Assembler->DataLabelsCapacity           = 0;

        retVal = ERROR_SUCCESS;
    } // malloc()

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
ErrorStatus
    AssemblerBase_createDataLabel
    (
        IN  OUT     RelocDataLabel**    Label,
        IN          AssemblerBase*      Assembler,
        IN          uint64_t            Data
    )
{
    ErrorStatus         retVal      = ERROR_FAILURE;
    RelocDataLabel**    labels      = NULL;
    size_t              capacity    = 0;
    size_t              refSize     = 0;

    __VERIFY_PARAM( Label, Assembler );

    if( NULL == ( *Label = (RelocDataLabel*) malloc( sizeof( RelocDataLabel ) ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "malloc() Failed\n" );
        retVal = ERROR_MEM_ALLOC;
    }
    else {
        memcpy( ( *Label )->Data,
                &Data,
                sizeof( uint64_t ) );

        if( Assembler->DataLabelsSize >= Assembler->DataLabelsCapacity )
        {
            capacity = ( ( Assembler->DataLabelsCapacity == 0 )
                        ? 1
                        : ( Assembler->DataLabelsCapacity * 2 ) );
            refSize  = capacity * sizeof( RelocDataLabel* );

            if( NULL == Assembler->DataLabels )
            {
                labels = (RelocDataLabel**) malloc( refSize );
            }
            else {
                labels = (RelocDataLabel**) realloc( Assembler->DataLabels, refSize );
            }

            if( NULL == labels )
            {
                free( *Label );
                capacity = 0;
                retVal = ERROR_MEM_ALLOC;
            }
            else {
                retVal = ERROR_SUCCESS;
            }

            Assembler->DataLabels           = labels;
            Assembler->DataLabelsCapacity   = capacity;
        }

        if( ERROR_SUCCESS == retVal )
        {
            ( *Label )->DataSize                = (uint8_t) sizeof( uint64_t );
            ( *Label )->Label.ref_insts_count   = 0;
            ( *Label )->Label.PcOffset          = 0;
            ( *Label )->Label.ref_insts         = NULL;

            Assembler->DataLabels[ Assembler->DataLabelsSize++ ] = *Label;
        }
    } // malloc()

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
void
    AssemblerBase_bindLabel
    (
        IN          AssemblerBase*      Assembler,
        IN          PseudoLabel*        Label
    )
{
    Label->PcOffset = Assembler->CodeBuffer.BufferSize;
    if( 0 != Label->ref_insts_count )
    {
        PseudoLabel_link_confused_instructions( Label, &Assembler->CodeBuffer );
    }
}

static
ErrorStatus
    AssemblerBase_relocDataLabels
    (
        IN          AssemblerBase*      Assembler
    )
{
    ErrorStatus     retVal      = ERROR_SUCCESS;
    size_t          i           = 0;

    __VERIFY_PARAM( Assembler );

    for( i = 0; i < Assembler->DataLabelsSize; i++ )
    {
        AssemblerBase_bindLabel( Assembler, &Assembler->DataLabels[ i ]->Label );

        retVal = CodeMemBuffer_emit( &Assembler->CodeBuffer,
                                     Assembler->DataLabels[ i ]->Data,
                                     Assembler->DataLabels[ i ]->DataSize );
    } // for()

    __DEBUG_RETVAL( retVal );
    return retVal;
}

// LoadStore
static
int32_t
    OpEncode_LoadStorePair
    (
        IN          LoadStorePairOp         Op,
        IN          const CPURegister*      RegisterRt,
        IN          const MemOperand*       Addr
    )
{
    int         imm7        = 0;
    int32_t     scale       = 2;
    int32_t     opc         = bits( Op, 30, 31 );

    if( kRegister > RegisterRt->RegisterType )
    {
      scale += bit( opc, 1 );
    }
    else if( kVRegister < RegisterRt->RegisterType )
    {
      scale += opc;
    }

    imm7 = (int)( Addr->Offset >> scale );

    return LeftShift( imm7, 7, 15 );
}

// register operation size, 32 bits or 64 bits
static
int32_t
    OpEncode_sf
    (
        IN          const Register*         Reg
    )
{
    int32_t retVal = 0;

    if( 64 == Reg->RegisterSize )
    {
        retVal = INT32_MIN;
    }

    return retVal;
}

// LogicalShift
static
int32_t
    OpEncode_LogicalShift
    (
        IN          const Register*         RegisterRd,
        IN          const Register*         RegisterRn,
        IN          const Operand*          Operand
    )
{
    return( OpEncode_sf( RegisterRd )
            | LeftShift( Operand->Shift, 2, 22 )
            | Rm( Operand->Register )
            | LeftShift( Operand->ShiftExtendImmediate, 6, 10 )
            | Rn( RegisterRn )
            | Rd( RegisterRd ) );
}

// LogicalImmeidate
static
int32_t
    OpEncode_LogicalImmediate
    (
        IN          const Register*         RegisterRd,
        IN          const Register*         RegisterRn,
        IN          const Operand*          Operand
    )
{
    int64_t imm     = Operand->Immediate;
    int32_t immr    = bits( imm, 0, 5  );
    int32_t imms    = bits( imm, 6, 11 );

    return( OpEncode_sf( RegisterRd )
            | LeftShift( immr, 6, 16 )
            | LeftShift( imms, 6, 10 )
            | Rd( RegisterRd )
            | Rn( RegisterRn ) );
}

static inline uint16_t Low16Bits( uint32_t value )
{
  return (uint16_t)( value & 0xffff );
}

static inline uint16_t High16Bits( uint32_t value )
{
  return (uint16_t)( value >> 16 );
}

static inline uint32_t Low32Bits( uint64_t value )
{
  return (uint32_t)( value );
}

static inline uint32_t High32Bits( uint64_t value )
{
  return (uint32_t)( value >> 32 );
}

static
ErrorStatus
    Assembler_Write32BitInstruction
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          uint32_t                Value
    )
{
    return CodeMemBuffer_emit( CodeBuffer,
                               (uint8_t*) &Value,
                               sizeof( uint32_t ) );
}

static
ErrorStatus
    AssemblerBase_LogicalShift
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          const Register*         RegisterRd,
        IN          const Register*         RegisterRn,
        IN          const Operand*          Operand,
        IN          LogicalOp               Op
    )
{
    ErrorStatus     retVal          = ERROR_FAILURE;
    int32_t         combinedOp      = 0;
    uint32_t        value           = 0;

    __VERIFY_PARAM( CodeBuffer,
                    RegisterRd,
                    RegisterRn,
                    Operand );

    combinedOp = OpEncode_LogicalShift( RegisterRd,
                                        RegisterRn,
                                        Operand );
    value  = ( Op | LogicalShiftedFixed | combinedOp );
    retVal = Assembler_Write32BitInstruction( CodeBuffer, value );

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
ErrorStatus
    AssemblerBase_LogicalImmediate
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          const Register*         RegisterRd,
        IN          const Register*         RegisterRn,
        IN          const Operand*          Operand,
        IN          LogicalOp               Op
    )
{
    ErrorStatus     retVal          = ERROR_FAILURE;
    int32_t         combinedOp      = 0;

    __VERIFY_PARAM( CodeBuffer,
                    RegisterRd,
                    RegisterRn,
                    Operand );

    combinedOp = OpEncode_LogicalImmediate( RegisterRd,
                                            RegisterRn,
                                            Operand );
    retVal = Assembler_Write32BitInstruction( CodeBuffer, Op | combinedOp );

    return retVal;
}

static
ErrorStatus
    AssemblerBase_Logical
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          const Register*         RegisterRd,
        IN          const Register*         RegisterRn,
        IN          const Operand*          Operand,
        IN          LogicalOp               Op
    )
{
    ErrorStatus retVal = ERROR_FAILURE;

    __VERIFY_PARAM( CodeBuffer,
                    RegisterRd,
                    RegisterRn,
                    Operand );

    if( 0 == Operand->Register->RegisterId )
    {
        retVal = AssemblerBase_LogicalImmediate( CodeBuffer,
                                                 RegisterRd,
                                                 RegisterRn,
                                                 Operand,
                                                 Op );
    }
    else {
        retVal = AssemblerBase_LogicalShift( CodeBuffer,
                                             RegisterRd,
                                             RegisterRn,
                                             Operand,
                                             Op );
    }

    return retVal;
}

static
ErrorStatus
    AssemblerBase_AddSubImmediate
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          const Register*         RegisterRd,
        IN          const Register*         RegisterRn,
        IN          const Operand*          Operand,
        IN          AddSubImmediateOp       Op
    )
{
    ErrorStatus     retVal      = ERROR_FAILURE;
    uint32_t        value       = 0;

    __VERIFY_PARAM( CodeBuffer,
                    RegisterRd,
                    RegisterRn,
                    Operand );

    if( 0 != Operand->Register->RegisterId )
    {
        retVal = ERROR_SUCCESS;
    }
    else {
        value   = ( Op
                    | Rd( RegisterRd )
                    | Rn( RegisterRn )
                    | LeftShift( Operand->Immediate, 12, 10 ) );
        retVal  = Assembler_Write32BitInstruction( CodeBuffer, value );
    }

    return retVal;
}

static
ErrorStatus
    AssemblerBase_MoveWide
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          Register*               RegisterRd,
        IN          uint64_t                Immediate,
        IN          int                     Shift,
        IN          MoveWideImmediateOp     Op
    )
{
    ErrorStatus     retVal      = ERROR_FAILURE;
    uint32_t        value       = 0;

    __VERIFY_PARAM( CodeBuffer, RegisterRd );

    if( 0 < Shift )
    {
        Shift /= 16;
    }
    else {
        Shift = 0;
    }

    value   = ( MoveWideImmediateFixed
                | Op
                | OpEncode_sf( RegisterRd )
                | LeftShift( Shift,     2,  21 )
                | LeftShift( Immediate, 16,  5 )
                | Rd( RegisterRd ) );

    retVal = Assembler_Write32BitInstruction( CodeBuffer, value );

    return retVal;
}

static
ErrorStatus
    AssemblerBase_LoadStorePair
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          LoadStorePairOp         Op,
        IN          const Register*         RegisterRt,
        IN          const Register*         RegisterRt2,
        IN          const MemOperand*       Addr
    )
{
    ErrorStatus     retVal          = ERROR_FAILURE;
    int32_t         combinedOp      = 0;
    int32_t         addrModeOp      = 0;
    uint32_t        value           = 0;

    __VERIFY_PARAM( CodeBuffer,
                    RegisterRt,
                    RegisterRt2,
                    Addr );

    combinedOp  = ( OpEncode_LoadStorePair( Op, RegisterRt, Addr )
                    | Rt2( RegisterRt2 )
                    | ( Addr->Base.RegisterId << kRnShift )
                    | Rt( RegisterRt ) );
    addrModeOp  = LoadStorePairPostIndexFixed;

    if( AddrModeOffset == Addr->AddressMode )
    {
        addrModeOp = LoadStorePairOffsetFixed;
    }
    else if( AddrModePreIndex == Addr->AddressMode )
    {
        addrModeOp = LoadStorePairPreIndexFixed;
    }

    value  = ( Op | addrModeOp | combinedOp );
    retVal = Assembler_Write32BitInstruction( CodeBuffer, value );

    return retVal;
}

static
ErrorStatus
    AssemblerBase_LoadStore
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          LoadStoreOp             Op,
        IN          const CPURegister*      RegisterRt,
        IN          const MemOperand*       Addr
    )
{
    ErrorStatus     retVal      = ERROR_FAILURE;
    int             scale       = 0;
    uint32_t        value       = 0;

    __VERIFY_PARAM( CodeBuffer,
                    RegisterRt,
                    Addr );

    if( AddrModeOffset != Addr->AddressMode )
    {
        retVal = ERROR_SUCCESS;
    }
    else {

        if( LoadStoreUnsignedOffsetFixed == ( Op & LoadStoreUnsignedOffsetFixed ) )
        {
            scale = bits( Op, 30, 31 );
        }

        value   = ( LoadStoreUnsignedOffsetFixed
                    | Op
                    | LeftShift( (int64_t)( Addr->Offset >> scale ), 12, 10 )
                    | ( Addr->Base.RegisterId << kRnShift )
                    | Rt( RegisterRt ) );
        retVal  = Assembler_Write32BitInstruction( CodeBuffer, value );
    }

    return retVal;
}

static
ErrorStatus
    AssemblerBase_EmitLoadRegLiteral
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          LoadRegLiteralOp        Op,
        IN          CPURegister*            RegisterRt,
        IN          int64_t                 Immediate
    )
{
    ErrorStatus     retVal      = ERROR_FAILURE;
    uint32_t        value       = 0;

    value   = ( Op
                | LeftShift( Immediate >> 2, 26, 5 )
                | Rt( RegisterRt ) );
    retVal  = Assembler_Write32BitInstruction( CodeBuffer, value );

    return retVal;
}

static
ErrorStatus
    Assemble_add
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          const Register*         RegisterRd,
        IN          const Register*         RegisterRn,
        IN          int64_t                 Immediate
    )
{
    ErrorStatus         retVal      = ERROR_FAILURE;
    AddSubImmediateOp   op          = ADD_w_imm;

    __VERIFY_PARAM( CodeBuffer,
                    RegisterRd,
                    RegisterRn );

    if( ( 64 == RegisterRd->RegisterSize ) &&
        ( 64 == RegisterRn->RegisterSize ) )
    {
        op = ADD_x_imm;
    }

    retVal = AssemblerBase_AddSubImmediate( CodeBuffer,
                                            RegisterRd,
                                            RegisterRn,
                                            &OPERAND_IMMEDIATE( Immediate ),
                                            op );

    return retVal;
}

/**
 * NOTE: Currently NOT used
 */
// static
// ErrorStatus
//     Assemble_mov
//     (
//         IN  OUT     CodeMemBuffer*          CodeBuffer,
//         IN          const Register*         RegisterRd,
//         IN          const Register*         RegisterRn
//     )
// {
//     ErrorStatus retVal = ERROR_FAILURE;

//     __VERIFY_PARAM( CodeBuffer,
//                     RegisterRd,
//                     RegisterRn );

//     if( ( RegisterRd->RegisterId == SP.RegisterId ) ||
//         ( RegisterRd->RegisterId == SP.RegisterId ) )
//     {
//         retVal = Assemble_add( CodeBuffer,
//                                RegisterRd,
//                                RegisterRn,
//                                0 );
//     }
//     else
//     {
//         if( 64 == RegisterRd->RegisterSize )
//         {
//             retVal = AssemblerBase_Logical( CodeBuffer,
//                                             RegisterRd,
//                                             &xzr,
//                                             &OPERAND_REGISTER( RegisterRn ),
//                                             ORR );
//         }
//         else {
//             retVal = AssemblerBase_Logical( CodeBuffer,
//                                             RegisterRd,
//                                             &wzr,
//                                             &OPERAND_REGISTER( RegisterRn ),
//                                             ORR );
//         }
//     }

//     return retVal;
// }

/**
 * NOTE: Currently NOT used
 */
// static ErrorStatus Assemble_stp(CodeMemBuffer* code_buffer, const Register* rt, const Register* rt2, const MemOperand* dst)
// {
//     ErrorStatus retVal = ERROR_UNIMPLEMENTED;

//     if( rt->RegisterType == kSIMD_FP_Register_128 )
//     {
//         retVal = AssemblerBase_LoadStorePair( code_buffer, STP_q, rt, rt2, dst );
//     }
//     else if( rt->RegisterType == kRegister_X )
//     {
//         retVal = AssemblerBase_LoadStorePair( code_buffer, STP_x, rt, rt2, dst );
//     }

//     return retVal;
// }

/**
 * NOTE: Currently NOT used
 */
// static ErrorStatus Assemble_ldp(CodeMemBuffer* code_buffer, const Register* rt, const Register* rt2, const MemOperand* src)
// {
//     ErrorStatus retVal = ERROR_UNIMPLEMENTED;

//     if (rt->RegisterType == kSIMD_FP_Register_128)
//     {
//         retVal = AssemblerBase_LoadStorePair( code_buffer,
//                                               LDP_q,
//                                               (CPURegister*)rt,
//                                               (CPURegister*)rt2,
//                                               src );
//     }
//     else if (rt->RegisterType == kRegister_X)
//     {
//         retVal = AssemblerBase_LoadStorePair( code_buffer,
//                                               LDP_x,
//                                               (CPURegister*)rt,
//                                               (CPURegister*)rt2,
//                                               src );
//     }

//     return retVal;
// }

/**
 * NOTE: Currently NOT used
 */
// static ErrorStatus Assemble_str(CodeMemBuffer* code_buffer, const CPURegister* rt, const MemOperand* src)
// {
//     return AssemblerBase_LoadStore( code_buffer,
//                                     STR_x,
//                                     rt,
//                                     src );
// }

// static ErrorStatus Assemble_ldr(CodeMemBuffer* code_buffer, const CPURegister* rt, const MemOperand* src)
// {
//     return AssemblerBase_LoadStore( code_buffer,
//                                     LDR_x,
//                                     rt,
//                                     src );
// }

/**
 * NOTE: Currently NOT used
 */
// static ErrorStatus Assemble_b(CodeMemBuffer* code_buffer, int64_t imm )
// {
//     return Assembler_Write32BitInstruction( code_buffer, B | bits( imm >> 2, 0, 25 ) ); // imm26
// }

/**
 * NOTE: Currently NOT used
 */
// static ErrorStatus Assemble_sub(CodeMemBuffer* code_buffer, const Register* rd, const Register* rn, int64_t imm)
// {
//     ErrorStatus         retVal      = ERROR_FAILURE;
//     AddSubImmediateOp   op          = 0;

//     if( ( 64 == rd->RegisterSize ) &&
//         ( 64 == rn->RegisterSize ) )
//     {
//         op = SUB_x_imm;
//     }
//     else {
//         op = SUB_w_imm;
//     }

//     retVal = AssemblerBase_AddSubImmediate( code_buffer,
//                                             rd,
//                                             rn,
//                                             &OPERAND_IMMEDIATE( imm ),
//                                             op );

//     return retVal;
// }

/**
 * NOTE: Currently NOT used
 */
// static ErrorStatus Assemble_brk(CodeMemBuffer* code_buffer, int code)
// {
//     return Assembler_Write32BitInstruction( code_buffer, BRK | LeftShift( code, 16, 5 ) );
// }

// static
// ErrorStatus
//     Assemble_adrp
//     (
//         CodeMemBuffer* code_buffer,
//         const Register* rd,
//         int64_t imm
//     )
// {
//     return Assembler_Write32BitInstruction( code_buffer, ADRP
//                                             | Rd( rd )
//                                             | LeftShift( bits( imm >> 12, 0, 1  ), 2, 29 )      // immlo
//                                             | LeftShift( bits( imm >> 12, 2, 20 ), 19, 5 ) );   // immhi
// }


static
ErrorStatus
    Assemble_ldr_imm
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          Register*               RegisterRt,
        IN          int64_t                 Immediate
    )
{
    ErrorStatus         retVal      = ERROR_FAILURE;
    LoadRegLiteralOp    op          = LiteralLoadRegisterFixed;

    __VERIFY_PARAM( CodeBuffer, RegisterRt );

    switch( RegisterRt->RegisterType )
    {
        case kRegister_32:
        {
            op = LDR_w_literal;
            break;
        }

        case kRegister_X:
        {
            op = LDR_x_literal;
            break;
        }

        case kSIMD_FP_Register_S:
        {
            op = LDR_s_literal;
            break;
        }

        case kSIMD_FP_Register_D:
        {
            op = LDR_d_literal;
            break;
        }

        case kSIMD_FP_Register_Q:
        {
            op = LDR_q_literal;
            break;
        }

        default:
        {
            DEBUGL( LOG_LEVEL_WARNING, "This code should not be reachable!\n" );
            break;
        }
    }

    retVal = AssemblerBase_EmitLoadRegLiteral( CodeBuffer,
                                               op,
                                               RegisterRt,
                                               Immediate );

    return retVal;
}

static
ErrorStatus
    Assemble_AdrpAdd
    (
        IN          CodeMemBuffer*      CodeBuffer,
        IN          Register*           RegisterRd,
        IN          uint64_t            From,
        IN          uint64_t            To
    )
{
    ErrorStatus     retVal          = ERROR_FAILURE;
    uint64_t        from_PAGE       = ALIGN_FLOOR( From, 0x1000 );
    uint64_t        to_PAGE         = ALIGN_FLOOR( To,   0x1000 );
    uint64_t        to_PAGEOFF      = (uint64_t)To % 0x1000;
    uint32_t        value           = 0;

    __VERIFY_PARAM( CodeBuffer, RegisterRd );

    value   = ( ADRP
                | Rd( RegisterRd )
                | LeftShift( bits( ( to_PAGE - from_PAGE ) >> 12, 0, 1  ), 2,  29 )
                | LeftShift( bits( ( to_PAGE - from_PAGE ) >> 12, 2, 20 ), 19,  5 ) );

    if( ERROR_SUCCESS != ( retVal = Assembler_Write32BitInstruction( CodeBuffer, value ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "Assemble_adrp() Failed\n" );
    }
    else {
        retVal = Assemble_add( CodeBuffer,
                               RegisterRd,
                               RegisterRd,
                               to_PAGEOFF );
    } // Assemble_adrp()

    return retVal;
}

static
ErrorStatus
    TurboAssemble_Mov
    (
        IN  OUT     CodeMemBuffer*      CodeBuffer,
        IN          Register*           RegisterRd,
        IN          uint64_t            Immediate
    )
{
    ErrorStatus     retVal  = ERROR_FAILURE;
    const uint32_t  w0      = Low32Bits( Immediate );
    const uint32_t  w1      = High32Bits( Immediate );
    const uint16_t  h0      = Low16Bits( w0 );
    const uint16_t  h1      = High16Bits( w0 );
    const uint16_t  h2      = Low16Bits( w1 );
    const uint16_t  h3      = High16Bits( w1 );

    __VERIFY_PARAM( CodeBuffer, RegisterRd );

    if( ERROR_SUCCESS != ( retVal = AssemblerBase_MoveWide( CodeBuffer,
                                                            RegisterRd,
                                                            h0,
                                                            0,
                                                            MOVZ ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "AssemblerBase_MoveWide() Failed\n" );
    }
    else {
        if( ERROR_SUCCESS != ( retVal = AssemblerBase_MoveWide( CodeBuffer,
                                                                RegisterRd,
                                                                h1,
                                                                16,
                                                                MOVK ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "AssemblerBase_MoveWide() Failed\n" );
        }
        else {
            if( ERROR_SUCCESS != ( retVal = AssemblerBase_MoveWide( CodeBuffer,
                                                                    RegisterRd,
                                                                    h2,
                                                                    32,
                                                                    MOVK ) ) )
            {
                DEBUGL( LOG_LEVEL_ERROR, "AssemblerBase_MoveWide() Failed\n" );
            }
            else {
                retVal = AssemblerBase_MoveWide( CodeBuffer,
                                                 RegisterRd,
                                                 h3,
                                                 48,
                                                 MOVK );
            } // Assemble_movk()
        } // Assemble_movk()
    } // Assemble_movz()

    __DEBUG_RETVAL( retVal );
    return retVal;
}

//

static
ErrorStatus
    Assembler_WriteInstruction_LDR
    (
        IN  OUT     CodeMemBuffer*          CodeBuffer,
        IN          Register*               RegisterRt,
        IN          PseudoLabel*            Label
    )
{
    ErrorStatus retVal = ERROR_FAILURE;

    __VERIFY_PARAM( CodeBuffer,
                    RegisterRt,
                    Label );

    if( ERROR_SUCCESS != ( retVal = PseudoLabel_link_to( Label,
                                                         kLabelImm19,
                                                         CodeBuffer->BufferSize ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "PseudoLabel_link_to() Failed\n" );
    }
    else {
        retVal = Assemble_ldr_imm( CodeBuffer,
                                   RegisterRt,
                                   0 );
    } // PseudoLabel_link_to()

    return retVal;
}

static
ErrorStatus
    LiteralLdrBranch
    (
        IN  OUT     AssemblerBase*      Assembler,
        IN          uint64_t            Address
    )
{
    ErrorStatus         retVal      = ERROR_FAILURE;
    RelocDataLabel*     label       = NULL;
    uint32_t            value       = 0;

    __VERIFY_PARAM( Assembler );

    if( ERROR_SUCCESS != ( retVal = AssemblerBase_createDataLabel( &label,
                                                                   Assembler,
                                                                   Address ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "AssemblerBase_createDataLabel() Failed\n" );
    }
    else {
        if( ERROR_SUCCESS != ( retVal = Assembler_WriteInstruction_LDR( &Assembler->CodeBuffer,
                                                                        (Register*) &TMP_REG_0,
                                                                        &label->Label ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "Assembler_WriteInstruction_LDR() Failed\n" );
        }
        else {
            value  = ( BR | ( ARM64_TMP_REG_NDX_0 << kRnShift ) );
            retVal = Assembler_Write32BitInstruction( &Assembler->CodeBuffer, value );
        } // Assembler_WriteInstruction_LDR()
    } // AssemblerBase_createDataLabel()

    if( ERROR_SUCCESS != retVal )
    {
        if( NULL != label )
        {
            free( label );
        }
    }

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
ErrorStatus
    GenerateNormalTrampolineBuffer
    (
        IN  OUT     Trampoline**        TrampolineBuffer,
        IN          uintptr_t           From,
        IN          uintptr_t           To
    )
{
    ErrorStatus     retVal      = ERROR_FAILURE;
    AssemblerBase   assembler   = { 0 };
    uint64_t        distance    = 0;
    uint64_t        adrp_range  = 0;
    uint8_t*        codeBuffer  = NULL;
    uint32_t        value       = 0;

    __VERIFY_PARAM( TrampolineBuffer );

    if( ERROR_SUCCESS != ( retVal = Assembler_Initialize( &assembler, From ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "Assembler_Initialize() Failed\n" );
    }
    else {
        distance    = llabs( (int64_t) ( From - To ) );
        adrp_range  = ( UINT32_MAX - 1 );

        if( distance < adrp_range )
        {
            if( ERROR_SUCCESS != ( retVal = Assemble_AdrpAdd( &assembler.CodeBuffer,
                                                              (Register*) &TMP_REG_0,
                                                              From,
                                                              To ) ) )
            {
                DEBUGL( LOG_LEVEL_ERROR, "Assemble_AdrpAdd() Failed\n" );
            }
            else {
                value  = ( BR | ( ARM64_TMP_REG_NDX_0 << kRnShift ) );
                retVal = Assembler_Write32BitInstruction( &assembler.CodeBuffer, value );
            } // Assemble_AdrpAdd()
        }
        else {
            retVal = LiteralLdrBranch( &assembler, (uint64_t)To );
        } // distance < adrp_range

        if( ERROR_SUCCESS == retVal )
        {
            // bind all labels
            if( ERROR_SUCCESS != ( retVal = AssemblerBase_relocDataLabels( &assembler ) ) )
            {
                DEBUGL( LOG_LEVEL_ERROR, "AssemblerBase_relocDataLabels() Failed\n" );
            }
            else {
                if( NULL == ( codeBuffer = (uint8_t *)malloc( assembler.CodeBuffer.BufferSize ) ) )
                {
                    DEBUGL( LOG_LEVEL_ERROR, "malloc() Failed\n" );
                    retVal = ERROR_MEM_ALLOC;
                }
                else {
                    memcpy( codeBuffer,
                            assembler.CodeBuffer.Buffer,
                            assembler.CodeBuffer.BufferSize );

                    if( NULL == ( *TrampolineBuffer = (Trampoline*)malloc( sizeof( Trampoline ) ) ) )
                    {
                        DEBUGL( LOG_LEVEL_ERROR, "malloc() Failed\n" );
                        free( codeBuffer );
                        retVal = ERROR_MEM_ALLOC;
                    }
                    else {
                        ( *TrampolineBuffer )->Buffer.Start = (uintptr_t)codeBuffer;
                        ( *TrampolineBuffer )->Buffer.Size  = assembler.CodeBuffer.BufferSize;
                    } // malloc()
                } // malloc()
            } // AssemblerBase_relocDataLabels()
        } // SUCCESS
    } // Assembler_Initialize()

    __DEBUG_RETVAL( retVal )
    return retVal;
}

static
uintptr_t
    GetContextCursor
    (
        relo_ctx_t* Context
    )
{
    return (uintptr_t)( Context->Origin->Start + ( Context->Cursor - Context->Origin->Start ) );
}

static inline bool inst_is_b_bl( uint32_t Instruction )
{
    return (Instruction & UnconditionalBranchFixedMask) == UnconditionalBranchFixed;
}
static inline bool inst_is_ldr_literal(uint32_t Instruction)
{
    return ((Instruction & LiteralLoadRegisterFixedMask) == LiteralLoadRegisterFixed);
}
static inline bool inst_is_adr(uint32_t Instruction)
{
    return( (Instruction & PCRelAddressingFixedMask) == PCRelAddressingFixed &&
            (Instruction & PCRelAddressingMask) == ADR );
}
static inline bool inst_is_adrp(uint32_t Instruction)
{
    return( (Instruction & PCRelAddressingFixedMask) == PCRelAddressingFixed &&
            (Instruction & PCRelAddressingMask) == ADRP );
}
static inline bool inst_is_b_cond(uint32_t Instruction)
{
    return (Instruction & ConditionalBranchFixedMask) == ConditionalBranchFixed;
}
static inline bool inst_is_compare_b(uint32_t Instruction)
{
    return (Instruction & CompareBranchFixedMask) == CompareBranchFixed;
}
static inline bool inst_is_test_b(uint32_t Instruction)
{
    return (Instruction & TestBranchFixedMask) == TestBranchFixed;
}

static inline int64_t SignExtend(unsigned long x, int M, int N)
{
    char sign_bit = bit(x, M - 1);
    unsigned long sign_mask = 0 - sign_bit;
    x |= ((sign_mask >> M) << M);
    return (int64_t)x;
}

// static inline int decode_rt(uint32_t Instruction)
// {
//     return bits(Instruction, 0, 4);
// }
// static inline int decode_rd(uint32_t Instruction)
// {
//     return bits(Instruction, 0, 4);
// }

static inline int64_t decode_imm26_offset(uint32_t Instruction)
{
    int64_t offset;
    {
        int64_t imm26 = bits(Instruction, 0, 25);
        offset = (imm26 << 2);
    }
    offset = SignExtend(offset, 2 + 26, 64);
    return offset;
}
static inline int64_t Imm19Offset(uint32_t Instruction)
{
    int64_t offset;
    {
        int64_t imm19 = bits( Instruction, 5, 23 );
        offset = (imm19 << 2);
    }
    offset = SignExtend(offset, 2 + 19, 64);
    return offset;
}
static inline int64_t ImmHiImmLoOffset(uint32_t Instruction)
{
    *(uint32_t*) &instruction_decoder = Instruction;

    int64_t imm = instruction_decoder.immlo + ( instruction_decoder.immhi << 2 );
    imm = SignExtend( imm, 2 + 19, 64 );
    return imm;
}
static inline int64_t ImmHiImmLoZero12Offset(uint32_t Instruction)
{
    int64_t imm = ImmHiImmLoOffset(Instruction);
    imm = imm << 12;
    return imm;
}
static inline int64_t Imm14Offset(uint32_t Instruction)
{
    int64_t offset;
    {
        int64_t imm14 = bits(Instruction, 5, 18);
        offset = (imm14 << 2);
    }
    offset = SignExtend(offset, 2 + 14, 64);
    return offset;
}

static
void
    AllocatorInit
    (
        IN  OUT     allocator_t*        Allocator,
        IN          uint8_t*            Buffer,
        IN          uint32_t            Capacity,
        IN          uint32_t            Alignment
    )
{
    Allocator->Buffer           = Buffer;
    Allocator->Capacity         = Capacity;
    Allocator->BuiltinAlignment = Alignment;
    Allocator->Size             = 0;
}

static
ErrorStatus
    AllocatorAlloc
    (
        IN  OUT     uint8_t**           Data,
        IN  OUT     allocator_t*        Allocator,
        IN          uint32_t            Size,
        IN          uint32_t            Alignment
    )
{
    ErrorStatus     retVal          = ERROR_FAILURE;
    uint32_t        alignment       = 0;
    uintptr_t       pageCeiling     = 0;

    alignment   = ( ( Alignment != 0 )
                    ? Alignment
                    : Allocator->BuiltinAlignment );
    pageCeiling = (uintptr_t)( Allocator->Buffer + Allocator->Size );

    Allocator->Size += ( ALIGN_CEIL( pageCeiling, alignment ) - pageCeiling );

    if( ( Allocator->Size + Size ) > Allocator->Capacity )
    {
        DEBUGL( LOG_LEVEL_WARNING, "Allocator not large enough!\n" );
        retVal = ERROR_MEMORY_OVERFLOW;
    }
    else {
        *Data = (uint8_t*)( Allocator->Buffer + Allocator->Size );
        // DEBUG_LOG("alloc: %p - %p", *Data, Size);
        Allocator->Size += Size;

        retVal = ERROR_SUCCESS;
    }

    return retVal;
}

static
int
    GetProtectionFromMemoryPermission
    (
        IN          MemoryPermission    Access
    )
{
    int prot = 0;

    if( Access & kRead )
    {
        prot |= PROT_READ;
    }
    if( Access & kWrite )
    {
        prot |= PROT_WRITE;
    }
    if( Access & kExecute )
    {
        prot |= PROT_EXEC;
    }

    return prot;
}

static
ErrorStatus
    OSMemory_SetPermission
    (
        IN          void*               Address,
        IN          size_t              Size,
        IN          MemoryPermission    Access
    )
{
    ErrorStatus     retVal          = ERROR_FAILURE;
    int             protection      = 0;

    protection = GetProtectionFromMemoryPermission( Access );

    if( 0 != mprotect( Address,
                       Size,
                       protection ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "mprotect() Failed\n" );
        retVal = ERROR_MEMORY_PERMISSION;
    }
    else {
        retVal = ERROR_SUCCESS;
    }

    return retVal;
}

static
int
    OSMemory_PageSize
    (
        void
    )
{
    return (int)sysconf( _SC_PAGESIZE );
}

static
ErrorStatus
    OSMemory_Allocate
    (
        IN  OUT         void**              VirtualPage,
        IN              size_t              size,
        IN              MemoryPermission    access,
        IN  OPTIONAL    void*               FixedAddress
    )
{
    ErrorStatus retVal      = ERROR_FAILURE;
    int         protection  = 0;
    int         flags       = MAP_PRIVATE | MAP_ANONYMOUS;

    __VERIFY_PARAM( VirtualPage );

    protection = GetProtectionFromMemoryPermission(access);

    if( NULL != FixedAddress )
    {
        flags |= MAP_FIXED;
    }

    if( MAP_FAILED == ( *VirtualPage = mmap( FixedAddress,
                                             size,
                                             protection,
                                             flags,
                                             kMmapFd,
                                             kMmapFdOffset ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "mmap() Failed\n" );
        retVal = ERROR_MEMORY_MAPPING;
    }
    else {
        retVal = ERROR_SUCCESS;
    } // mmap()

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
ErrorStatus
    MemoryAllocator_allocExecBlock
    (
        IN  OUT     CodeMemBlock**      CodeBlock,
        IN          MemoryAllocator*    Allocator,
        IN          size_t              BufferSize
    )
{
    ErrorStatus     retVal          = ERROR_FAILURE;
    uint8_t*        result          = NULL;
    void*           page            = NULL;
    size_t          i               = 0;
    size_t          codePageSize    = 0;

    if( BufferSize > OSMemory_PageSize() )
    {
        DEBUGL( LOG_LEVEL_ERROR,
                "Requested Size is too large: %zu\n",
                BufferSize );
        return ERROR_MEMORY_OVERFLOW;
    } // OSMemory_PageSize()

    __VERIFY_PARAM( Allocator, CodeBlock );

    for( i = 0; ( i < Allocator->CodePageCount ) && ( ERROR_SUCCESS != retVal ); i++ )
    {
        retVal = AllocatorAlloc( &result,
                                 &Allocator->CodePages[ i ],
                                 BufferSize,
                                 0 );
    } // for()

    if( !result )
    {
        if( ERROR_SUCCESS != ( retVal = OSMemory_Allocate( &page,
                                                           OSMemory_PageSize(),
                                                           kNoAccess,
                                                           NULL ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "OSMemory_Allocate() Failed\n" );
        }
        else {
            if( ERROR_SUCCESS != ( retVal = OSMemory_SetPermission( page,
                                                                    OSMemory_PageSize(),
                                                                    kReadExecute ) ) )
            {
                DEBUGL( LOG_LEVEL_ERROR, "OSMemory_SetPermission() Failed\n" );
            }
            else {
                Allocator->CodePageCount++;
                codePageSize = Allocator->CodePageCount * sizeof( allocator_t );

                if( NULL == Allocator->CodePages )
                {
                    Allocator->CodePages = (allocator_t*) malloc( codePageSize );
                }
                else {
                    Allocator->CodePages = (allocator_t*) realloc( Allocator->CodePages, codePageSize );
                }

                if( NULL == Allocator->CodePages )
                {
                    DEBUGL( LOG_LEVEL_ERROR, "malloc() Failed\n" );
                    retVal = ERROR_MEM_ALLOC;
                }
                else {
                    AllocatorInit( &Allocator->CodePages[ Allocator->CodePageCount - 1 ],
                                   (uint8_t*) page,
                                   (uint32_t) sysconf( _SC_PAGESIZE ),
                                   8 );

                    retVal = AllocatorAlloc( &result,
                                             &Allocator->CodePages[ Allocator->CodePageCount - 1 ],
                                             BufferSize,
                                             0 );
                } // malloc()
            } // OSMemory_SetPermission()
        } // OSMemory_Allocate()
    } // !result

    if( ERROR_SUCCESS == retVal )
    {
        if( NULL == ( *CodeBlock = (CodeMemBlock*) malloc( sizeof( CodeMemBlock ) ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "malloc() Failed\n" );
            retVal = ERROR_MEM_ALLOC;
        }
        else {
            ( *CodeBlock )->Start = (uintptr_t)result;
            ( *CodeBlock )->Size  = BufferSize;
        } // malloc()
    } // AllocatorAlloc()

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
ErrorStatus
    AssemblerCodeBuilder_FinalizeFromAssembler
    (
        IN          AssemblerBase*      Assembler,
        IN          CodeMemBlock*       CodeBlock
    )
{
    ErrorStatus     retVal      = ERROR_FAILURE;
    CodeMemBlock*   block       = NULL;

    if( Assembler->FixedAddress )
    {
        retVal = ERROR_SUCCESS;
    }
    else {
        if( ERROR_SUCCESS != ( retVal = MemoryAllocator_allocExecBlock( &block,
                                                                        &gMemoryAllocator,
                                                                        Assembler->CodeBuffer.BufferSize ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "MemoryAllocator_allocExecBlock() Failed\n" );
        }
        else {
            Assembler->FixedAddress = block->Start;
        } // MemoryAllocator_allocExecBlock()
    } // fixed_addr

    if( ERROR_SUCCESS == retVal )
    {
        DEBUGL( LOG_LEVEL_NOTICE, "Patching hooked function call into function address...\n" );

        if( ERROR_SUCCESS != ( retVal = ApplyCodePatch( (void*) Assembler->FixedAddress,
                                                        Assembler->CodeBuffer.Buffer,
                                                        Assembler->CodeBuffer.BufferSize ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "ApplyCodePatch() Failed\n" );
        }
        else {
            CodeBlock->Start = Assembler->FixedAddress;
            CodeBlock->Size  = Assembler->CodeBuffer.BufferSize;
        } // ApplyCodePatch()
    }

    return retVal;
}

static
ErrorStatus
    WriteInstructionToBuffer_UnconditionalBranchFixed
    (
        IN          relo_ctx_t*         Context,
        IN  OUT     AssemblerBase*      Assembler,
        IN          uint32_t            Instruction
    )
{
    ErrorStatus     retVal  = ERROR_FAILURE;
    uintptr_t       dst     = 0;
    RelocDataLabel* label   = NULL;
    uint32_t        value   = 0;

    __VERIFY_PARAM( Context, Assembler );

    dst = GetContextCursor( Context ) + decode_imm26_offset( Instruction );

    if( ERROR_SUCCESS != ( retVal = AssemblerBase_createDataLabel( &label,
                                                                   Assembler,
                                                                   dst ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "AssemblerBase_createDataLabel() Failed\n" );
    }
    else {
        if( ERROR_SUCCESS != ( retVal = Assembler_WriteInstruction_LDR( &Assembler->CodeBuffer,
                                                                        (Register*) &TMP_REG_0,
                                                                        &label->Label ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "Assembler_WriteInstruction_LDR() Failed\n" );
        }
        else {
            if( BL == ( Instruction & UnconditionalBranchMask ) )
            {
                value = ( BLR | ( ARM64_TMP_REG_NDX_0 << kRnShift ) );
            }
            else {
                value = ( BR  | ( ARM64_TMP_REG_NDX_0 << kRnShift ) );
            } // BLR or BL

            retVal = Assembler_Write32BitInstruction( &Assembler->CodeBuffer, value );
        } // Assembler_WriteInstruction_LDR()
    } // AssemblerBase_createDataLabel()

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
ErrorStatus
    WriteInstructionToBuffer_LiteralLoadRegisterFixed
    (
        IN          relo_ctx_t*         Context,
        IN  OUT     AssemblerBase*      Assembler,
        IN          uint32_t            Instruction
    )
{
    ErrorStatus retVal  = ERROR_FAILURE;
    uintptr_t   dst     = 0;
    char        opc     = 0;
    int         rt      = 0;

    __VERIFY_PARAM( Context, Assembler );

    dst = GetContextCursor( Context ) + Imm19Offset( Instruction );
    rt  = bits( Instruction, 0,  4  );
    opc = bits( Instruction, 30, 31 );

    if( ERROR_SUCCESS != ( retVal = TurboAssemble_Mov( &Assembler->CodeBuffer,
                                                       (Register*) &TMP_REG_0,
                                                       dst ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "TurboAssemble_Mov() Failed\n" );
    }
    else {
        if( 0b00 == opc )
        {
            retVal = AssemblerBase_LoadStore( &Assembler->CodeBuffer,
                                              LDR_x,
                                              &W( rt ),
                                              &MEMOP_ADDR( AddrModeOffset ) );
        }
        else if( 0b01 == opc )
        {
            retVal = AssemblerBase_LoadStore( &Assembler->CodeBuffer,
                                              LDR_x,
                                              &X( rt ),
                                              &MEMOP_ADDR( AddrModeOffset ) );
        }
        else {
            DEBUGL( LOG_LEVEL_WARNING,
                    "Unexpected opcode: %c\n",
                    opc );
            retVal = ERROR_UNIMPLEMENTED;
        } // opcode
    } // TurboAssemble_Mov()

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
ErrorStatus
    WriteInstructionToBuffer_PCRelAddressingFixed_ADR
    (
        IN          relo_ctx_t*         Context,
        IN  OUT     AssemblerBase*      Assembler,
        IN          uint32_t            Instruction
    )
{
    ErrorStatus retVal  = ERROR_FAILURE;
    uintptr_t   dst     = 0;
    int         rd      = 0;

    __VERIFY_PARAM( Context, Assembler );

    rd  = bits( Instruction, 0, 4 );
    dst = GetContextCursor( Context ) + ImmHiImmLoOffset( Instruction );

    retVal = TurboAssemble_Mov( &Assembler->CodeBuffer,
                                &X( rd ),
                                dst );

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
ErrorStatus
    WriteInstructionToBuffer_PCRelAddressingFixed_ADRP
    (
        IN          relo_ctx_t*         Context,
        IN  OUT     AssemblerBase*      Assembler,
        IN          uint32_t            Instruction
    )
{
    ErrorStatus retVal  = ERROR_FAILURE;
    uintptr_t   dst     = 0;

    __VERIFY_PARAM( Context, Assembler );

    dst = GetContextCursor( Context ) + ImmHiImmLoZero12Offset( Instruction );
    dst = arm64_trunc_page( dst );

    retVal = TurboAssemble_Mov( &Assembler->CodeBuffer,
                                &X( bits( Instruction, 0, 4 ) ),
                                dst );

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
ErrorStatus
    WriteInstructionToBuffer_ConditionalBranchFixed
    (
        IN          relo_ctx_t*         Context,
        IN  OUT     AssemblerBase*      Assembler,
        IN          uint32_t            Instruction
    )
{
    ErrorStatus     retVal      = ERROR_FAILURE;
    uintptr_t       dst         = 0;
    uint32_t        branchInstr = 0;
    char            condition   = 0;
    RelocDataLabel* label       = NULL;
    uint32_t        value       = 0;

    __VERIFY_PARAM( Context, Assembler )

    dst         = GetContextCursor( Context ) + Imm19Offset( Instruction );
    branchInstr = Instruction;
    condition   = bits( Instruction, 0, 3 ) ^ 1;

    set_bits( branchInstr, 0, 3, condition );
    set_bits( branchInstr, 5, 23, 3 );

    if( ERROR_SUCCESS != ( retVal = AssemblerBase_createDataLabel( &label,
                                                                   Assembler,
                                                                   dst ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "AssemblerBase_createDataLabel() Failed\n" );
    }
    else {
        if( ERROR_SUCCESS != ( retVal = Assembler_Write32BitInstruction( &Assembler->CodeBuffer, branchInstr ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "Assembler_Write32BitInstruction() Failed\n" );
        }
        else {
            if( ERROR_SUCCESS != ( retVal = Assembler_WriteInstruction_LDR( &Assembler->CodeBuffer,
                                                                            (Register*) &TMP_REG_0,
                                                                            &label->Label ) ) )
            {
                DEBUGL( LOG_LEVEL_ERROR, "Assembler_WriteInstruction_LDR() Failed\n" );
            }
            else {
                value  = ( BR | ( ARM64_TMP_REG_NDX_0 << kRnShift ) );
                retVal = Assembler_Write32BitInstruction( &Assembler->CodeBuffer, value );
            } // Assembler_WriteInstruction_LDR()
        } // Assembler_Write32BitInstruction()
    } // AssemblerBase_createDataLabel()

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
ErrorStatus
    WriteInstructionToBuffer_CompareBranchFixed
    (
        IN          relo_ctx_t*         Context,
        IN  OUT     AssemblerBase*      Assembler,
        IN          uint32_t            Instruction
    )
{
    ErrorStatus     retVal      = ERROR_FAILURE;
    uintptr_t       dst         = 0;
    uint32_t        branchInstr = 0;
    char            op          = 0;
    RelocDataLabel* label       = NULL;
    uint32_t        value       = 0;

    __VERIFY_PARAM( Context, Assembler );

    dst         = GetContextCursor( Context ) + Imm19Offset( Instruction );
    branchInstr = Instruction;
    op          = bit( Instruction, 24 ) ^ 1;

    set_bit( branchInstr, 24, op );
    set_bits( branchInstr, 5, 23, 3 );

    if( ERROR_SUCCESS != ( retVal = AssemblerBase_createDataLabel( &label,
                                                                   Assembler,
                                                                   dst ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "AssemblerBase_createDataLabel() Failed\n" );
    }
    else {
        if( ERROR_SUCCESS != ( retVal = Assembler_Write32BitInstruction( &Assembler->CodeBuffer, branchInstr ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "Assembler_Write32BitInstruction() Failed\n" );
        }
        else {
            if( ERROR_SUCCESS != ( retVal = Assembler_WriteInstruction_LDR( &Assembler->CodeBuffer,
                                                                            (Register*) &TMP_REG_0,
                                                                            &label->Label ) ) )
            {
                DEBUGL( LOG_LEVEL_ERROR, "Assembler_WriteInstruction_LDR() Failed\n" );
            }
            else {
                value  = ( BR | ( ARM64_TMP_REG_NDX_0 << kRnShift ) );
                retVal = Assembler_Write32BitInstruction( &Assembler->CodeBuffer, value );
            } // Assembler_WriteInstruction_LDR()
        } // Assembler_Write32BitInstruction()
    } // AssemblerBase_createDataLabel()

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
ErrorStatus
    WriteInstructionToBuffer_TestBranchFixed
    (
        IN          relo_ctx_t*         Context,
        IN  OUT     AssemblerBase*      Assembler,
        IN          uint32_t            Instruction
    )
{
    ErrorStatus     retVal      = ERROR_FAILURE;
    uintptr_t       dst         = 0;
    uint32_t        branchInstr = 0;
    char            op          = 0;
    RelocDataLabel* label       = NULL;
    uint32_t        value       = 0;

    __VERIFY_PARAM( Context, Assembler );

    dst         = GetContextCursor( Context ) + Imm14Offset( Instruction );
    branchInstr = Instruction;
    op          = bit( Instruction, 24 ) ^ 1;

    set_bit( branchInstr, 24, op );
    set_bits( branchInstr, 5, 18, 3 );

    if( ERROR_SUCCESS != ( retVal = AssemblerBase_createDataLabel( &label,
                                                                    Assembler,
                                                                    dst ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "AssemblerBase_createDataLabel() Failed\n" );
    }
    else {
        if( ERROR_SUCCESS != ( retVal = Assembler_Write32BitInstruction( &Assembler->CodeBuffer, branchInstr ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "Assembler_Write32BitInstruction() Failed\n" );
        }
        else {
            if( ERROR_SUCCESS != ( retVal = Assembler_WriteInstruction_LDR( &Assembler->CodeBuffer,
                                                                            (Register*) &TMP_REG_0,
                                                                            &label->Label ) ) )
            {
                DEBUGL( LOG_LEVEL_ERROR, "Assembler_WriteInstruction_LDR() Failed\n" );
            }
            else {
                value  = ( BR | ( ARM64_TMP_REG_NDX_0 << kRnShift ) );
                retVal = Assembler_Write32BitInstruction( &Assembler->CodeBuffer, value );
            } // Assembler_WriteInstruction_LDR()
        } // Assembler_Write32BitInstruction()
    } // AssemblerBase_createDataLabel()

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
ErrorStatus
    relo_ctx_t_relocate
    (
        IN  OUT     relo_ctx_t*     Context,
        IN          bool            branch
    )
{
    ErrorStatus     retVal          = ERROR_SUCCESS;
    AssemblerBase   assembler       = { 0 };
    uint32_t        instruction     = 0;

    __VERIFY_PARAM( Context );

    Assembler_Initialize( &assembler, 0 );

    Context->RelocatedBuffer = (CodeMemBuffer*) &assembler.CodeBuffer;

    while( ( ( Context->Cursor - Context->Origin->Start ) < Context->Origin->Size ) &&
           ( ERROR_SUCCESS == retVal ) )
    {
        // record_relo_start();

        instruction = *(uint32_t *)GetContextCursor( Context );

        if( inst_is_b_bl( instruction ) )
        {
            retVal = WriteInstructionToBuffer_UnconditionalBranchFixed( Context,
                                                                        &assembler,
                                                                        instruction );
        }
        else if( inst_is_ldr_literal( instruction ) )
        {
            retVal = WriteInstructionToBuffer_LiteralLoadRegisterFixed( Context,
                                                                        &assembler,
                                                                        instruction );
        }
        else if( inst_is_adr( instruction ) )
        {
            retVal = WriteInstructionToBuffer_PCRelAddressingFixed_ADR( Context,
                                                                        &assembler,
                                                                        instruction );
        }
        else if( inst_is_adrp( instruction ) )
        {
            retVal = WriteInstructionToBuffer_PCRelAddressingFixed_ADRP( Context,
                                                                         &assembler,
                                                                         instruction );
        }
        else if( inst_is_b_cond( instruction ) )
        {
            retVal = WriteInstructionToBuffer_ConditionalBranchFixed( Context,
                                                                      &assembler,
                                                                      instruction );
        }
        else if( inst_is_compare_b( instruction ) )
        {
            retVal = WriteInstructionToBuffer_CompareBranchFixed( Context,
                                                                  &assembler,
                                                                  instruction );
        }
        else if( inst_is_test_b( instruction ) )
        {
            retVal = WriteInstructionToBuffer_TestBranchFixed( Context,
                                                               &assembler,
                                                               instruction );
        }
        else {
            retVal = Assembler_Write32BitInstruction( &assembler.CodeBuffer, instruction );
        }

        Context->Cursor += sizeof(uint32_t);
    } // while()

    if( ERROR_SUCCESS == retVal )
    {
        Context->Origin->Size = ( Context->Cursor - Context->Origin->Start );

        // TODO: if last instr is unlink branch, ignore it
        if( true == branch )
        {
            retVal = LiteralLdrBranch( &assembler, GetContextCursor( Context ) );
        }

        if( ERROR_SUCCESS == retVal )
        {
            if( ERROR_SUCCESS != ( retVal = AssemblerBase_relocDataLabels( &assembler ) ) )
            {

            }
            else {
                retVal = AssemblerCodeBuilder_FinalizeFromAssembler( &assembler, &Context->RelocatedBlock );
            } // AssemblerBase_relocDataLabels()
        } // LiteralLdrBranch()
    } // Error check

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
ErrorStatus
    GenRelocateCodeAndBranch
    (
        IN          CodeMemBlock*       Origin,
        IN  OUT     CodeMemBlock*       Relocated,
        IN          bool                Branch
    )
{
    ErrorStatus     retVal      = ERROR_FAILURE;
    relo_ctx_t      context     = { 0 };

    context.Origin = Origin;
    context.Cursor = Origin->Start;

    retVal = relo_ctx_t_relocate( &context, Branch );

    *Relocated = context.RelocatedBlock;

    return retVal;
}

static
ErrorStatus
    InterceptRouting_init
    (
        IN  OUT     InterceptRouting**      Routing,
        IN          InterceptorEntry*       Entry,
        IN          uintptr_t               FakeFunction
    )
{
    ErrorStatus retVal = ERROR_FAILURE;

    if( NULL == ( *Routing = (InterceptRouting*)malloc( sizeof( InterceptRouting ) ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "malloc() Failed\n" );
        retVal = ERROR_MEM_ALLOC;
    }
    else {
        ( *Routing )->InterceptEntry     = Entry;
        ( *Routing )->Trampoline         = NULL;
        ( *Routing )->HookFunction       = FakeFunction;

        retVal = ERROR_SUCCESS;
    } // malloc()

    return retVal;
}

static
ErrorStatus
    Active
    (
        IN  OUT     InterceptRouting*       Routing
    )
{
    ErrorStatus     retVal              = ERROR_FAILURE;
    size_t          trampolineSize      = 0;
    uintptr_t       bufferStart         = 0;

    __VERIFY_PARAM( Routing );

    trampolineSize  = Routing->Trampoline->Buffer.Size;
    bufferStart     = Routing->Trampoline->Buffer.Start;

    DEBUGL( LOG_LEVEL_NOTICE, "Patching Trampoline into Intercept Address...\n" );

    retVal = ApplyCodePatch( (void*) Routing->InterceptEntry->Address,
                             (uint8_t*) bufferStart,
                             trampolineSize );

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
ErrorStatus
    GenerateRelocatedCode
    (
        InterceptRouting* Routing
    )
{
    ErrorStatus     retVal          = ERROR_FAILURE;
    size_t          trampoline_size = 0;
    uintptr_t       buffer_start    = 0;

    __VERIFY_PARAM( Routing );

    trampoline_size = Routing->Trampoline->Buffer.Size;
    buffer_start    = Routing->Trampoline->Buffer.Start;

    if( buffer_start == 0 )
    {
        DEBUGL( LOG_LEVEL_ERROR, "Routing failed. Cannot continue\n" );
        retVal = ERROR_ROUTING_FAILURE;
    }
    else {
        Routing->InterceptEntry->Patched.Start      = Routing->InterceptEntry->Address;
        Routing->InterceptEntry->Patched.Size       = trampoline_size;
        Routing->InterceptEntry->Relocated.Start    = 0;
        Routing->InterceptEntry->Relocated.Size     = 0;

        retVal = GenRelocateCodeAndBranch( &Routing->InterceptEntry->Patched,
                                           &Routing->InterceptEntry->Relocated,
                                           true );

        if( ( ERROR_SUCCESS == retVal                                  ) &&
            ( 0             == Routing->InterceptEntry->Relocated.Size ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "Routing failed. Cannot continue\n" );
            retVal = ERROR_ROUTING_FAILURE;
        }
    }

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
ErrorStatus
    GenerateTrampoline
    (
        InterceptRouting* routing
    )
{
    ErrorStatus     retVal      = ERROR_FAILURE;
    uintptr_t       from        = routing->InterceptEntry->Address;
    uintptr_t       to          = routing->HookFunction;

    __VERIFY_PARAM( routing );

    retVal = GenerateNormalTrampolineBuffer( &routing->Trampoline,
                                             from,
                                             to );

    __DEBUG_RETVAL( retVal );
    return retVal;
}

static
ErrorStatus
    BuildRoutingAndActivateHook
    (
        InterceptRouting*   Routing
    )
{
    ErrorStatus retVal = ERROR_FAILURE;

    __VERIFY_PARAM( Routing );

    if( ERROR_SUCCESS != ( retVal = GenerateTrampoline( Routing ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "GenerateTrampoline() Failed\n" );
    }
    else {
        if( ERROR_SUCCESS != ( retVal = GenerateRelocatedCode( Routing ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "GenerateRelocatedCode() Failed\n" );
        }
        else {
            if( ERROR_SUCCESS != ( retVal = Interceptor_Entry_backup_orig_code( Routing->InterceptEntry ) ) )
            {
                DEBUGL( LOG_LEVEL_ERROR, "Interceptor_Entry_backup_orig_code() Failed\n" );
            }
            else {
                retVal = Active( Routing );
            } // Interceptor_Entry_backup_orig_code()
        } // GenerateRelocatedCode()
    } // GenerateTrampoline()

    __DEBUG_RETVAL( retVal );
    return retVal;
}

PUBLIC
ErrorStatus
    DoTheHook
    (
        IN          void*           address,
        IN          void*           fake_func,
        IN  OUT     void**          OriginalFunctionAddress,
        IN          uintptr_t       VMProtectAddress
    )
{
    ErrorStatus         retVal      = ERROR_FAILURE;
    InterceptorEntry*   entry       = NULL;
    InterceptRouting*   routing     = NULL;

    __VERIFY_PARAM( address, fake_func );

    vm_protect_address = VMProtectAddress;

    if( NULL == ( entry = (InterceptorEntry*)malloc( sizeof( InterceptorEntry ) ) ) )
    {
        DEBUGL( LOG_LEVEL_ERROR, "malloc() Failed\n" );
        retVal = ERROR_MEM_ALLOC;
    }
    else {
        entry->Address              = (uintptr_t) address;
        entry->HookFunctionAddress  = (uintptr_t) fake_func;

        if( ERROR_SUCCESS != ( retVal = InterceptRouting_init( &routing,
                                                               entry,
                                                               (uintptr_t) fake_func ) ) )
        {
            DEBUGL( LOG_LEVEL_ERROR, "InterceptRouting_init() Failed\n" );
        }
        else {

            if( ERROR_SUCCESS != ( retVal = BuildRoutingAndActivateHook( routing ) ) )
            {
                DEBUGL( LOG_LEVEL_ERROR, "BuildRoutingAndActivateHook() Failed\n" );
            }
            else {
                entry->Routing = routing;

                if( NULL != OriginalFunctionAddress )
                {
                    *OriginalFunctionAddress = (void *)entry->Relocated.Start;
                }

                retVal = ERROR_SUCCESS;
            } // BuildRoutingAndActivateHook()
        } // InterceptRouting_init()
    } // malloc()

    __DEBUG_RETVAL( retVal );
    return retVal;
}
